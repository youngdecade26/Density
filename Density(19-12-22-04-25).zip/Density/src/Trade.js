
import React, { Component, useRef } from 'react'
import { Text, SafeAreaView, StatusBar, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity, ScrollView, ImageBackground } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, Footer, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appsmallbutton } from './AllComponents';
import Slider from 'react-native-slider';
import { Switch } from 'react-native-paper';
import SwipeButton from 'rn-swipe-button';
import RBSheet from "react-native-raw-bottom-sheet";

export default class Trade extends Component {
  constructor(props) {
    super(props)
    this.state = {
      BuyModel: false,

      count: 0,

      value: 0.2,
      Overbook: false,
      Chart: true,
      RecentTrades: false,

      Market: true,
      Limit: false,
      StopMarket: false,
      StopLimit: false,

      securetext1: true,
      securetext2: true,

      Chart_arr: [
        {
          'id': '0',
          Name: '1H',
          'Size': '21.345'
        },
        {
          'id': '0',
          Name: 'Line',
          'Size': '21.345'
        },
        {
          'id': '0',
          Name: 'Compare',
          'Size': '21.345'
        },
        {
          'id': '0',
          Name: 'Indicators',
          'Size': '21.345'
        },
      ],

      AskBidArr: [
        {
          'id': '0',
          'taxt': 'All',
          'color': 'Yellow',
          'status': true
        },
        {
          'id': '1',
          'taxt': 'Bids',
          'color': 'Green',
          'status': false
        },
        {
          'id': '2',
          'taxt': 'Asks',
          'color': 'Red',
          'status': false
        },
      ]
      ,
      OverBookarr: [
        {
          'id': '0',
          'Price': '20,703.7',
          'Size': '21.345',
          'Sum': '21.345'
        },
        {
          'id': '1',
          'Price': '20,700',
          'Size': '1.034',
          'Sum': '1.034'
        },
        {
          'id': '2',
          'Price': '20,699.7',
          'Size': '99.122',
          'Sum': '99.122'
        },
        {
          'id': '3',
          'Price': '20,699',
          'Size': '2.096',
          'Sum': '2.096'
        },
        {
          'id': '4',
          'Price': '20,671',
          'Size': '3.434',
          'Sum': '3.434'
        },
        {
          'id': '5',
          'Price': '20,670',
          'Size': '3.434',
          'Sum': '3.434'
        },
        {
          'id': '6',
          'Price': '20,670',
          'Size': '3.434',
          'Sum': '3.434'
        }
      ],
      RecentTrdarr: [
        {
          'id': '0',
          'Price': '20,703.7',
          'Size': '21.345',
          'Time': '20:09:19'
        },
        {
          'id': '1',
          'Price': '20,600',
          'Size': '1.034',
          'Time': '20:09:19'
        },
        {
          'id': '2',
          'Price': '20,799.7',
          'Size': '99.122',
          'Time': '20:09:19'
        },
        {
          'id': '3',
          'Price': '20,799',
          'Size': '2.096',
          'Time': '20:09:19'
        },
        {
          'id': '4',
          'Price': '20,671',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '5',
          'Price': '20,770',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '6',
          'Price': '20,670',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '7',
          'Price': '20,670',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '8',
          'Price': '20,703.7',
          'Size': '21.345',
          'Time': '20:09:19'
        },
        {
          'id': '9',
          'Price': '20,600',
          'Size': '1.034',
          'Time': '20:09:19'
        },
        {
          'id': '10',
          'Price': '20,799.7',
          'Size': '99.122',
          'Time': '20:09:19'
        },
        {
          'id': '11',
          'Price': '20,799',
          'Size': '2.096',
          'Time': '20:09:19'
        },
        {
          'id': '12',
          'Price': '20,671',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '13',
          'Price': '20,770',
          'Size': '3.434',
          'Time': '20:09:19'
        },
        {
          'id': '14',
          'Price': '20,670',
          'Size': '3.434',
          'Time': '20:09:19'
        },

      ]

    }
  }
  componentDidMount() {
  }

  // ---------For AskBidArr of Overbook----------
  AskBid = (item, index) => {
    //consolepro.consolelog({ item, index })
    let data1 = this.state.AskBidArr;
    //consolepro.consolelog('data1', data1)
    for (let i = 0; i < data1.length; i++) {
      data1[i].status = false;
    }
    data1[index].status = true;
    {
      this.setState({
        AskBidArr: data1,
      })
    }
  }

  // --------CountForMarginUsed---------
  increment = () => {
    this.setState({
      count: this.state.count + 1
    });
  }

  decrement = () => {
    this.setState({
      count: this.state.count - 1
    });
  }
  // --------------------------------


  //---------for password-------------
  eyepress1 = () => {
    if (this.state.securetext1) {
      this.setState({ securetext1: false })
    } else {
      this.setState({ securetext1: true })
    }
  }


  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
        <SafeAreaView style={styles.container}>
          <StatusBar
            hidden={false}
            translucent={false}
            barStyle="light-content"
            networkActivityIndicatorVisible={true}
            backgroundColor={Colors.statusbarcolor}
          />
          <KeyboardAwareScrollView
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ width: mobileW, paddingBottom: mobileH * 6 / 100 }}
            keyboardShouldPersistTaps='handled'>


            {/* //==========Get Started Now Text=========// */}
            <View
              style={{
                flexDirection: 'row',
                marginTop: mobileH * 2 / 100,
                paddingHorizontal: mobileW * 5 / 100,
              }} >
              <View
                style={{
                  width: mobileW * 89 / 100,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignSelf: 'center',
                  alignItems: 'center',
                }}>
                <View style={{
                  width: mobileW * 35.8 / 100,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                  <Image style={{
                    height: mobileH * 4.4 / 100,
                    width: mobileW * 8.8 / 100,
                  }}
                    source={localimag.market_2}>
                  </Image>
                  <View>
                    <TouchableOpacity
                      activeOpacity={0.8}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        width: mobileW * 25 / 100,
                      }}>
                      <Text style={{
                        color: Colors.whiteColor,
                        fontFamily: Font.FontSemiBold,
                        fontSize: mobileW * 4.3 / 100
                      }}>
                        {Lang_chg.BTCUSDT[config.language]}
                      </Text>
                      <Image style={{
                        height: mobileH * 2 / 100,
                        width: mobileW * 4 / 100,
                      }}
                        source={localimag.DownWordArrow}>
                      </Image>
                    </TouchableOpacity>

                    <Text style={{
                      color: Colors.PnlTextColor,
                      fontFamily: Font.FontSemiBold,
                      fontSize: mobileW * 3.3 / 100
                    }}>
                      {Lang_chg.Perpetual[config.language]}
                    </Text>
                  </View>
                </View>

                <View style>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: mobileW * 20 / 100, }}>
                    <Image style={{
                      height: mobileH * 2 / 100,
                      width: mobileW * 4 / 100,
                    }}
                      source={localimag.UpwardArrow}></Image>

                    <Text style={{
                      color: Colors.GreenText,
                      fontFamily: Font.FontBold,
                      fontSize: mobileW * 4.3 / 100
                    }}>
                      {'$40,998'}
                    </Text>
                  </View>
                  <Text style={{
                    color: Colors.GreenText,
                    fontFamily: Font.FontSemiBold,
                    fontSize: mobileW * 2.3 / 100,
                    textAlign: 'right'
                  }}>
                    {'5.38%'}
                  </Text>
                </View>
              </View>
            </View>

            <View style={{
              width: mobileW * 90 / 100, alignSelf: 'center',
            }}>

              {/* -------------SecondBox-------------- */}
              <View
                style={{
                  marginTop: mobileH * 1.5 / 100,
                  width: '99.5%',
                  alignSelf: 'center',
                  //backgroundColor: Colors.CartBackColor,
                }}>

                <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100 }]}>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.MarkPrice[config.language]}
                    </Text>
                    <Text style={styles.pricetxt1}>{'40,564'}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.IndexPrice[config.language]}
                    </Text>
                    <Text style={styles.pricetxt1}>{'40,564'}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.FundingCountdown[config.language]}
                    </Text>
                    <Text style={styles.pricetxt1}>{'-0.004%/21:30:00'}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.HChange[config.language]}
                    </Text>
                    <Text style={[styles.pricetxt1, { color: Colors.OrangeColor }]}>{'-128 -0.659%'}
                    </Text>
                  </View>
                </View>

                <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, paddingTop: mobileH * 1.5 / 100, }]}>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.HHigh[config.language]}
                    </Text>
                    <Text style={styles.pricetxt1}>{'40,564'}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.HLow[config.language]}
                    </Text>
                    <Text style={styles.pricetxt1}>{'40,564'}
                    </Text>
                  </View>
                  <View>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={styles.pricetxt}>{Lang_chg.HValueUSDT[config.language]}
                      </Text>
                    </View>
                    <Text style={styles.pricetxt1}>{'123240564'}
                    </Text>
                  </View>
                  <View>
                    <Text style={styles.pricetxt}>{Lang_chg.OpenInterset[config.language]}</Text>
                    <Text style={styles.pricetxt1}>{'290880411'}
                    </Text>
                  </View>
                </View>

                <View style={{
                  borderBottomWidth: mobileW * 0.1 / 100,
                  borderBottomColor: Colors.BorderColor,
                  marginTop: mobileW * 1 / 100,
                  width: mobileW * 100 / 100,
                  alignSelf: 'center'
                }}></View>

                {/* ----------------HeadingBar----------------- */}
                <View
                  style={{
                    width: mobileW * 90 / 100,
                    flexDirection: 'row',
                    alignItems: 'center',
                    alignSelf: 'center',
                    marginTop: mobileH * 0.5 / 100
                  }}>
                  <TouchableOpacity
                    activeOpacity={0.9}
                    onPress={() => {
                      this.setState({
                        Overbook: false,
                        Chart: true,
                        RecentTrades: false,
                      });
                    }}
                    style={{
                      width: mobileW * 32 / 100,
                    }}>
                    <View
                      style={{
                        width: mobileW * 27 / 100,
                      }}>
                      <Text
                        style={this.state.Chart == true ? styles.activetabstyle : styles.inactivetabstyle}>
                        {Lang_chg.Chart[config.language]}
                      </Text>
                    </View>
                    {this.state.Chart == true &&
                      <View style={{
                        borderBottomWidth: mobileW * 0.5 / 100,
                        borderBottomColor: Colors.ButtonBarColor,
                        width: mobileW * 11 / 100,
                      }}></View>
                    }
                  </TouchableOpacity>

                  <TouchableOpacity
                    activeOpacity={0.9}
                    onPress={() => {
                      this.setState({
                        Overbook: true,
                        Chart: false,
                        RecentTrades: false,
                      });
                    }}
                    style={{ width: mobileW * 32 / 100, alignSelf: 'center' }}>
                    <View
                      style={{
                        width: mobileW * 27 / 100,
                      }}>
                      <Text style={this.state.Overbook == true ? styles.activetabstyle : styles.inactivetabstyle}>
                        {Lang_chg.Orderbook[config.language]}
                      </Text>
                    </View>
                    {this.state.Overbook == true &&
                      <View style={{
                        borderBottomWidth: mobileW * 0.5 / 100,
                        borderBottomColor: Colors.ButtonBarColor,
                        width: mobileW * 20 / 100,
                      }}></View>
                    }
                  </TouchableOpacity>

                  <TouchableOpacity
                    activeOpacity={0.9}
                    onPress={() => {
                      this.setState({
                        Overbook: false,
                        Chart: false,
                        RecentTrades: true,
                      });
                    }}
                    style={{
                      width: mobileW * 32 / 100, alignSelf: 'center'
                    }}>
                    <View style={{
                      width: mobileW * 27 / 100,
                    }}>
                      <Text
                        style={this.state.RecentTrades == true ? styles.activetabstyle : styles.inactivetabstyle}>
                        {Lang_chg.RecentTrades[config.language]}
                      </Text>
                    </View>
                    {this.state.RecentTrades == true &&
                      <View style={{
                        borderBottomWidth: mobileW * 0.5 / 100,
                        borderBottomColor: Colors.ButtonBarColor,
                        width: mobileW * 26.5 / 100,
                      }}></View>
                    }
                  </TouchableOpacity>
                </View>
                {/* -------------------------------------------- */}

                {/* ------------------ContainrStart------------------ */}
                <View>
                  <View style={{
                    borderBottomWidth: mobileW * 0.4 / 100,
                    borderBottomColor: Colors.BorderColor,
                    width: mobileW * 100 / 100,
                    alignSelf: 'center'
                  }}></View>

                  {/* ----------------DataForChart-----------------*/}

                  {this.state.Chart == true &&
                    <View>
                      <View style={{
                        width: mobileW * 90 / 100,
                        flexDirection: 'row',
                        alignItems: 'center',
                        alignSelf: 'center'
                      }}>
                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 10 / 100,
                            alignSelf: 'center',
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            flexDirection: 'row',
                            alignItems: 'center'
                          }}>
                          <Text
                            style={styles.tabstyle}>
                            {Lang_chg.OneH[config.language]}
                          </Text>
                          <Image
                            style={styles.DownArrowStyle}
                            source={localimag.DownWordArrow}>
                          </Image>
                        </TouchableOpacity>

                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 15 / 100,
                            alignSelf: 'center',
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>
                          <Text style={styles.tabstyle}>
                            {Lang_chg.Line[config.language]}
                          </Text>
                          <Image
                            style={styles.DownArrowStyle}
                            source={localimag.DownWordArrow}>
                          </Image>
                        </TouchableOpacity>

                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 27 / 100,
                            alignSelf: 'center',
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>
                          <Text
                            style={styles.tabstyle}>
                            {Lang_chg.Compare[config.language]}
                          </Text>
                          <Image
                            style={{
                              height: mobileH * 2 / 100,
                              width: mobileW * 4 / 100,
                              marginLeft: mobileW * 2 / 100
                            }}
                            source={localimag.AddIcon}>
                          </Image>
                        </TouchableOpacity>

                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 20 / 100,
                            alignSelf: 'center',
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center'
                          }}>
                          <Text
                            style={styles.tabstyle}>
                            {Lang_chg.Indicators[config.language]}
                          </Text>
                          <Image
                            style={styles.DownArrowStyle}
                            source={localimag.DownWordArrow}>
                          </Image>
                        </TouchableOpacity>

                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 12 / 100,
                            alignSelf: 'center',
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center',
                            paddingVertical: mobileH * 0.6 / 100
                          }}>
                          <Image
                            style={{
                              height: mobileH * 2.5 / 100,
                              width: mobileW * 5 / 100,
                            }}
                            source={localimag.Settings}>
                          </Image>
                        </TouchableOpacity>

                        <TouchableOpacity
                          activeOpacity={0.7}
                          onPress={() => {
                          }}
                          style={{
                            width: mobileW * 16 / 100,
                            alignSelf: 'center',
                            flexDirection: 'row',
                            alignItems: 'center',
                            paddingVertical: mobileH * 0.7 / 100,
                            paddingLeft: mobileW * 3 / 100
                          }}>
                          <Image
                            style={{
                              height: mobileH * 2 / 100,
                              width: mobileW * 4 / 100,
                            }}
                            source={localimag.Widepng}>
                          </Image>
                        </TouchableOpacity>
                      </View>

                      <View style={{
                        borderBottomWidth: mobileW * 0.5 / 100,
                        borderBottomColor: Colors.BorderColor,
                        width: mobileW * 100 / 100,
                        alignSelf: 'center'
                      }}></View>

                      {/* -----------Image---------- */}
                      <View style={{
                        alignItems: 'center',
                        paddingRight: mobileW * 1.2 / 100
                      }}><Image
                        style={{
                          height: mobileH * 49 / 100,
                          width: mobileW * 100 / 100,
                          marginLeft: mobileW * 2 / 100,
                        }}
                        source={localimag.TreadingImage}></Image>
                      </View>
                    </View>
                  }

                  {/* ------------------DataForOverbook------------------- */}

                  {this.state.Overbook == true &&

                    <View style={{
                      height: mobileH * 53 / 100,
                      width: mobileW * 90 / 100,
                      alignSelf: 'center'
                    }}>
                      <FlatList
                        horizontal={true}
                        data={this.state.AskBidArr}
                        contentContainerStyle={{ paddingBottom: mobileW * 7 / 100 }}
                        showsVerticalScrollIndicator={false}
                        renderItem={({ item, index }) => {
                          console.log('item', item)
                          return (
                            <TouchableOpacity
                              activeOpacity={0.8}
                              onPress={() => this.AskBid(item, index)}
                              style={[styles.ThreeButtonView,
                              { backgroundColor: item.status == true ? Colors.whiteColor : Colors.themeblack_color, borderColor: item.status == true ? Colors.whiteColor : item.color == 'Green' ? Colors.GreenText : item.color == 'Red' ? Colors.OrangeColor : Colors.YellowTextColor }
                              ]}>
                              <Text style={[styles.ThreeButtonText,
                              { color: item.status == true ? Colors.black_color : item.color == 'Green' ? Colors.GreenText : item.color == 'Red' ? Colors.OrangeColor : Colors.YellowTextColor }
                              ]}>{item.taxt}
                              </Text>
                            </TouchableOpacity>
                          )
                        }}
                      />

                      <View style={{
                        width: mobileW * 90 / 100,
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignSelf: 'center', marginTop: mobileH * 2 / 100
                      }}>
                        <View style={styles.FlatelistHeaderTxtView}>
                          <Text style={[styles.FlatelistHeaderTxt, {}]}>{Lang_chg.PriceUSDT[config.language]}
                          </Text>
                        </View>
                        <View style={styles.FlatelistHeaderTxtView}>
                          <Text style={[styles.FlatelistHeaderTxt, { marginLeft: mobileW * 6 / 100 }]}>{Lang_chg.SizeUSDT[config.language]}
                          </Text>
                        </View>
                        <View style={styles.FlatelistHeaderTxtView}>
                          <Text style={[styles.FlatelistHeaderTxt, { marginLeft: mobileW * 11 / 100 }]}>{Lang_chg.SumUSDT[config.language]}
                          </Text></View>
                      </View>

                      <ImageBackground
                        source={localimag.RedTradeBackImage}
                        style={{
                          height: mobileH * 18 / 100,
                          width: mobileW * 90 / 100,
                        }}>
                        <FlatList
                          data={this.state.OverBookarr}
                          contentContainerStyle={{ paddingBottom: mobileW * 2 / 100 }}
                          showsVerticalScrollIndicator={false}
                          renderItem={({ item, index }) => {
                            console.log('item', item)
                            return (
                              <View style={[styles.justifyContentStyle, {
                                width: mobileW * 90 / 100,
                                paddingVertical: mobileW * 0.2 / 100
                              }]}>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.RedButton }]}>{item.Price}
                                  </Text>
                                </View>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 1 / 100 }]}>{item.Size}
                                  </Text>
                                </View>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 1 / 100 }]}>{item.Sum}
                                  </Text>
                                </View>
                              </View>
                            )
                          }}
                        />
                      </ImageBackground>

                      {/* ----------------------------*/}
                      <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: mobileH * 0.2 / 100, Width: mobileW * 90 / 100, }}>
                        <Text style={{
                          fontSize: mobileW * 5 / 100,
                          fontFamily: Font.FontSemiBold,
                          color: Colors.RedButton
                        }}>21,283.1</Text>
                        <Image style={{
                          height: mobileH * 2 / 100,
                          width: mobileW * 4 / 100,
                          marginLeft: mobileW * 1 / 100
                        }}
                          source={localimag.RedDown}>
                        </Image>
                        <Text style={{
                          fontSize: mobileW * 4 / 100,
                          fontFamily: Font.FontSemiBold,
                          color: Colors.GreyText, textDecorationLine: 'underline',
                          marginLeft: mobileW * 5 / 100
                        }}>21,283.1</Text>
                      </View>
                      {/* ----------------------------*/}
                      {/* --------------SecondFlatlist--------------- */}
                      <ImageBackground
                        source={localimag.GreenTradeBackImage}
                        style={{
                          height: mobileH * 21 / 100,
                          width: mobileW * 90 / 100,
                        }}>
                        <FlatList
                          data={this.state.OverBookarr
                          }
                          contentContainerStyle={{
                            paddingBottom: mobileW * 2 / 100,
                            marginTop: mobileH * 0.2 / 100
                          }}
                          showsVerticalScrollIndicator={false}
                          renderItem={({ item, index }) => {
                            console.log('item', item)
                            return (

                              <View style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                marginTop: mobileH * 0.5 / 100,
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                              }}>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.GreenText }]}>{item.Price}
                                  </Text>
                                </View>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 1 / 100 }]}>{item.Size}
                                  </Text>
                                </View>

                                <View style={styles.FlatelistTxtView}>
                                  <Text style={[styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 1 / 100 }]}>{item.Sum}
                                  </Text>
                                </View>
                              </View>
                            )
                          }}
                        />
                      </ImageBackground>
                    </View>

                  }

                  {/* -----------------DataForRecentTrades----------------- */}

                  {this.state.RecentTrades == true &&
                    <View style={{
                      height: mobileH * 53 / 100,
                      width: mobileW * 90 / 100,
                      alignSelf: 'center'
                    }}>
                      <View style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        marginTop: mobileH * 1 / 100,
                        width: mobileW * 90 / 100,
                        alignSelf: 'center'
                      }}>
                        <View style={styles.FlatelistHeaderTxtView1}>
                          <Text style={[styles.FlatelistHeaderTxt, {}]}>{Lang_chg.PriceUSDT[config.language]}
                          </Text>
                        </View>
                        <View style={[styles.FlatelistHeaderTxtView1, {}]}>
                          <Text style={[styles.FlatelistHeaderTxt, { marginLeft: mobileW * 7 / 100 }]}>{Lang_chg.SizeUSDT[config.language]}
                          </Text>
                        </View>
                        <View style={[styles.FlatelistHeaderTxtView1, {}]}>
                          <Text style={[styles.FlatelistHeaderTxt, { marginLeft: mobileW * 13 / 100 }]}>{Lang_chg.Time[config.language]}
                          </Text>
                        </View>
                      </View>
                      <FlatList
                        data={this.state.RecentTrdarr
                        }
                        contentContainerStyle={{ paddingBottom: mobileW * 2 / 100 }}
                        showsVerticalScrollIndicator={false}
                        renderItem={({ item, index }) => {
                          console.log('item', item)
                          return (
                            <View style={{
                              flexDirection: 'row', justifyContent: 'space-between',
                              alignItems: 'center', width: '100%',
                              paddingVertical: mobileW * 0.5 / 100
                            }}>

                              <View style={styles.FlatelistTxtView}>
                                <Text style={[
                                  styles.FlatelistTxt, {
                                    color: item.Price >= '20,700' ? Colors.RedButton : Colors.GreenButton,
                                    //textAlign: 'left'
                                  }]}
                                >{item.Price}
                                </Text>
                              </View>

                              <View style={[styles.FlatelistTxtView, {}]}>
                                <Text style={[
                                  styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 4.5 / 100 }]}>{item.Size}
                                </Text>
                              </View>

                              <View style={[styles.FlatelistTxtView, {}]}>
                                <Text style={[
                                  styles.FlatelistTxt, { color: Colors.whiteColor, marginLeft: mobileW * 7 / 100 }]}>{item.Time}
                                </Text>
                              </View>
                            </View>
                          )
                        }}
                      />
                    </View>
                  }

                  <View style={{
                    borderBottomWidth: mobileW * 0.5 / 100,
                    borderBottomColor: Colors.BorderColor,
                    width: mobileW * 100 / 100,
                    alignSelf: 'center'
                  }}></View>

                  {/* -----------------Buttons------------------ */}
                  <View style={{
                    marginVertical: mobileH * 1 / 100,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: mobileW * 84 / 100,
                    alignSelf: 'center',
                  }}>
                    <TouchableOpacity
                      onPress={() => this.RBSheet.open()}
                      activeOpacity={0.9} style={[styles.BuySellButtonView, { backgroundColor: Colors.GreenButton, }]}>
                      <Text style={styles.BuySellButtonTxt}>{Lang_chg.Buy[config.language]}
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() => { }}
                      activeOpacity={0.9} style={[styles.BuySellButtonView, { backgroundColor: Colors.RedButton, }]}>
                      <Text style={styles.BuySellButtonTxt}>{Lang_chg.Sell[config.language]}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>

            {/* ----------------BottomSheet------------------ */}
            <RBSheet
              ref={ref => {
                this.RBSheet = ref;
              }}
              height={520}
              openDuration={250}
              minClosingHeight={0}
              closeDuration={250}
              closeOnDragDown={true}
              dragFromTopOnly={true}
              keyboardAvoidingViewEnabled={true}
              customStyles={{
                container: {
                  justifyContent: "center",
                  alignItems: "center",
                  borderTopRightRadius: mobileH * 5 / 100,
                  borderTopLeftRadius: mobileH * 5 / 100,
                  backgroundColor: Colors.HomeBackColor,
                }
              }}
            >
              <KeyboardAwareScrollView>
                <View style={{
                  alignSelf: 'center',
                  width: mobileW * 100 / 100,
                  marginTop: mobileH * 7 / 100
                }}>

                  {/* -----------HeadingBar------------ */}
                  <ScrollView
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={{
                      width: mobileW * 100 / 100,
                      flexDirection: 'row',
                      alignItems: 'center',
                      alignSelf: 'center'
                    }}>
                    <TouchableOpacity
                      activeOpacity={0.9}
                      onPress={() => {
                        this.setState({
                          Market: true,
                          Limit: false,
                          StopMarket: false,
                          StopLimit: false,
                        });
                      }}
                      style={{ width: mobileW * 25 / 100, alignSelf: 'center', }}>
                      <Text
                        style={this.state.Market == true ? styles.activetabstyle1 : styles.inactivetabstyle1}>
                        {Lang_chg.Market[config.language]}
                      </Text>
                      {this.state.Market == true &&
                        <View style={{
                          borderBottomWidth: mobileW * 1 / 100,
                          borderBottomColor: Colors.ButtonBarColor, width: '100%'
                        }}></View>
                      }
                    </TouchableOpacity>

                    <TouchableOpacity
                      activeOpacity={0.9}
                      onPress={() => {
                        this.setState({
                          Market: false,
                          Limit: true,
                          StopMarket: false,
                          StopLimit: false,
                        });
                      }}
                      style={{ width: mobileW * 25 / 100, alignSelf: 'center' }}>
                      <Text style={this.state.Limit == true ? styles.activetabstyle1 : styles.inactivetabstyle1}>
                        {Lang_chg.Limit[config.language]}
                      </Text>
                      {this.state.Limit == true &&
                        <View style={{
                          borderBottomWidth: mobileW * 1 / 100,
                          borderBottomColor: Colors.ButtonBarColor, width: '100%'
                        }}></View>
                      }
                    </TouchableOpacity>

                    <TouchableOpacity
                      activeOpacity={0.9}
                      onPress={() => {
                        this.setState({
                          Market: false,
                          Limit: false,
                          StopMarket: true,
                          StopLimit: false,
                        });
                      }}
                      style={{
                        width: mobileW * 25 / 100, alignSelf: 'center'
                      }}>
                      <Text
                        style={this.state.StopMarket == true ? styles.activetabstyle1 : styles.inactivetabstyle1}>
                        {Lang_chg.StopMarket[config.language]}
                      </Text>
                      {this.state.StopMarket == true &&
                        <View style={{
                          borderBottomWidth: mobileW * 1 / 100,
                          borderBottomColor: Colors.ButtonBarColor, width: '100%'
                        }}></View>
                      }
                    </TouchableOpacity>

                    <TouchableOpacity
                      activeOpacity={0.9}
                      onPress={() => {
                        this.setState({
                          Market: false,
                          Limit: false,
                          StopMarket: false,
                          StopLimit: true,
                        });
                      }}
                      style={{
                        width: mobileW * 25 / 100, alignSelf: 'center'
                      }}>
                      <Text
                        style={this.state.StopLimit == true ? styles.activetabstyle1 : styles.inactivetabstyle1}>
                        {Lang_chg.StopLimit[config.language]}
                      </Text>
                      {this.state.StopLimit == true &&
                        <View style={{
                          borderBottomWidth: mobileW * 1 / 100,
                          borderBottomColor: Colors.ButtonBarColor, width: '100%'
                        }}></View>
                      }
                    </TouchableOpacity>
                  </ScrollView>
                  {/* ----------------------------------- */}

                  <View style={{
                    borderBottomWidth: mobileW * 0.5 / 100,
                    borderBottomColor: Colors.BorderColor,
                    width: mobileW * 100 / 100,
                    alignSelf: 'center',
                    marginBottom: mobileH * 0.1 / 100
                  }}></View>
                  {/* --------------------Close---------------------- */}

                  <View style={[styles.justifyContentStyle, {
                    width: mobileW * 90 / 100,
                    marginTop: mobileH * 1 / 100
                  }]}>
                    <Text style={styles.AvailableBalancetxt}>{Lang_chg.AvailableBalance[config.language]}
                    </Text>
                    <Text style={styles.AvailableBalancetxt}>{Lang_chg.AvailableBalanceTXT[config.language]}
                    </Text>
                  </View>

                  {/* -----------------LevelRange--------------- */}
                  <View style={{
                    marginTop: mobileH * 2 / 100,
                    width: mobileW * 90 / 100,
                    alignSelf: 'center'
                  }}>
                    <Text style={styles.TextStyle}>{Lang_chg.Leverange[config.language]}</Text>
                    <Slider
                      value={(this.state.disance)}
                      onValueChange={(value) => this.setState({ disance: value })}
                      maximumTrackTintColor='#CACACA'
                      minimumTrackTintColor='#E2FF6F'
                      thumbTintColor='#44444D'
                      minimumValue={1}
                      maximumValue={100}
                      thumbStyle={{ elevation: 5, shadowColor: '#000', shadowOffset: { width: 1, height: 1 }, shadowOpacity: 0.5, }}
                      style={{}}
                    />
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: mobileW * 90 / 100 }}>
                      <Text style={styles.SliderText}>1x</Text>
                      <Text style={styles.SliderText}>2x</Text>
                      <Text style={styles.SliderText}>3x</Text>
                      <Text style={styles.SliderText}>4x</Text>
                      <Text style={styles.SliderText}>5x</Text>
                      <Text style={styles.SliderText}>6x</Text>
                      <Text style={styles.SliderText}>7x</Text>
                      <Text style={styles.SliderText}>8x</Text>
                      <Text style={styles.SliderText}>9x</Text>
                      <Text style={styles.SliderText}>10x</Text>
                    </View>
                  </View>
                  {/* --------------------------------------- */}

                  <View style={[styles.justifyContentStyle, {
                    marginTop: mobileH * 2 / 100,
                    width: mobileW * 90 / 100,
                  }]}>
                    <Text style={{
                      fontSize: mobileW * 4 / 100,
                      fontFamily: Font.FontSemiBold,
                      textAlign: 'center',
                      color: Colors.whiteColor
                    }}>{Lang_chg.MaxBuyPower[config.language]}
                    </Text>
                    <Text style={{
                      fontSize: mobileW * 4 / 100,
                      fontFamily: Font.FontSemiBold,
                      textAlign: 'center',
                      color: Colors.whiteColor
                    }}>{Lang_chg.AvailableBalanceTXT[config.language]}
                    </Text>
                  </View>

                  {/* ------------ForStopMarket------------ */}
                  {this.state.StopMarket == true &&
                    <View style={{
                      alignSelf: 'center',
                      width: mobileW * 90 / 100,
                    }}>
                      <Text style={styles.TextStyle}>{Lang_chg.TriggerPrice[config.language]}
                      </Text>
                      <View style={{
                        height: mobileH * 5 / 100,
                        width: mobileW * 90 / 100,
                        justifyContent: 'center',
                        backgroundColor: Colors.ModelInsideButton,
                        marginTop: mobileH * 1 / 100
                      }}>
                        <View style={{
                          width: mobileW * 80 / 100,
                          flexDirection: 'row',
                          alignSelf: 'center',
                          justifyContent: 'space-between',
                        }}>
                          <Text style={{
                            fontSize: mobileW * 3 / 100,
                            fontFamily: Font.FontSemiBold,
                            textAlign: 'center',
                            color: Colors.PnlTextColor
                          }}>{Lang_chg.SizeInUSDT[config.language]}
                          </Text>
                          <Text style={{
                            fontSize: mobileW * 3 / 100,
                            fontFamily: Font.FontSemiBold,
                            textAlign: 'center',
                            color: Colors.GreenText
                          }}>{Lang_chg.Last[config.language]}
                          </Text>
                        </View>
                      </View>
                    </View>
                  }
                  {/* ------------------------------ */}

                  {/* --------------Size-------------- */}
                  <View style={{
                    alignSelf: 'center',
                    width: mobileW * 90 / 100,
                    marginTop: mobileH * 1 / 100
                  }}>
                    <Text style={styles.TextStyle}>{Lang_chg.SizeTaxt[config.language]}
                    </Text>
                    <View style={{
                      flexDirection: 'row',
                      alignSelf: 'center',
                      justifyContent: 'space-between',
                      width: mobileW * 90 / 100,
                      marginTop: mobileH * 0.4 / 100
                    }}>
                      <View style={{
                        height: mobileH * 5 / 100,
                        width: mobileW * 28 / 100,
                        justifyContent: 'center',
                        backgroundColor: Colors.ModelInsideButton
                      }}>
                        <Text style={{
                          fontSize: mobileW * 3 / 100,
                          fontFamily: Font.FontSemiBold,
                          textAlign: 'center',
                          color: Colors.PnlTextColor
                        }}>{Lang_chg.SizeInUSDT[config.language]}
                        </Text>
                      </View>

                      <Text style={{ color: Colors.whiteColor, marginTop: mobileH * 1 / 100 }}>{'-'}</Text>

                      <View style={{
                        height: mobileH * 5 / 100,
                        width: mobileW * 28 / 100,
                        justifyContent: 'center',
                        borderWidth: mobileW * 0.3 / 100,
                        borderColor: Colors.PnlTextColor,
                        backgroundColor: Colors.ModelInsideButton
                      }}>
                        <View style={[styles.justifyContentStyle, { width: mobileW * 22 / 100, }]}>
                          <Text style={{
                            fontSize: mobileW * 3.6 / 100,
                            fontFamily: Font.FontSemiBold,
                            color: Colors.whiteColor
                          }}>{'2000'}
                          </Text>
                          <Text style={{
                            fontSize: mobileW * 3.6 / 100,
                            fontFamily: Font.FontSemiBold,
                            color: Colors.whiteColor
                          }}>{Lang_chg.BTC[config.language]}
                          </Text>
                        </View>
                      </View>
                    </View>

                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginTop: mobileH * 2 / 100
                    }}>
                      <Text style={styles.TextStyle}>{Lang_chg.MinimumQuality[config.language]}
                      </Text>
                      <Text style={{
                        fontSize: mobileW * 3.2 / 100,
                        fontFamily: Font.FontSemiBold,
                        textAlign: 'center',
                        color: Colors.whiteColor
                      }}>{Lang_chg.AvailableBalanceTXT[config.language]}
                      </Text>
                    </View>

                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>
                      <Text style={styles.TextStyle}>{Lang_chg.StepSize[config.language]}
                      </Text>
                      <Text style={{
                        fontSize: mobileW * 3.2 / 100,
                        fontFamily: Font.FontSemiBold,
                        textAlign: 'center',
                        color: Colors.whiteColor
                      }}>{Lang_chg.AvailableBalanceTXT[config.language]}
                      </Text>
                    </View>

                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginTop: mobileH * 2 / 100
                    }}>
                      <Text style={styles.TextStyle}>{Lang_chg.MarginUsed2[config.language]}
                      </Text>
                      <Text style={{
                        fontSize: mobileW * 3.2 / 100,
                        fontFamily: Font.FontSemiBold,
                        textAlign: 'center',
                        color: Colors.whiteColor
                      }}>{Lang_chg.AvailableBalanceTXT[config.language]}
                      </Text>
                    </View>
                    {/* -------------MarginUsed-------------- */}
                    <View style={{
                      flexDirection: 'row',
                      alignSelf: 'center',
                      justifyContent: 'space-between',
                      width: mobileW * 90 / 100,
                      marginTop: mobileH * 0.4 / 100
                    }}>
                      <View style={{
                        height: mobileH * 5 / 100,
                        width: mobileW * 25 / 100,
                        justifyContent: 'space-between',
                        borderWidth: mobileW * 0.3 / 100,
                        borderColor: Colors.PnlTextColor,
                        backgroundColor: Colors.ModelInsideButton,
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}>
                        <View style={{
                          width: mobileW * 21 / 100,
                          justifyContent: 'space-between',
                          flexDirection: 'row',
                          alignItems: 'center',
                          marginLeft: mobileW * 2 / 100
                        }}>
                          <TouchableOpacity
                            activeOpacity={0.7}
                            onPress={() => this.decrement()}>
                            <Text style={styles.MarginUsedCounttxt}>{'-'}
                            </Text>
                          </TouchableOpacity>
                          <Text style={styles.MarginUsedCounttxt}>{this.state.count}
                          </Text>
                          <TouchableOpacity
                            activeOpacity={0.7}
                            onPress={() => this.increment()}
                          >
                            <Text style={styles.MarginUsedCounttxt}>{'+'}</Text>
                          </TouchableOpacity>
                        </View>
                      </View>


                      <View style={{
                        width: mobileW * 45 / 100,
                        justifyContent: 'space-between',
                        alignSelf: 'center',
                        alignItems: 'center',
                        flexDirection: 'row',
                      }}>
                        <View style={
                          styles.MarginUsedPertxtView
                        }>
                          <Text style={
                            styles.MarginUsedPertxt
                          }>{'25%'}
                          </Text>
                        </View>
                        <View style={
                          styles.MarginUsedPertxtView
                        }>
                          <Text style={
                            styles.MarginUsedPertxt
                          }>{'50%'}
                          </Text>
                        </View>
                        <View style={
                          styles.MarginUsedPertxtView
                        }>
                          <Text style={
                            styles.MarginUsedPertxt
                          }>{'75%'}
                          </Text>
                        </View>
                        <View style={
                          styles.MarginUsedPertxtView
                        }>
                          <Text style={
                            styles.MarginUsedPertxt
                          }>{'100%'}
                          </Text>
                        </View>
                      </View>
                    </View>

                    {/* ---------Toggles----------- */}
                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginTop: mobileH * 2 / 100
                    }}>
                      <View>
                        <View style={{
                          flexDirection: 'row', justifyContent: 'space-between',
                          alignItems: 'center',
                          width: mobileW * 9 / 100
                        }}>
                          <Switch
                            color={Colors.theme_color}
                            value={this.state.isSwitchOn}
                            onValueChange={this.onToggleSwitch}
                          />
                          <Text style={{
                            fontSize: mobileW * 3.2 / 100,
                            fontFamily: Font.FontSemiBold,
                            color: Colors.whiteColor
                          }}>{Lang_chg.TP[config.language]}
                          </Text>
                        </View>
                        <View style={styles.ProfitlossView}>
                          <Text style={styles.ProfitlossTxt}>{Lang_chg.TakeProfit[config.language]}
                          </Text>
                        </View>
                      </View>

                      <View style={{}}>
                        <View style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          alignItems: 'center',
                          width: mobileW * 9 / 100,
                          marginLeft: mobileW * 11 / 100
                        }}>
                          <Switch
                            color={Colors.theme_color}
                            value={this.state.isSwitchOn}
                            onValueChange={this.onToggleSwitch}
                          />
                          <Text style={{
                            fontSize: mobileW * 3.2 / 100,
                            fontFamily: Font.FontSemiBold,
                            color: Colors.whiteColor
                          }}>{Lang_chg.SL[config.language]}
                          </Text>
                        </View>
                        <View style={styles.ProfitlossView}>
                          <Text style={styles.ProfitlossTxt}>{Lang_chg.StopLose[config.language]}
                          </Text>
                        </View>
                      </View>
                    </View>

                    {/* ----------------------------------             */}
                    <View style={{
                      borderBottomWidth: mobileW * 0.8 / 100,
                      borderBottomColor: Colors.BorderColor,
                      marginTop: mobileW * 10 / 100,
                      width: mobileW * 100 / 100,
                      alignSelf: 'center'
                    }}></View>

                    <TouchableOpacity activeOpacity={0.7}
                      onPress={() => { this.eyepress1() }}
                      style={{
                        flexDirection: 'row',
                        marginTop: mobileH * 2 / 100,
                        width: mobileW * 90 / 100,
                        alignSelf: 'center',
                        alignItems: 'center'
                      }}>
                      <TouchableOpacity activeOpacity={0.7} style={{}}
                        onPress={() => { this.eyepress1() }}  >
                        {this.state.securetext1 ?
                          <Image style={{ width: mobileW * 4 / 100, height: mobileW * 4 / 100 }} source={localimag.CheckBlack}>
                          </Image>
                          :
                          <Image style={{ width: mobileW * 4 / 100, height: mobileW * 4 / 100 }} source={localimag.UncheckBlack}>
                          </Image>
                        }
                      </TouchableOpacity>
                      <Text style={{
                        fontSize: mobileW * 3.2 / 100,
                        fontFamily: Font.FontSemiBold,
                        textAlign: 'center',
                        color: Colors.PnlTextColor,
                        marginLeft: mobileW * 2 / 100
                      }}>{Lang_chg.ReduceOnly[config.language]}
                      </Text>
                    </TouchableOpacity>

                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginTop: mobileH * 2 / 100,
                      width: mobileW * 55 / 100,
                      alignSelf: 'center'
                    }}>
                      <View style={{
                        borderRightWidth: mobileW * 0.5 / 100,
                        borderRightColor: Colors.BorderColor,
                        width: mobileW * 30 / 100,
                      }}>
                        <Text style={styles.Bottomtxt}>{Lang_chg.Max[config.language]}  <Text style={styles.Bottomtxt1}>0.05 {Lang_chg.usdt_txt[config.language]}</Text>
                        </Text>
                      </View>
                      <View>
                        <Text style={styles.Bottomtxt}>{Lang_chg.Cost[config.language]}  <Text style={styles.Bottomtxt1}>0.05 {Lang_chg.usdt_txt[config.language]}</Text>
                        </Text>
                      </View>
                    </View>

                    {/* -------------Button--------------- */}
                    {/* <View style={{ marginTop: mobileH * 2 / 100 }}>
                      <SwipeButton
                        disableResetOnTap
                        // forceReset={reset => {
                        //   forceResetLastButton = reset
                        // }}
                        railBackgroundColor="#31a57c"
                        railStyles={{ borderRadius: 60 }}
                        //thumbIconImageSource={localimag.GreenRightArrow}
                        thumbIconStyles={{ borderRadius: 60, }}
                        thumbIconWidth={60}
                        title="BUY/LONG"
                        titleColor="#ffffff"
                        thumbIconImageSource={localimag.GreenRightArrow}
                        titleFontSize={mobileW * 5 / 100}
                        thumbIconBackgroundColor="#FFFFFF"
                        height={60}
                      //titleFontSize={Font.FontBold}
                      />
                    </View> */}

                    <View style={{ marginTop: mobileH * 2 / 100, paddingBottom: mobileH * 2 / 100 }}>
                      <TouchableOpacity
                        onPress={this.props.handlepress}
                        activeOpacity={0.7} style={{
                          backgroundColor: Colors.GreenButton,
                          height: mobileH * 7.5 / 100,
                          width: mobileW * 90 / 100,
                          alignSelf: 'center',
                          justifyContent: 'center',

                          borderRadius: mobileW * 8 / 100
                        }}>
                        <View style={{
                          alignItems: 'flex-start', flexDirection: 'row', alignItems: 'center',
                        }}>
                          <Image source={localimag.GreenRightArrow}
                            style={{
                              height: mobileH * 7 / 100, width: mobileW * 14 / 100,
                              marginLeft: mobileW * 0.5 / 100
                            }}></Image>
                          <Text style={{
                            color: Colors.whiteColor,
                            fontFamily: Font.FontBold,
                            fontSize: mobileW * 4 / 100,
                            marginLeft: mobileW * 20 / 100,
                          }}>{"BUY/LONG"}</Text>
                        </View>


                      </TouchableOpacity>
                    </View>


                  </View>
                </View>
              </KeyboardAwareScrollView>
            </RBSheet>
            {/* --------------------------------------- */}

          </KeyboardAwareScrollView >

          {/* ----------------Footer----------------- */}
          <Footer
            activepage='Trade'
            usertype={1}
            footerpage={[
              {
                name: 'Home',
                fname: 'Home',
                image: localimag.home_inactive,
                activeimage: localimag.home_active,
              },
              {
                name: 'Orders',
                fname: 'Orders', image: localimag.orders_inactive,
                activeimage: localimag.orders_active,
              },
              {
                name: 'Trade',
                fname: 'Trade',
                image: localimag.trade_inactive,
                activeimage: localimag.trade_active,
              },
              {
                name: 'Positions',
                fname: 'Positions',
                image: localimag.position_inactive,
                activeimage: localimag.position_active,
              },
              {
                name: 'Wallet',
                fname: 'Wallet', image: localimag.wallet_inactive,
                activeimage: localimag.wallet_active,
              },
            ]}
            navigation={this.props.navigation}
            imagestyle1={{
              width: mobileW * 6 / 100, height: mobileW * 6 / 100,
              backgroundColor: Colors.themeblack_color,
              countcolor: Colors.white_color,
            }}
          />

        </SafeAreaView >
      </View >
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: Colors.themeblack_color
  },

  justifyContentStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignSelf: 'center'
  },
  pricetxt: {
    color: Colors.PnlTextColor,
    fontSize: mobileW * 2.8 / 100,
    fontFamily: Font.FontMedium,
    textAlign: 'center'
  },
  pricetxt1: {
    color: Colors.whiteColor,
    fontSize: mobileW * 3.4 / 100,
    fontFamily: Font.FontMedium,
    textAlign: 'center'
  },
  activetabstyle: {
    color: Colors.whiteColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    paddingVertical: mobileW * 1 / 100,
    marginTop: mobileH * 0.5 / 100
  },
  inactivetabstyle: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    paddingVertical: mobileW * 1 / 100,
    marginTop: mobileH * 0.5 / 100
  },
  tabstyle: {
    color: Colors.whiteColor,
    fontFamily: Font.FontRegular,
    fontSize: mobileW * 3 / 100,
    textAlign: config.textalign,
    alignSelf: 'center',
    paddingVertical: mobileW * 1.2 / 100,
  },
  DownArrowStyle: {
    height: mobileH * 1 / 100,
    width: mobileW * 2 / 100,
    marginLeft: mobileW * 2 / 100
  },
  TextStyle: {
    fontSize: mobileW * 3.8 / 100,
    fontFamily: Font.FontSemiBold,
    color: Colors.whiteColor
  },
  SliderText: {
    fontSize: mobileW * 4 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.whiteColor
  },
  OverbookTabtxt: {
    fontSize: mobileW * 3.5 / 100,
    fontFamily: Font.FontSemiBold,
    marginLeft: mobileW * 4 / 100,
    color: Colors.PnlTextColor
  },
  ThreeButtonText: {
    fontSize: mobileW * 3 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    textAlignVertical: 'center'
  },
  ThreeButtonView: {
    height: mobileH * 2.5 / 100,
    width: mobileW * 9 / 100,
    justifyContent: 'center',
    marginTop: mobileH * 2 / 100,
    borderWidth: mobileW * 0.3 / 100,
    marginRight: mobileW * 2 / 100
  },
  FlatelistHeaderTxtView:
  {
    width: mobileW * 30 / 100,
  },
  FlatelistHeaderTxtView1:
  {
    width: mobileW * 26 / 100,
  },
  FlatelistHeaderTxt:
  {
    fontSize: mobileW * 3.5 / 100,
    fontFamily: Font.FontSemiBold,
    color: Colors.PnlTextColor,
  },
  FlatelistTxtView: {
    width: mobileW * 20 / 100,
  },
  FlatelistTxt: {
    fontSize: mobileW * 3 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'left'
  },
  BuySellButtonView:
  {
    height: mobileH * 5.5 / 100,
    width: mobileW * 40 / 100,
    justifyContent: 'center',
  },
  BuySellButtonTxt:
  {
    fontSize: mobileW * 4.5 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.whiteColor
  },

  //   -------ModelTxt-------
  activetabstyle1: {
    color: Colors.whiteColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    textAlign: config.textalign,
    alignSelf: 'center',
    paddingVertical: mobileW * 0.8 / 100,
  },
  inactivetabstyle1: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    textAlign: config.textalign,
    alignSelf: 'center',
    paddingVertical: mobileW * 0.8 / 100,
  },
  AvailableBalancetxt: {
    fontSize: mobileW * 4.5 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.whiteColor
  },
  MarginUsedPertxtView: {
    height: mobileH * 3 / 100,
    paddingHorizontal: mobileW * 1 / 100,
    justifyContent: 'center',
    borderWidth: mobileW * 0.3 / 100,
    borderColor: Colors.PnlTextColor,

  },
  MarginUsedPertxt: {
    fontSize: mobileW * 3 / 100,
    fontFamily: Font.FontRegular,
    color: Colors.whiteColor
  },
  MarginUsedCounttxt: {
    fontSize: mobileW * 6 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.whiteColor
  },
  Bottomtxt: {
    fontSize: mobileW * 3.2 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.PnlTextColor,
    marginLeft: mobileW * 2 / 100
  },
  Bottomtxt1: {
    fontSize: mobileW * 3.2 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.whiteColor
  },
  ProfitlossView: {
    height: mobileH * 5 / 100,
    width: mobileW * 28 / 100,
    justifyContent: 'center',
    backgroundColor: Colors.ModelInsideButton,
    marginTop: mobileH * 0.5 / 100
  },
  ProfitlossTxt: {
    fontSize: mobileW * 3 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
    color: Colors.PnlTextColor
  },

})




