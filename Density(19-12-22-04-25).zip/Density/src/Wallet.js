import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity, consolepro } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appsmallbutton } from './AllComponents';
import { Appbutton } from './AllComponents';


export default class Wallet extends Component {
  constructor(props) {
    super(props)
    this.state = {
      BuyOrderModel: false,
      AdjustMarginmodel: false,
      activePage: 0,

      RadioArr: [
        {
          'id': '0',
          'Name': '1Day',
          'statusRadio': false
        },
        {
          'id': '1',
          'Name': '1Week',
          'statusRadio': false
        },
        {
          'id': '2',
          'Name': '1Month',
          'statusRadio': true
        },
        {
          'id': '3',
          'Name': '3Months',
          'statusRadio': false
        },
        {
          'id': '2',
          'Name': 'Custom',
          'statusRadio': false
        },
      ],

      BTCUSDTArr: [
        {
          'id': '0',
          'Name': 'Deposit',
          'DateTime': '20 Sep 2022 | 01:07PM',
          'ReferenceId': '4444',
          'Price': '+₹2,500',
          'Status': 'Completed'
        },
        {
          'id': '1',
          'Name': 'Deposit',
          'DateTime': '20 Sep 2022 | 01:07PM',
          'ReferenceId': '4444',
          'Price': '+₹2,500',
          'Status': 'Failed'
        },
        {
          'id': '2',
          'Name': 'Withdrow',
          'DateTime': '20 Sep 2022 | 01:07PM',
          'ReferenceId': '4444',
          'Price': '+₹2,500',
          'Status': 'Failed'
        }
      ]
    }
  }
  componentDidMount() {

  }

  Select_btn = (item, index) => {
    //consolepro.consolelog({ item, index })
    let data1 = this.state.RadioArr;
    //consolepro.consolelog('data1', data1)
    for (let i = 0; i < data1.length; i++) {
      data1[i].statusRadio = false;
    }
    data1[index].statusRadio = true;
    {
      this.setState({
        RadioArr: data1,
      })
    }
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
        <SafeAreaView style={styles.container}>
          <StatusBar
            hidden={false}
            translucent={false}
            barStyle="light-content"
            networkActivityIndicatorVisible={true}
            backgroundColor={Colors.statusbarcolor}
          />
          <KeyboardAwareScrollView
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

            {/* //==========Get Started Now Text=========// */}

            <View style={{
              width: mobileW * 90 / 100,
              alignSelf: 'center',
            }}>

              {/* ===================conditional========================= */}
              <View style={{
                flexDirection: "row",
                alignItems: 'center',
                width: mobileW * 95 / 100,
                alignSelf: 'center',
                marginTop: mobileW * 10 / 100,
                justifyContent: 'center'
              }}>
                <TouchableOpacity
                  style={[styles.INRUSDTWallettxtView,
                  { backgroundColor: this.state.activePage == 0 ? Colors.whiteColor : Colors.TogglebuttonBack }
                  ]}
                  activeOpacity={0.8}
                  onPress={() => { this.setState({ activePage: 0 }) }}
                >
                  <Text
                    style={[styles.INRUSDTWallettxt, { color: this.state.activePage == 0 ? Colors.black_color : Colors.whiteColor }
                    ]}
                  >
                    {Lang_chg.INRWALLET[config.language]}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.INRUSDTWallettxtView, {
                    backgroundColor: this.state.activePage == 1 ? Colors.whiteColor : Colors.TogglebuttonBack
                  }]}
                  activeOpacity={0.8}
                  onPress={() => { this.setState({ activePage: 1 }) }}
                >
                  <Text style={[styles.INRUSDTWallettxt, { color: this.state.activePage == 1 ? Colors.black_color : Colors.whiteColor }]}
                  >
                    {Lang_chg.USDTWALLET[config.language]}
                  </Text>
                </TouchableOpacity>
              </View>

              {this.state.activePage == 0 ?
                <View>
                  <View style={{
                    width: mobileW * 90 / 100,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginTop: mobileH * 6 / 100
                  }}>
                    <Text style={{
                      color: Colors.whiteColor,
                      fontSize: mobileW * 4.6 / 100,
                      fontFamily: Font.FontBold,
                      width: mobileW * 45 / 100
                    }}>{Lang_chg.TotalINRBalance[config.language]}
                    </Text>
                    <Text style={{
                      color: Colors.whiteColor,
                      fontSize: mobileW * 3.3 / 100,
                      fontFamily: Font.FontBold,
                    }}>{'₹12,3459'}
                    </Text>
                  </View>

                  <View style={{
                    borderBottomWidth: mobileW * 0.5 / 100,
                    borderBottomColor: Colors.BorderColor,
                    marginTop: mobileW * 5 / 100,
                    width: mobileW * 90 / 100,
                    alignSelf: 'center'
                  }}></View>

                  {/* ------------Buttons------------- */}
                  <View style={[styles.justifyContentStyle, { marginVertical: mobileH * 1 / 100, paddingTop: mobileH * 1 / 100, width: mobileW * 89.5 / 100 }]}>
                    <TouchableOpacity
                      onPress={() => { this.props.navigation.navigate('Deposit') }}
                      activeOpacity={0.7} style={[styles.DepostWithdrowtxtView, { backgroundColor: Colors.whiteColor }]}>
                      <Text style={[styles.DepostWithdrowtxt, { color: Colors.black_color }]}>{Lang_chg.Deposit[config.language]}
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() => { this.props.navigation.navigate('Withdraw') }}
                      activeOpacity={0.7} style={[styles.DepostWithdrowtxtView, {}]}>
                      <Text style={[styles.DepostWithdrowtxt, { color: Colors.whiteColor }]}>{Lang_chg.Withdraw[config.language]}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
                :
                <View>
                  <View
                    style={{
                      marginTop: mobileH * 2 / 100,
                      width: '99.5%',
                      alignSelf: 'center',
                      borderWidth: mobileW * 0.5 / 100,
                      borderColor: Colors.BorderColor,
                      backgroundColor: Colors.CartBackColor,
                    }}>
                    <View style={{ paddingVertical: mobileH * 2 / 100 }}>
                      <Text style={{
                        color: Colors.PnlTextColor,
                        fontFamily: Font.FontSemiBold,
                        fontSize: mobileW * 3.5 / 100,
                        marginTop: mobileW * 1.4 / 100,
                        textAlign: 'center'
                      }}>{Lang_chg.TotalMarginBalance[config.language]}
                      </Text>
                      <Text style={{
                        color: Colors.whiteColor,
                        fontFamily: Font.FontSemiBold,
                        fontSize: mobileW * 6 / 100,
                        marginTop: mobileW * 1.4 / 100,
                        textAlign: 'center'
                      }}>{'$40,000'}
                      </Text>
                      <Text style={{
                        color: Colors.GreenText,
                        fontFamily: Font.FontSemiBold,
                        fontSize: mobileW * 3.2 / 100,
                        marginTop: mobileW * 1.4 / 100,
                        textAlign: 'center'
                      }}>{'+$23.71 (5.38%)'}
                      </Text>
                    </View>

                    <View style={{
                      borderBottomWidth: mobileW * 0.5 / 100,
                      borderBottomColor: Colors.BorderColor,
                      marginTop: mobileW * 5 / 100,
                      width: mobileW * 90 / 100,
                      alignSelf: 'center'
                    }}></View>

                    <View style={[styles.justifyContentStyle, { width: mobileW * 88 / 100, alignItems: 'center' }]}>
                      <View style={{
                        width: mobileW * 43 / 100,
                        borderRightWidth: mobileW * 0.5 / 100,
                        borderRightColor: Colors.BorderColor,
                        paddingVertical: mobileH * 3 / 100,
                      }} >
                        <Text style={[styles.MarginRealisedtxt, {}]}>{Lang_chg.FreeMarginBalance[config.language]}
                        </Text>
                        <Text style={[styles.MarginRealisedtxt1, { paddingBottom: mobileH * 1 / 100 }]}>{'$1,285'}
                        </Text>
                      </View>

                      <View style={{
                        width: mobileW * 43 / 100,
                        marginTop: mobileH * 1 / 100
                      }} >
                        <Text style={[styles.MarginRealisedtxt, { marginTop: mobileH * 1.4 / 100 }]}>{Lang_chg.Realised24HPnl[config.language]}
                        </Text>
                        <Text style={[styles.MarginRealisedtxt1, {}]}>{'$11,091.10'}
                        </Text>
                        <Text style={{
                          color: Colors.GreenText,
                          fontFamily: Font.FontSemiBold,
                          fontSize: mobileW * 3 / 100,
                          marginTop: mobileW * 0.2 / 100,
                          textAlign: 'center'
                        }}>{'9.88%'}
                        </Text>
                      </View>
                    </View>
                  </View>

                  {/* BuyUsdt and SellUsdt button */}
                  <View style={[styles.justifyContentStyle, { marginTop: mobileH * 2 / 100, width: mobileW * 89.5 / 100 }]}>
                    {/* ----------BuyUsdt button---------- */}
                    <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('BuyUSDT')}
                      activeOpacity={0.7} style={[styles.DepostWithdrowtxtView, { backgroundColor: Colors.whiteColor }]}>
                      <Text style={[styles.DepostWithdrowtxt, { color: Colors.black_color }]}>{Lang_chg.BuyUsdt[config.language]}
                      </Text>
                    </TouchableOpacity>
                    {/* ------------SellUsdt button------------ */}
                    <TouchableOpacity
                      onPress={() => this.props.navigation.navigate('SellUSDT')}
                      activeOpacity={0.7} style={[styles.DepostWithdrowtxtView, {}]}>
                      <Text style={[styles.DepostWithdrowtxt, { color: Colors.whiteColor }]}>{Lang_chg.SellUsdt[config.language]}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              }

              {/* -----------TransactionHistory---------- */}
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: mobileH * 2 / 100,
                }} >
                <View
                  style={[styles.justifyContentStyle, { width: mobileW * 89 / 100, alignItems: 'center' }]}>
                  <View>
                    <Text style={{
                      color: Colors.whiteColor,
                      fontFamily: Font.FontSemiBold,
                      fontSize: mobileW * 4.3 / 100
                    }}>
                      {Lang_chg.TransactionHistory[config.language]}
                    </Text>
                    <View style={{
                      width: mobileW * 33 / 100,
                      backgroundColor: Colors.yellow_color,
                      borderColor: Colors.yellow_color,
                      borderWidth: mobileW * 0.9 / 100
                    }}>
                    </View>
                  </View>
                  <View>
                    <Image style={{
                      height: mobileH * 3.1 / 100,
                      width: mobileW * 6.2 / 100,
                      marginTop: mobileH * 1 / 100
                    }}
                      source={localimag.YellowSearchIcon}>
                    </Image>
                  </View>
                </View>
              </View>

              <Text style={{
                color: Colors.PnlTextColor,
                fontFamily: Font.FontSemiBold,
                fontSize: mobileW * 3.5 / 100,
                marginTop: mobileW * 1.4 / 100
              }}>{Lang_chg.LoremIpsumElitText[config.language]}</Text>

              {/* --------------RadioButtons-------------- */}
              <View>
                <FlatList
                  data={this.state.RadioArr
                  }
                  horizontal={true}
                  contentContainerStyle={{}}
                  showsHorizontalScrollIndicator={false}
                  showsVerticalScrollIndicator={false}
                  renderItem={({ item, index }) => {
                    return (
                      <TouchableOpacity
                        style={[styles.justifyContentStyle, {
                          marginTop: mobileW * 8 / 100,
                          paddingRight: mobileW * 5 / 100, alignItems: 'center'
                        }]}>
                        <TouchableOpacity activeOpacity={0.7}
                          onPress={() => this.Select_btn(item, index)}>
                          <Image source={item.statusRadio == true ? localimag.YellowRadioActice : localimag.RadioInactice}
                            style={{ height: mobileW * 5 / 100, width: mobileW * 5 / 100 }} />
                        </TouchableOpacity>
                        <Text style={{
                          color: item.statusRadio == true ? Colors.whiteColor : Colors.PnlTextColor,
                          fontFamily: Font.FontSemiBold,
                          fontSize: mobileW * 3 / 100,
                          marginLeft: mobileW * 2 / 100,
                          paddingTop: mobileH * 0.2 / 100
                        }}>{item.Name}
                        </Text>
                      </TouchableOpacity>
                    )
                  }}
                />
              </View>

              <View style={{
                borderBottomWidth: mobileW * 0.5 / 100,
                borderBottomColor: Colors.BorderColor,
                marginTop: mobileW * 5 / 100,
                width: mobileW * 100 / 100,
                alignSelf: 'center'
              }}></View>

              <View>
                {/* ------------------Flatelist-------------------- */}
                <FlatList
                  data={this.state.BTCUSDTArr
                  }
                  contentContainerStyle={{ paddingBottom: mobileH * 15 / 100 }}
                  renderItem={({ item, index }) => {
                    console.log('item', item)
                    return (
                      <View
                        style={{
                          marginTop: mobileH * 1 / 100,
                          width: '99.5%',
                          alignSelf: 'center',
                        }}>

                        <TouchableOpacity
                          onPress={() => this.props.navigation.navigate('Portfolio')}
                          style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, paddingVertical: mobileH * 1 / 100 }]}>
                          <View style={{ width: mobileW * 60 / 100, }}>
                            <View style={{}}>
                              <Text style={{
                                color: Colors.whiteColor,
                                fontSize: mobileW * 3.6 / 100,
                                fontFamily: Font.FontMedium,
                                paddingVertical: mobileH * 0.2 / 100,
                              }}>{item.Name}
                              </Text>
                            </View>
                            <Text style={{
                              color: Colors.PnlTextColor,
                              fontSize: mobileW * 3 / 100,
                              fontFamily: Font.FontSemiBold,
                            }}>{item.DateTime}
                            </Text>
                            <Text style={{
                              color: Colors.PnlTextColor,
                              fontSize: mobileW * 3 / 100,
                              fontFamily: Font.FontSemiBold,
                            }}>{Lang_chg.ReferenceId[config.language]}<Text>{item.ReferenceId}
                              </Text>
                            </Text>
                          </View>

                          <View style={{
                            width: mobileW * 25 / 100,
                            flexDirection: 'row',
                            backgroundColor: 'Green',
                            justifyContent: 'flex-end'
                          }}>
                            <View>
                              <View style={{}}>
                                <Text style={{
                                  color: Colors.whiteColor,
                                  fontSize: mobileW * 4.3 / 100,
                                  fontFamily: Font.FontSemiBold,
                                  textAlign: 'right'
                                }}>{item.Price}
                                </Text>
                              </View>
                              <View style={{
                                backgroundColor: item.Status == 'Failed' ? Colors.OrangeColor : Colors.GreenButton,
                                marginTop: mobileH * 0.5 / 100
                              }}>
                                <Text style={{
                                  color: Colors.whiteColor,
                                  fontSize: mobileW * 3.3 / 100,
                                  fontFamily: Font.FontMedium,
                                  paddingHorizontal: mobileW * 2 / 100,
                                  textAlign: 'center'
                                }}>{item.Status}
                                </Text>
                              </View>
                            </View>
                          </View>
                        </TouchableOpacity>

                        <View style={{
                          borderBottomWidth: mobileW * 0.5 / 100,
                          borderBottomColor: Colors.BorderColor,
                          marginTop: mobileW * 4 / 100,
                          width: mobileW * 88 / 100,
                          alignSelf: 'center'
                        }}></View>

                      </View>
                    )
                  }}
                />
              </View>
            </View>

            {/* ---------------Model--------------- */}
            <Modal
              animationType="slide"
              transparent
              visible={this.state.BuyOrderModel}
              onRequestClose={() => {
              }}>
              <View
                style={{
                  flex: 1,
                  backgroundColor: '#00000090',
                  alignItems: 'center',
                  justifyContent: 'center',
                  // bottom:-mobileH*2/100,
                  borderRadius: 0,
                }}>
                <View style={{
                  backgroundColor: Colors.ModelColor,
                  width: mobileW * 80 / 100,
                  paddingVertical: mobileH * 2 / 100
                }}>
                  <View style={{
                    paddingVertical: mobileH * 2 / 100,
                    alignSelf: 'center'
                  }}>
                    <View style={{
                      width: mobileW * 70 / 100,
                      alignSelf: 'center',
                      alignItems: 'center'
                    }}>
                      <Image style={{
                        height: mobileH * 6 / 100,
                        width: mobileW * 12 / 100,
                        marginTop: mobileH * 1 / 100
                      }}
                        source={localimag.ErrorIcon}>
                      </Image>
                      <Text style={{
                        marginLeft: mobileW * 1 / 100,
                        fontSize: mobileW * 3.5 / 100,
                        fontFamily: Font.FontMedium,
                        paddingTop: mobileH * 2 / 100,
                        color: Colors.whiteColor,
                        textAlign: 'center'
                      }}>{Lang_chg.BuyOrderModelText1}
                      </Text>
                      <Text style={{
                        fontFamily: Font.FontBold,
                        color: Colors.whiteColor,
                        paddingTop: mobileH * 1 / 100
                      }}>{Lang_chg.BuyOrderModelText2} <Text>{Lang_chg.BuyOrderModelText3}
                        </Text>
                      </Text>

                      <Text style={{
                        fontSize: mobileW * 4 / 100,
                        fontFamily: Font.FontMedium,
                        color: Colors.whiteColor,
                        textAlign: 'center'
                      }}>{Lang_chg.ExitToModel}
                      </Text>
                    </View>

                    <View style={{
                      marginVertical: mobileH * 1 / 100,
                      paddingTop: mobileH * 3 / 100,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      width: mobileW * 74 / 100,
                      alignSelf: 'center',
                    }}>
                      <TouchableOpacity
                        onPress={() => { this.setState({ BuyOrderModel: 'false' }) }}
                        activeOpacity={0.7} style={{
                          backgroundColor: Colors.ModelColor,
                          borderWidth: mobileW * 0.5 / 100,
                          borderColor: Colors.whiteColor,
                          height: mobileH * 5 / 100,
                          width: mobileW * 35 / 100,
                          justifyContent: 'center',
                        }}>
                        <Text style={{
                          fontSize: mobileW * 4.5 / 100,
                          fontFamily: Font.FontSemiBold,
                          textAlign: 'center',
                          color: Colors.whiteColor
                        }}>{Lang_chg.canada_txt[config.language]}
                        </Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        onPress={() => { this.props.navigation.navigate('PositionsAfterModel'), this.setState({ BuyOrderModel: 'false' }) }}
                        activeOpacity={0.7} style={{
                          backgroundColor: Colors.whiteColor,
                          borderWidth: mobileW * 0.5 / 100,
                          borderColor: Colors.whiteColor,
                          height: mobileH * 5 / 100,
                          width: mobileW * 35 / 100,
                          justifyContent: 'center',
                        }}>
                        <Text style={{
                          fontSize: mobileW * 4.5 / 100,
                          fontFamily: Font.FontSemiBold,
                          textAlign: 'center',
                          color: Colors.black_color
                        }}>{Lang_chg.Confirm[config.language]}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            </Modal>

          </KeyboardAwareScrollView>

          <Footer
            activepage='Wallet'
            usertype={1}
            footerpage={[
              {
                name: 'Home',
                fname: 'Home',
                image: localimag.home_inactive,
                activeimage: localimag.home_active,
              },
              {
                name: 'Orders',
                fname: 'Orders', image: localimag.orders_inactive,
                activeimage: localimag.orders_active,
              },
              {
                name: 'Trade',
                fname: 'Trade',
                image: localimag.trade_inactive,
                activeimage: localimag.trade_active,
              },
              {
                name: 'Positions',
                fname: 'Positions',
                image: localimag.position_inactive,
                activeimage: localimag.position_active,
              },
              {
                name: 'Wallet',
                fname: 'Wallet', image: localimag.wallet_inactive,
                activeimage: localimag.wallet_active,
              },
            ]}
            navigation={this.props.navigation}
            imagestyle1={{
              width: mobileW * 6 / 100, height: mobileW * 6 / 100,
              backgroundColor: Colors.themeblack_color,
              countcolor: Colors.white_color,
            }}
          />
        </SafeAreaView >
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: Colors.themeblack_color
  },
  justifyContentStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignSelf: 'center'
  },
  INRUSDTWallettxtView:
  {
    height: mobileH * 5 / 100,
    width: mobileW * 30 / 100,
    justifyContent: 'center',
    borderWidth: mobileW * 0.3 / 100,
    borderColor: Colors.whiteColor,
  },
  INRUSDTWallettxt: {
    color: Colors.whiteColor,
    fontSize: mobileW * 3.3 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
  },
  DepostWithdrowtxtView: {
    height: mobileH * 5.5 / 100,
    width: mobileW * 43 / 100,
    justifyContent: 'center',
    borderWidth: mobileW * 0.3 / 100,
    borderColor: Colors.whiteColor
  },
  DepostWithdrowtxt: {
    fontSize: mobileW * 4.5 / 100,
    fontFamily: Font.FontSemiBold,
    textAlign: 'center',
  },
  MarginRealisedtxt: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 3.5 / 100,
    textAlign: 'center'
  },
  MarginRealisedtxt1: {
    color: Colors.whiteColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    marginTop: mobileW * 0.2 / 100,
    textAlign: 'center',
  },
  BuySellButtonnView: {
    height: mobileH * 5 / 100,
    width: mobileW * 42.5 / 100,
    borderColor: Colors.white_color,
    borderWidth: mobileW * 0.3 / 100,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  BuySellButtonntxt: {
    fontFamily: Font.FontBold,
    fontSize: mobileW * 3.75 / 100
  }



})



