import React, { Component } from 'react'
import { Text, SafeAreaView, TouchableOpacity, StatusBar, View, StyleSheet, Image, } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';


export default class ConfirmEmail extends Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar
          hidden={false}
          translucent={false}
          barStyle="light-content"
          networkActivityIndicatorVisible={true}
        />

        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

          {/* //==========Image & density Text=========// */}
          <View style={{
            width: mobileW * 90 / 100,
            alignItems: 'center',
            alignSelf: 'center',
            flexDirection: 'row', justifyContent: 'space-between'
          }}>
            <View style={{
              width: mobileW * 70 / 100,
              alignSelf: 'center', flexDirection: 'row', marginTop: mobileH * 3 / 100, alignItems: 'center'
            }}>
              <Image style={{
                width: mobileW * 5.5 / 100,
                height: mobileW * 5.5 / 100
              }}
                resizeMode='contain'
                source={localimag.splashlogo}></Image>
              <View style={{ paddingHorizontal: mobileW * 1 / 100, }}>
                <Text style={{
                  color: Colors.yellow_color,
                  fontSize: mobileW * 7 / 100,
                  fontFamily: Font.FontSemiBold
                }}>{Lang_chg.density_txt[config.language]}</Text>
              </View>
            </View>
          </View>
          {/* //===============Image==============// */}
          <View style={{
            width: mobileW * 90 / 100,
            alignSelf: 'center',
            flexDirection: 'row',
            justifyContent: 'center',
            marginTop: mobileH * 10 / 100,
            alignItems: 'center'
          }}>
            <Image style={{
              width: mobileW * 90 / 100,
              height: mobileW * 90 / 100
            }} resizeMode='cover'
              source={localimag.illustration}></Image>

          </View>
          <View style={{
            width: mobileW * 90 / 100,
            alignSelf: 'center',
            alignItems: 'center',
            marginTop: mobileH * 7 / 100
          }}>
            <Text style={{
              color: Colors.whiteColor,
              fontFamily: Font.FontSemiBold,
              fontSize: mobileW * 9 / 100
            }}>
              {Lang_chg.confirm_your_txt[config.language]}
            </Text>
          </View>
          <View
            style={{
              alignItems: 'center',
              alignSelf: 'center',
              flexDirection: 'row',
              marginTop: mobileH * 2 / 100,
              marginBottom: mobileH * 4 / 100
            }} >
            <Text style={{
              color: Colors.TermsColor,
              fontFamily: Font.FontSemiBold,
              fontSize: mobileW * 4 / 100
            }}>{Lang_chg.I_didnt_receive_txt[config.language]}</Text>
            <TouchableOpacity
              onPress={() => this.props.navigation.navigate('RegisterPhone')}
              activeOpacity={0.7}
              style={{
                marginLeft: mobileW * 1 / 100
              }}>
              <Text style={{
                color: Colors.yellow_color,
                fontFamily: Font.FontBold,
                fontSize: mobileW * 4 / 100
              }}>{Lang_chg.send_again_txt[config.language]}</Text>
              <View style={{
                width: mobileW * 22 / 100, justifyContent: 'center',
                alignSelf: 'center',
                borderColor: Colors.BorderColor,
                borderWidth: mobileW * 0.2 / 100
              }}>
              </View>
            </TouchableOpacity>
          </View>
        </KeyboardAwareScrollView>
      </SafeAreaView>
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.themeblack_color


  },
  view1:
  {
    backgroundColor: Colors.themeblack_color,
    height: mobileH * 8 / 100,

    flexDirection: 'row',
    width: mobileW * 88 / 100,
    alignSelf: 'center',
    alignItems: 'center',

  },

  icon1s: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    resizeMode: 'contain', alignSelf: 'center'
  },

})
