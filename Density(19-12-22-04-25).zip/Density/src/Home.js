import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

export default class Home extends Component {

  constructor(props) {
    super(props)
    this.state = {
      scripts: [
        {
          title: Lang_chg.highest_24h_turnover_txt[config.language],
          scriptName: Lang_chg.ethereum_txt[config.language], currency: Lang_chg.usdt_txt[config.language],
          rise_percent: Lang_chg.rise_percent2[config.language]
        },
        {
          title: Lang_chg.highest_24h_turnover_txt[config.language],
          scriptName: Lang_chg.ethereum_txt[config.language], currency: Lang_chg.usdt_txt[config.language],
          rise_percent: Lang_chg.rise_percent2[config.language]
        },
      ],
      script_arr_all: [
        {
          scriptName: Lang_chg.Bitcoin_txt[config.language],
          volume: Lang_chg.vol_562b_text[config.language],
          starImage: localimag.star_fill,
          scriptImage: localimag.market_2,
          currency: Lang_chg.inr_txt[config.language],
          arrow: localimag.red_dropdown,
          color_rise: Colors.OrangeColor,
          rise_percent: Lang_chg.rise_percent[config.language]
        },
        {
          scriptName: Lang_chg.solana_text[config.language],
          volume: Lang_chg.vol_562b_text[config.language],
          starImage: localimag.star_unfill,
          scriptImage: localimag.market_3,
          arrow: localimag.green_dropdown,
          currency: Lang_chg.usdt_txt[config.language],
          color_rise: Colors.green_type_color,
          rise_percent: Lang_chg.rise_percent[config.language]
        },
        {
          scriptName: Lang_chg.ethereum_txt[config.language],
          volume: Lang_chg.vol_562b_text[config.language],
          starImage: localimag.star_fill,
          scriptImage: localimag.market_1,
          currency: Lang_chg.usdt_txt[config.language],
          arrow: localimag.red_dropdown,
          color_rise: Colors.OrangeColor,
          rise_percent: Lang_chg.rise_percent[config.language]
        },
        {
          scriptName: Lang_chg.ethereum_txt[config.language],
          volume: Lang_chg.vol_562b_text[config.language],
          starImage: localimag.star_fill,
          scriptImage: localimag.market_1,
          currency: Lang_chg.usdt_txt[config.language],
          arrow: localimag.red_dropdown,
          color_rise: Colors.OrangeColor,
          rise_percent: Lang_chg.rise_percent[config.language]
        },
      ]
    }
  }
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
        <SafeAreaView style={styles.container}>
          <StatusBar
            hidden={false}
            translucent={false}
            barStyle="light-content"
            networkActivityIndicatorVisible={true}
            backgroundColor={Colors.statusbarcolor}
          />

          {/* //========== density Text and wallet image=========// */}
          <View style={{
            width: mobileW * 90 / 100,
            alignItems: 'center',
            alignSelf: 'center',
            flexDirection: 'row',
            justifyContent: 'space-between'
          }}>

            {/* -------density Text------- */}
            <View style={{
              width: mobileW * 70 / 100,
              alignSelf: 'center',
              flexDirection: 'row',
              marginTop: mobileH * 2 / 100,
              alignItems: 'center'
            }}>
              <Image style={{
                width: mobileW * 4.5 / 100,
                height: mobileW * 4.5 / 100
              }}
                resizeMode='contain' source={localimag.splashlogo}></Image>

              <View style={{ paddingHorizontal: mobileW * 2 / 100, }}>
                <Text style={{
                  color: Colors.yellow_color,
                  fontSize: mobileW * 5.3 / 100,
                  fontFamily: Font.FontSemiBold
                }}>{Lang_chg.density_txt[config.language]}</Text>
              </View>
            </View>
            {/*----- wallet image------ */}
            <View style={{
              alignSelf: 'center',
              flexDirection: 'row',
              marginTop: mobileH * 3 / 100,
              alignItems: 'center',
              left: mobileW * 2 / 100
            }}>
              <Image style={{
                width: mobileW * 7 / 100,
                height: mobileW * 7 / 100
              }}
                resizeMode='contain'
                source={localimag.wallet_bg}></Image>
              <View style={{ paddingHorizontal: mobileW * 2 / 100, }}>
                <Image style={{
                  width: mobileW * 7 / 100,
                  height: mobileW * 7 / 100,
                  left: mobileW * 2 / 100
                }} resizeMode='contain'
                  source={localimag.person_bg}></Image>
              </View>
            </View>
          </View>

          <KeyboardAwareScrollView
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

            {/* //==========Order Text=========// */}

            <View style={{
              flexDirection: 'row',
              marginTop: mobileH * 2 / 100,
              marginBottom: mobileH * 2 / 100,
              width: mobileW * 90 / 100,
              alignSelf: 'center'
            }}>
              <View
                style={{
                }}>
                <Text style={{
                  color: Colors.whiteColor,
                  fontFamily: Font.FontSemiBold,
                  fontSize: mobileW * 6.3 / 100,
                }}>
                  {Lang_chg.market_txt[config.language]}
                </Text>
                <View style={{
                  width: mobileW * 15 / 100,
                  backgroundColor: Colors.yellow_color,
                  borderColor: Colors.yellow_color,
                  borderWidth: mobileW * 0.7 / 100
                }}>
                </View>
              </View>
            </View>

            {/* lorem ispum heading */}
            <View style={{
              width: mobileW * 90 / 100,
              alignSelf: 'center',
              flexDirection: 'row',
            }}>
              <View style={{}}>
                <Text style={{
                  color: Colors.text_color3,
                  fontSize: mobileW * 3.5 / 100,
                  fontFamily: Font.FontSemiBold
                }}>
                  {Lang_chg.lorem_ipsum_dolot_txt[config.language]}
                </Text>
              </View>
            </View>

            {/* --------Cart FlatList horizontal-------- */}

            <FlatList
              showsHorizontalScrollIndicator={false}
              horizontal={true}
              data={this.state.scripts}
              contentContainerStyle={{
              }}
              renderItem={({ item, index }) =>
                <View style={{
                  width: mobileW * 70 / 100,
                  marginHorizontal: mobileW * 5 / 100,
                  marginTop: mobileH * 1.5 / 100,

                }}>
                  {/* faltlist box */}
                  <View style={{
                    width: mobileW * 70 / 100,
                    paddingHorizontal: mobileW * 5 / 100,
                    backgroundColor: Colors.CartBackColor,
                    paddingTop: mobileH * 1.25 / 100,
                    paddingBottom: mobileH * 1 / 100,
                    borderColor: Colors.BorderColor,
                    borderWidth: mobileW * 0.2 / 100
                  }}>
                    <Text style={{
                      color: Colors.placeholder_color,
                      fontSize: mobileW * 4.5 / 100,
                      fontFamily: Font.FontSemiBold
                    }}>
                      {item.title}
                    </Text>

                    {/* border below highest 24 hr turnover */}
                    <View style={{
                      marginTop: mobileH * 0.6 / 100,
                      borderBottomWidth: 1,
                      borderColor: Colors.BorderColor,
                      width: mobileW * 60 / 100,
                      alignSelf: 'center',
                    }}>
                    </View>

                    {/* etherium and its image and % rise */}
                    <View style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: mobileW * 60 / 100,
                    }}>

                      {/* etherium and its image*/}
                      <View style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        width: mobileW * 51 / 100,
                      }}>
                        <Image style={{
                          width: mobileW * 4.3 / 100,
                          height: mobileW * 8.5 / 100
                        }} resizeMode='contain'
                          source={localimag.market_1}>
                        </Image>
                        <Text
                          numberOfLines={1}
                          style={{
                            marginLeft: mobileW * 1 / 100,
                            color: Colors.placeholder_color,
                            fontSize: mobileW * 4 / 100,
                            fontFamily: Font.FontSemiBold
                          }}>
                          {Lang_chg.ethereum_txt[config.language]}</Text>

                        {/* currency usdt  */}
                        <View style={{
                          marginLeft: mobileW * 1 / 100,
                          alignItems: 'center'
                        }}>
                          <Text style={{
                            color: Colors.placeholder_color,
                            backgroundColor: Colors.usdt_bg,
                            fontSize: mobileW * 2.25 / 100,
                            fontFamily: Font.FontMedium,
                            paddingHorizontal: mobileW * 1 / 100,
                            borderColor: Colors.placeholder_color,
                            borderWidth: mobileW * 0.1 / 100
                          }}>
                            {Lang_chg.usdt_txt[config.language]}
                          </Text>
                        </View>
                      </View>

                      {/* % rise in script*/}
                      <Text style={{
                        color: Colors.green_type_color,
                        fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontSemiBold
                      }}>
                        {item.rise_percent}
                      </Text>

                    </View>

                    {/* price */}
                    <View style={{
                      justifyContent: 'center',
                      width: mobileW * 60 / 100,
                    }}>
                      <Text style={{
                        color: Colors.placeholder_color,
                        fontSize: mobileW * 4.5 / 100,
                        fontFamily: Font.FontSemiBold
                      }}>
                        {'$1,234.56'}
                      </Text>
                    </View>

                    {/* volume */}
                    <View style={{
                      alignSelf: 'center',
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: mobileW * 60 / 100,
                    }}>
                      <Text style={{
                        color: Colors.yellow_color,
                        fontSize: mobileW * 3 / 100,
                        fontFamily: Font.FontSemiBold
                      }}>
                        24h {Lang_chg.Volume[config.language]}
                      </Text>

                      <View style={{ paddingHorizontal: mobileW * 2 / 100, }}>
                        <Text style={{
                          color: Colors.placeholder_color,
                          fontSize: mobileW * 3 / 100,
                          fontFamily: Font.FontSemiBold
                        }}>
                          2,51.7M({Lang_chg.usdt_txt[config.language]}) </Text>
                      </View>
                    </View>
                  </View>
                </View>
              }></FlatList>

            {/*------------- All and favourite----------- */}
            <View style={{
              flexDirection: 'row',
              marginTop: mobileH * 4 / 100,
              marginBottom: mobileH * 1 / 100,
              width: mobileW * 90 / 100,
              alignSelf: 'center',
            }} >

              {/* ----------All and favourite text---------- */}
              <View style={{
                flexDirection: 'row',
                width: mobileW * 83.5 / 100,
                alignContent: 'center',
                alignItems: 'center',
              }}>
                <Text style={{
                  color: Colors.black_color,
                  backgroundColor: Colors.whiteColor,
                  fontSize: mobileW * 4 / 100,
                  fontFamily: Font.FontMedium,
                  paddingHorizontal: mobileW * 1.5 / 100,
                  paddingVertical: mobileW * 0.5 / 100,
                  borderColor: Colors.placeholder_color,
                }}>
                  {Lang_chg.all_text[config.language]}
                </Text>

                <Text style={{
                  marginLeft: mobileW * 3 / 100,
                  color: Colors.placeholder_color,
                  fontSize: mobileW * 4 / 100,
                  fontFamily: Font.FontMedium,
                  paddingHorizontal: mobileW * 1.5 / 100,
                  paddingVertical: mobileW * 0.5 / 100,
                  borderColor: Colors.placeholder_color,
                  borderWidth: mobileW * 0.2 / 100
                }}>
                  {Lang_chg.Favourites_txt[config.language]}
                </Text>
              </View>

              {/* search image */}
              <TouchableOpacity
                onPress={() => this.props.navigation.navigate('SearchHome')}
                style={{
                  alignItems: 'center',
                  flexDirection: 'row',
                  paddingHorizontal: mobileW * 1 / 100,
                  paddingTop: mobileH * 0.6 / 100
                }}>
                <Image style={{
                  width: mobileW * 5 / 100,
                  height: mobileW * 5 / 100,
                  tintColor: Colors.yellow_color
                }} resizeMode='contain'
                  source={localimag.searchwhite}></Image>
              </TouchableOpacity>
            </View>

            {/* border below all and fav */}
            <View style={{
              marginTop: mobileH * 1 / 100,
              borderBottomWidth: mobileW * 0.25 / 100,
              marginLeft: mobileW * 5 / 100,
              borderColor: Colors.greyColor,
              width: mobileW * 90 / 100,
            }}>
            </View>

            {/* ------script, its volume and price faltlist-------*/}

            <FlatList
              data={this.state.script_arr_all}
              contentContainerStyle={{
                paddingBottom: mobileH * 10 / 100,
              }}
              renderItem={({ item, index }) =>

                <View style={{ marginTop: mobileH * 2 / 100, }}>
                  <View style={{
                    flexDirection: 'row',
                    alignItems: 'flex-end',
                    width: mobileW * 90 / 100,
                    alignSelf: 'center',
                  }}>

                    {/* script and its image*/}

                    <View style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: mobileW * 75 / 100,
                    }}>

                      <Image style={{
                        width: mobileW * 4.5 / 100,
                        height: mobileW * 4.5 / 100
                      }} resizeMode='contain'
                        source={item.starImage}></Image>

                      <Image style={{
                        marginLeft: mobileW * 1.5 / 100,
                        marginRight: mobileW * 1.5 / 100,
                        width: mobileW * 7 / 100,
                        height: mobileW * 7 / 100
                      }} resizeMode='contain'
                        source={item.scriptImage}></Image>

                      <Text
                        numberOfLines={1}
                        style={{
                          color: Colors.placeholder_color,
                          fontSize: mobileW * 4 / 100,
                          fontFamily: Font.FontSemiBold
                        }}>
                        {item.scriptName}</Text>

                      {/* currency usdt  */}

                      <View style={{
                        marginLeft: mobileW * 1 / 100,
                      }}>
                        <Text style={{
                          color: Colors.placeholder_color,
                          alignSelf: 'center',
                          backgroundColor: Colors.usdt_bg,
                          fontSize: mobileW * 2.25 / 100,
                          fontFamily: Font.FontMedium,
                          paddingHorizontal: mobileW * 2 / 100,
                          paddingVertical: mobileH * 0.1 / 100,
                          borderRadius: mobileW * 0.5 / 100
                        }}>
                          {item.currency}
                        </Text>
                      </View>
                    </View>

                    {/*price of script*/}
                    <View style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: mobileW * 75 / 100,
                    }}>
                      <Text style={{
                        color: Colors.placeholder_color,
                        fontSize: mobileW * 3.25 / 100,
                        fontFamily: Font.FontSemiBold
                      }}>{'$1234.56'}
                      </Text>
                    </View>
                  </View>

                  <View style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginLeft: mobileW * 14.3 / 100,
                    width: mobileW * 75 / 100,
                    alignSelf: 'center'
                  }}>

                    {/* volume */}
                    <View style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      width: mobileW * 60 / 100,
                    }}>
                      <Text
                        numberOfLines={1}
                        style={{
                          color: Colors.PnlTextColor,
                          fontSize: mobileW * 3 / 100,
                          fontFamily: Font.FontSemiBold
                        }}>
                        {item.volume}</Text>
                    </View>

                    {/* % rise or fall in script*/}
                    <View style={{
                      flexDirection: 'row',
                      justifyContent: 'flex-end',
                      alignItems: 'center',
                      width: mobileW * 15 / 100
                    }}>
                      <Image style={{
                        width: mobileW * 2.5 / 100,
                        height: mobileW * 2.5 / 100,
                        tintColor: item.color_rise,
                        marginRight: mobileW * 1 / 100,
                      }} resizeMode='contain'
                        source={item.arrow}></Image>
                      <Text style={{
                        color: item.color_rise,
                        fontSize: mobileW * 3.25 / 100,
                        fontFamily: Font.FontSemiBold
                      }}>
                        {Lang_chg.rise_percent[config.language]}
                      </Text>
                    </View>
                  </View>

                  {/* border below all and fav */}
                  <View style={{
                    marginTop: mobileH * 1 / 100,
                    borderBottomWidth: mobileW * 0.25 / 100,
                    marginLeft: mobileW * 5 / 100,
                    borderColor: Colors.greyColor,
                    width: mobileW * 90 / 100,
                  }}>
                  </View>

                </View>
              }></FlatList>

          </KeyboardAwareScrollView>

          {/* --------------Footer--------------- */}
          <Footer
            activepage='Home'
            usertype={1}
            footerpage={[
              {
                name: 'Home',
                fname: 'Home',
                image: localimag.home_inactive,
                activeimage: localimag.home_active,
              },
              {
                name: 'Orders',
                fname: 'Orders', image: localimag.orders_inactive,
                activeimage: localimag.orders_inactive,
              },
              {
                name: 'Trade',
                fname: 'Trade',
                image: localimag.trade_inactive,
                activeimage: localimag.trade_active,
              },
              {
                name: 'Positions',
                fname: 'Positions',
                image: localimag.position_inactive,
                activeimage: localimag.position_inactive,
              },
              {
                name: 'Wallet',
                fname: 'Wallet', image: localimag.wallet_inactive,
                activeimage: localimag.wallet_inactive,
              },
            ]}
            navigation={this.props.navigation}
            imagestyle1={{
              width: mobileW * 6 / 100, height: mobileW * 6 / 100,
              backgroundColor: Colors.themeblack_color,
              countcolor: Colors.white_color,
            }}
          />
        </SafeAreaView >
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: Colors.HomeBackColor
  },
  view1:
  {
    backgroundColor: Colors.themeblack_color,
    height: mobileH * 8 / 100,
    flexDirection: 'row',
    width: mobileW * 88 / 100,
    alignSelf: 'center',
    alignItems: 'center',
  },
  icon1s: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    resizeMode: 'contain', alignSelf: 'center'
  },
})
