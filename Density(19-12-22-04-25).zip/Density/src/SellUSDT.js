import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, Modal, ImageBackground, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { color } from 'react-native-reanimated';
import { Keyboard } from 'react-native';
import { Appbutton } from './AllComponents';


export default class BuyUSDT extends Component {

  constructor(props) {
    super(props)
    this.state = {
      amount: '',
      refferal: false,
    }
  }

  //-------------for accept terms and conditions---------------
  refferal = () => {
    if (this.state.refferal) {
      this.setState({ refferal: false })
    } else {
      this.setState({ refferal: true })
    }
  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
        <SafeAreaView style={styles.container} />
        <StatusBar
          hidden={false}
          translucent={false}
          barStyle="light-content"
          networkActivityIndicatorVisible={true}
        />

        {/* heading  and back icon */}

        <View style={{
          width: mobileW * 90 / 100,
          alignItems: 'center',
          marginTop: mobileH * 2 / 100,
          alignSelf: 'center',
          flexDirection: 'row',
        }}>
          <TouchableOpacity
            onPress={() => this.props.navigation.goBack()
            }
            style={{}}>
            <Image style={{
              width: mobileW * 5 / 100,
              height: mobileW * 5 / 100
            }}
              resizeMode='contain' source={localimag.left}></Image>
          </TouchableOpacity>
          <View style={{
            paddingHorizontal: mobileW * 2 / 100,
          }}>
            <Text style={{
              color: Colors.placeholder_color,
              fontSize: mobileW * 5 / 100,
              fontFamily: Font.FontBold
            }}>{Lang_chg.SellUSDT[config.language]}</Text>

          </View>
        </View>

        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

          <View style={{
            alignSelf: 'center',
            width: mobileW * 90 / 100,
            marginTop: mobileH * 6 / 100
          }}>
            <Text style={{
              fontSize: mobileW * 3.8 / 100,
              fontFamily: Font.FontSemiBold,
              color: Colors.whiteColor
            }}>{Lang_chg.EnterAmountInUSDT[config.language]}</Text>
            <View style={{
              height: mobileH * 6.6 / 100,
              width: mobileW * 90 / 100,
              justifyContent: 'center',
              backgroundColor: Colors.ModelInsideButton,
              marginTop: mobileH * 1 / 100,
            }}>
              <View style={[styles.justifyContentStyle, { width: mobileW * 80 / 100 }]}>
                <Text style={{
                  fontSize: mobileW * 4 / 100,
                  fontFamily: Font.FontSemiBold,
                  textAlign: 'center',
                  color: Colors.PnlTextColor
                }}>{'500'}
                </Text>
                <Text style={{
                  fontSize: mobileW * 4 / 100,
                  fontFamily: Font.FontSemiBold,
                  textAlign: 'center',
                  color: Colors.whiteColor
                }}>{Lang_chg.Max[config.language]}
                </Text>
              </View>
            </View>
          </View>

          <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, marginTop: mobileH * 3 / 100 }]}>
            <Text style={{
              fontSize: mobileW * 4 / 100,
              fontFamily: Font.FontSemiBold,
              textAlign: 'center',
              color: Colors.whiteColor
            }}>{Lang_chg.AmountInINR[config.language]}
            </Text>
            <Text style={{
              fontSize: mobileW * 4 / 100,
              fontFamily: Font.FontSemiBold,
              textAlign: 'center',
              color: Colors.whiteColor
            }}>{'44,220'}
            </Text>
          </View>

          <View style={{
            borderBottomWidth: mobileW * 0.5 / 100,
            borderBottomColor: Colors.BorderColor,
            marginTop: mobileW * 5 / 100,
            width: mobileW * 90 / 100,
            alignSelf: 'center'
          }}></View>

          <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, marginTop: mobileH * 3 / 100 }]}>
            <Text style={{
              fontSize: mobileW * 4 / 100,
              fontFamily: Font.FontSemiBold,
              textAlign: 'center',
              color: Colors.whiteColor
            }}>{Lang_chg.OneUSDT[config.language]}
            </Text>
            <View style={[styles.justifyContentStyle, {}]}>
              <Text style={{
                fontSize: mobileW * 4 / 100,
                fontFamily: Font.FontSemiBold,
                textAlign: 'center',
                color: Colors.whiteColor
              }}>{'44,220'} <Text>{Lang_chg.INR[config.language]}</Text>
              </Text>
              <Image source={localimag.ReverseRefresh}
                style={{
                  height: mobileH * 2 / 100,
                  width: mobileW * 4 / 100,
                  marginLeft: mobileW * 1.6 / 100
                }}
              ></Image>
            </View>
          </View>

          <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, marginTop: mobileH * 3 / 100 }]}>
            <Text style={{
              fontSize: mobileW * 4 / 100,
              fontFamily: Font.FontSemiBold,
              textAlign: 'center',
              color: Colors.whiteColor
            }}>1 {Lang_chg.TDSChargesLevied[config.language]}
            </Text>
            <Text style={{
              fontSize: mobileW * 4 / 100,
              fontFamily: Font.FontSemiBold,
              textAlign: 'center',
              color: Colors.whiteColor
            }}>{'1%'} <Text>(0 {Lang_chg.INR[config.language]})</Text>
            </Text>
          </View>

          <View style={[styles.justifyContentStyle, { width: mobileW * 90 / 100, 
          marginTop: mobileH * 20 / 100,alignItems:'center' ,paddingBottom:mobileH*2/100}]}>
            {/*  transfer to usdt text view */}
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => this.refferal()}
              style={{
                flexDirection: 'row',
              }}>
              <Image style={{
              
                width: mobileW * 4 / 100,
                height: mobileW * 4 / 100,
              }} resizeMode='contain' source={this.state.refferal ? localimag.CheckBlack : localimag.UncheckBlack}></Image>

              <Text style={{
                color: Colors.PnlTextColor,
                marginLeft: mobileW * 2 / 100,
                fontSize: mobileW * 3.5 / 100,
                fontFamily: Font.FontSemiBold,
                
              }}>{Lang_chg.WithdrowToAccountDir[config.language]}</Text>
            </TouchableOpacity>
          </View>

          {/* -------------Button------------ */}
          <Appbutton
            handlepress={() => {
              this.props.navigation.navigate('Wallet')
            }}
            title={Lang_chg.Confirm[config.language]}
          />


        </KeyboardAwareScrollView >
      </View >
    )
  }
}

const styles = StyleSheet.create({
  justifyContentStyle: {
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
})

