import { Text, View, TouchableOpacity, Image, Keyboard, StyleSheet, ImageBackground, TextInput } from 'react-native';
import React, { Component } from 'react';
import {
  Colors,
  Font,
  Footer,
  mobileH,
  Mapprovider,
  msgProvider,
  msgText,
  config,
  mobileW,
  localStorage,
  consolepro,
  handleback,
  Lang_chg,
  apifuntion,
  msgTitle,
  localimag,
  localimg
} from './Provider/utilslib/Utils';

export class Yellowbtn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: ''
    };
  }
  render() {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        style={{
          backgroundColor: Colors.bluebtn,
          borderRadius: mobileW * 1 / 100,
          paddingVertical: mobileW * 4 / 100,
          marginVertical: mobileW * 1 / 100
        }}
        onPress={this.props.handlepress}
      >
        <Text
          style={{
            textAlign: 'center',
            color: Colors.whiteColor,
            fontFamily: Font.fontbold,
            fontSize: Font.slarge
          }}
        >
          {this.props.title}
        </Text>
      </TouchableOpacity>
    );
  }
}


export class Objectivebtn extends Component {
  render() {
    return (
      <View style={{ alignItems: 'center', alignSelf: 'center' }} >

        {/* //===============Image==============// */}
        <View style={{
          width: mobileW * 90 / 100,
          alignSelf: 'center',
          flexDirection: 'row',
          justifyContent: 'center',
          marginTop: mobileH * 10 / 100,
          alignItems: 'center'
        }}>
          <Image style={{
            width: mobileW * 75 / 100,
            height: mobileW * 75 / 100
          }} resizeMode='cover'
            source={localimag.ObjectiveOneImage}></Image>
        </View>

        <View style={{
          width: mobileW * 60 / 100,
          alignSelf: 'center',
          alignItems: 'center',
          marginTop: mobileH * 7 / 100
        }}>
          <Text style={{
            color: Colors.whiteColor,
            fontFamily: Font.FontSemiBold,
            fontSize: mobileW * 6.5 / 100,
            textAlign: 'center'
          }}>
            {Lang_chg.lorem_ipsum_dolot_txt[config.language]}
          </Text>
        </View>
        <View
          style={{
            width: mobileW * 90 / 100,
            alignItems: 'center',
            alignSelf: 'center',
            marginTop: mobileH * 2 / 100,
          }} >
          <Text style={{
            color: Colors.TermsColor,
            fontFamily: Font.FontMedium,
            fontSize: mobileW * 3.8 / 100,
            textAlign: 'center'
          }}>{Lang_chg.ConsecteturDummyText[config.language]}</Text>
        </View>

        <TouchableOpacity
          activeOpacity={0.8}
          onPress={this.props.handlepress}
          style={{
            width: mobileW * 90 / 100,
            alignSelf: 'center',
            flexDirection: 'row',
            justifyContent: 'center',
            marginTop: mobileH * 7 / 100,
            alignItems: 'center'
          }}>
          <Image style={{
            width: mobileW * 20 / 100,
            height: mobileW * 20 / 100
          }} resizeMode='cover'
            source={this.props.image}></Image>
        </TouchableOpacity>
      </View>
    );
  }
}

// header with one icon right icon

export class Appbutton extends Component {
  render() {
    return (
      <View style={{ alignItems: 'center', alignSelf: 'center' }} >
        <TouchableOpacity
          onPress={this.props.handlepress}
          activeOpacity={0.7} style={{
            backgroundColor: Colors.whiteColor,
            height: mobileH * 6.5 / 100,
            width: mobileW * 90 / 100,
            alignSelf: 'center',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{
            color: Colors.black_color,
            fontFamily: Font.FontBold,
            fontSize: mobileW * 4 / 100
          }}>{this.props.title}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export class Appsmallbutton extends Component {
  render() {
    return (
      <View style={{ alignItems: 'center', alignSelf: 'center' }} >
        <TouchableOpacity
          onPress={this.props.handlepress}
          activeOpacity={0.7} style={{
            backgroundColor: Colors.whiteColor,
            height: mobileH * 5 / 100,
            width: mobileW * 68 / 100,
            alignSelf: 'center',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{
            color: Colors.black_color,
            fontFamily: Font.FontBold,
            fontSize: mobileW * 4 / 100
          }}>{this.props.title}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export class Appsmallbutton1 extends Component {
  render() {
    return (
      <View style={{ alignItems: 'center', alignSelf: 'center' }} >
        <TouchableOpacity
          onPress={this.props.handlepress}
          activeOpacity={0.7} style={{
            backgroundColor: Colors.whiteColor,
            height: mobileH * 5 / 100,
            width: mobileW * 84 / 100,
            alignSelf: 'center',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{
            color: Colors.black_color,
            fontFamily: Font.FontBold,
            fontSize: mobileW * 4 / 100
          }}>{this.props.title}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export class TextInputCmp extends Component {
  render() {
    return (
      <View>
        <View style={{
          width: mobileW * 90 / 100,
          alignSelf: 'center',
          flexDirection: 'row',
          marginTop: mobileH * 2 / 100
        }}>
          <Text style={{
            color: Colors.whiteColor,
            fontSize: mobileW * 3.9 / 100,
            fontFamily: Font.FontRegular
          }}>{this.props.htitle}</Text>
        </View>
        <View style={{
          width: mobileW * 90 / 100,
          marginTop: mobileH * 1 / 100,
          height: mobileH * 7 / 100,
          backgroundColor: Colors.textbackground_color,
          borderRadius: mobileW * 1 / 100,
          flexDirection: 'row',
          alignItems: 'center',
          borderColor: Colors.text_color2,
          borderWidth: 0.5
        }}>
          <TextInput style={{
            fontFamily: Font.FontRegular,
            width: mobileW * 80 / 100,
            fontSize: mobileW * 4 / 100,
            backgroundColor: Colors.textbackground_color,
            marginLeft: mobileW * 2 / 100,
            color: Colors.placeholder_color
          }}
            placeholderTextColor={Colors.Placeholdercolor}
            placeholder={this.props.placeholder}
            keyboardType={this.props.Keyboard}
            returnKeyLabel='done'
            returnKeyType='done'
            ref={(input) => { this.mobilefield = input; }}
            onSubmitEditing={() => { Keyboard.dismiss() }}
            onFocus={() => { this.setState({ errorno: 0, activeinput: 1 }) }}
            maxLength={this.props.maxLength}
            secureTextEntry={this.props.securetext}

          />
          <TouchableOpacity activeOpacity={0.7} style={{
            justifyContent: 'center',
            alignSelf: 'center',
          }}
            onPress={this.props.onpresshandler} >
            {this.props.securetext == true ?
              <Image style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }}
                source={this.props.Open}>
              </Image>
              :
              <Image style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }}
                source={this.props.Close}>
              </Image>
            }
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}




// -------------textInput---------------






const styles = StyleSheet.create({
  footericon: {
    width: mobileW * 18 / 100,
    paddingBottom: 6,
    borderWidth: mobileW * 0.8 / 100,
    borderRadius: mobileW * 3 / 100,
    borderColor: Colors.YellowBoarder
  },
  footericonview: {
    alignSelf: 'center',
    height: mobileH * 6 / 100,
    alignItems: 'center'
  },
  footerimage: {
    alignSelf: 'center',
    //resizeMode: 'contain'
  }
});
