import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { TouchableOpacity } from 'react-native-gesture-handler';


export default class SearchHome extends Component {

    constructor(props) {
        super(props)
        this.state = {

            script_arr_all: [
                {
                    scriptName: Lang_chg.BTC_USDT[config.language],
                    volume: Lang_chg.vol_562b_text[config.language],
                    starImage: localimag.star_fill,
                    currency: Lang_chg.inr_txt[config.language],
                    arrow: localimag.dropdown,
                    color_rise: Colors.green_type_color,
                    price: Lang_chg.num_19953[config.language],
                    rise_percent: Lang_chg.num_122[config.language]
                },
                {
                    scriptName: Lang_chg.ETH_USDT[config.language],
                    volume: Lang_chg.vol_562b_text[config.language],
                    starImage: localimag.star_unfill,
                    arrow: localimag.green_dropdown,
                    currency: Lang_chg.usdt_txt[config.language],
                    price: Lang_chg.num_1322[config.language],
                    color_rise: Colors.green_type_color,
                    rise_percent: Lang_chg.num_328[config.language]
                },
                {
                    scriptName: Lang_chg.DOGE_USDT[config.language],
                    volume: Lang_chg.vol_562b_text[config.language],
                    starImage: localimag.star_fill,
                    currency: Lang_chg.usdt_txt[config.language],
                    arrow: localimag.dropdown, price: Lang_chg.num_0[config.language],
                    color_rise: Colors.OrangeColor,
                    rise_percent: Lang_chg.num_7[config.language]
                },
                {
                    scriptName: Lang_chg.TRX_USDT[config.language],
                    volume: Lang_chg.vol_562b_text[config.language],
                    starImage: localimag.star_fill,
                    currency: Lang_chg.usdt_txt[config.language],
                    arrow: localimag.dropdown,
                    price: Lang_chg.num_53[config.language],
                    color_rise: Colors.OrangeColor,
                    rise_percent: '-1.22%'
                },
            ],
            title: '',
        }
    }

    SearchFilterFunction = (text) => {
        this.setState({ title: text })
        let data1 = this.state.script_arr_all
        console.log('this.state.report_arr', this.state.report_arr1)
        if (data1 != 'NA') {
            var text_data = text.toString().toLowerCase();
            let newData = data1.filter(function (item) {
                return (
                    item.scriptName.toString().toLowerCase().indexOf(text_data) >= 0
                )
            });
            consolepro.consolelog("newdataa", newData)
            if (newData.length > 0) {
                consolepro.consolelog("newdataa1", newData)
                this.setState({ report_arr: newData })
            } else if (newData.length <= 0) {
                consolepro.consolelog("newdataa   2", newData)
                this.setState({ report_arr: 'NA' })
            }
        }
    }

    render() {
        return (
            <SafeAreaView style={styles.container}>
                <StatusBar
                    hidden={false}
                    translucent={false}
                    barStyle="light-content"
                    backgroundColor={Colors.statusbarcolor}
                    networkActivityIndicatorVisible={true}
                />

                <View style={{
                    marginTop: mobileH * 3 / 100,
                    borderRadius: mobileW * 2 / 100,
                    alignSelf: 'center',
                    borderColor: Colors.PnlTextColor,
                    width: mobileW * 87.5 / 100,
                }}>
                    <View style={{
                        paddingHorizontal: mobileW * 2 / 100, flexDirection: 'row',
                        alignItems: 'center', borderColor: Colors.placeholder_color,
                        borderWidth: mobileW * 0.25 / 100,
                        height: mobileH * 7 / 100,
                    }}>
                        <View style={{
                            paddingHorizontal: mobileW * 3 / 100,
                            // paddingVertical: mobileH * 0.5 / 100,
                        }}>
                            <Image
                                source={localimag.searchwhite}
                                resizeMode='contain'
                                style={{
                                    width: mobileW * 4 / 100, height: mobileW * 4 / 100,
                                    tintColor: Colors.PnlTextColor
                                }}
                            ></Image>
                        </View>
                        <TextInput
                            keyboardType='default'
                            returnKeyType="done"
                            onChangeText={(text) => { this.SearchFilterFunction(text) }}
                            ref={(input) => { this.searchfield = input; }}
                            maxLength={50}
                            style={{
                                color: Colors.white_color,
                                backgroundColor: Colors.textinput_back,
                                borderTopRightRadius: mobileW * 2 / 100,
                                borderBottomRightRadius: mobileW * 2 / 100,
                                paddingVertical: mobileW * 3 / 100, width: mobileW * 62.5 / 100,
                                fontSize: mobileW * 3.5 / 100,
                            }}
                            placeholder={Lang_chg.search_for_crypto_txt[config.language]}
                            placeholderTextColor={Colors.PnlTextColor}
                            value={"" + this.state.title + ""}
                        >
                        </TextInput>

                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate("Home")}
                            style={{
                                paddingHorizontal: mobileW * 3 / 100,
                                // paddingVertical: mobileH * 0.5 / 100,
                            }}>
                            <Image
                                source={localimag.cancel_white}
                                resizeMode='contain'
                                style={{
                                    width: mobileW * 4 / 100, height: mobileW * 4 / 100,
                                    tintColor: Colors.placeholder_color
                                }}
                            ></Image>
                        </TouchableOpacity>
                    </View>
                </View>

                <KeyboardAwareScrollView>
                    <View style={{
                        width: mobileW * 87.5 / 100, alignItems: 'center',
                        marginTop: mobileH * 3 / 100
                    }}>
                        <Text style={{
                            color: Colors.placeholder_color, width: mobileW * 87.5 / 100,
                            fontSize: mobileW * 4.5 / 100, fontFamily: Font.FontSemiBold
                        }}>
                            {Lang_chg.MostSearched[config.language]}
                        </Text>
                    </View>

                    <View style={{
                        width: mobileW * 87.5 / 100,
                        alignItems: 'center',
                        marginTop: mobileH * 1 / 100
                    }}>
                        <Text style={{
                            color: Colors.text_color2,
                            width: mobileW * 87.5 / 100,
                            fontSize: mobileW * 4 / 100,
                            fontFamily: Font.FontSemiBold
                        }}>
                            {Lang_chg.Cryptos_everyone[config.language]}
                        </Text>
                    </View>

                    {/* script, its volume and price faltlist*/}

                    <FlatList
                        data={this.state.script_arr_all}
                        contentContainerStyle={{
                            paddingBottom: mobileH * 10 / 100
                        }}
                        renderItem={({ item, index }) =>
                            <View>
                                <View style={{
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    width: mobileW * 90 / 100,
                                    alignSelf: 'center',
                                    marginTop: mobileH * 2 / 100,
                                }}>
                                    {/* script name*/}

                                    <View style={{
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        width: mobileW * 90 / 100,
                                    }}>
                                        <Text
                                            numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 4 / 100, fontFamily: Font.FontSemiBold
                                            }}>
                                            {item.scriptName}</Text>

                                        <Text style={{
                                            textAlign: 'justify',
                                            color: Colors.placeholder_color,
                                            fontSize: mobileW * 3.25 / 100,
                                            fontFamily: Font.FontSemiBold
                                        }}>
                                            {item.price}</Text>
                                    </View>
                                </View>

                                <View style={{
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    marginLeft: mobileW * 14.3 / 100,
                                    width: mobileW * 75 / 100,
                                    alignSelf: 'flex-end'
                                }}>

                                    {/* ----% rise or fall in script----*/}
                                    <View style={{
                                        flexDirection: 'row', justifyContent: 'flex-end',
                                        alignItems: 'center',
                                        width: mobileW * 75 / 100
                                    }}>
                                        <Text style={{
                                            color: item.color_rise,
                                            fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontSemiBold
                                        }}>
                                            {item.rise_percent}</Text>
                                    </View>
                                </View>

                                {/* ------border below all and fav------ */}
                                <View style={{
                                    marginTop: mobileH * 1 / 100,
                                    borderBottomWidth: mobileW * 0.25 / 100,
                                    borderColor: Colors.greyColor, width: mobileW * 90 / 100,
                                }}>
                                </View>

                            </View>
                        }></FlatList>

                </KeyboardAwareScrollView>
            </SafeAreaView>
        )
    }
}

const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.themeblack_color
    },

})