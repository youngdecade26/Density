import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity, } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appsmallbutton } from './AllComponents';
import { Appbutton } from './AllComponents';

export default class Positions extends Component {
          constructor(props) {
                    super(props)
                    this.state = {
                              BuyOrderModel: false,
                              EditModel: false,

                              BTCUSDTArr: [
                                        {
                                                  'id': '0',
                                                  'Type': 'Long',
                                                  'PnL': '39.058',
                                                  'LTP': '$1962.50'
                                        },
                                        {
                                                  'id': '1',
                                                  'Type': 'Long',
                                                  'PnL': '39.058',
                                                  'LTP': '$1962.50'
                                        },
                                        {
                                                  'id': '2',
                                                  'Type': 'Short',
                                                  'PnL': '39.058',
                                                  'LTP': '$1962.50'
                                        }
                              ]

                    }
          }
          componentDidMount() {

          }


          render() {
                    return (
                              <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                                        <SafeAreaView style={styles.container}>
                                                  <StatusBar
                                                            hidden={false}
                                                            translucent={false}
                                                            barStyle="light-content"
                                                            networkActivityIndicatorVisible={true}
                                                  />
                                                  <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                                                            showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

                                                            {/* //==========Get Started Now Text=========// */}
                                                            <View
                                                                      style={{
                                                                                flexDirection: 'row',
                                                                                marginTop: mobileH * 2 / 100,
                                                                                marginBottom: mobileH * 4 / 100,
                                                                                paddingHorizontal: mobileW * 5 / 100,
                                                                      }} >
                                                                      <View
                                                                                style={{
                                                                                          width: mobileW * 89 / 100,
                                                                                          flexDirection: 'row',
                                                                                          justifyContent: 'space-between',
                                                                                          alignSelf: 'center',
                                                                                          alignItems: 'center',
                                                                                }}>
                                                                                <View>
                                                                                          <Text style={{
                                                                                                    color: Colors.whiteColor,
                                                                                                    fontFamily: Font.FontSemiBold,
                                                                                                    fontSize: mobileW * 6.3 / 100
                                                                                          }}>
                                                                                                    {Lang_chg.Positions[config.language]}
                                                                                          </Text>
                                                                                          <View style={{
                                                                                                    width: mobileW * 22 / 100,
                                                                                                    backgroundColor: Colors.yellow_color,
                                                                                                    borderColor: Colors.yellow_color,
                                                                                                    borderWidth: mobileW * 0.9 / 100
                                                                                          }}>
                                                                                          </View>
                                                                                </View>
                                                                                <View>
                                                                                          <Image style={{
                                                                                                    height: mobileH * 3.3 / 100,
                                                                                                    width: mobileW * 6.6 / 100,
                                                                                                    marginTop: mobileH * 1 / 100
                                                                                          }}
                                                                                                    source={localimag.YellowSearchIcon}></Image>
                                                                                </View>
                                                                      </View>
                                                            </View>

                                                            <View style={{
                                                                      width: mobileW * 90 / 100, alignSelf: 'center',
                                                            }}>

                                                                      {/* -------------FirstBox-------------- */}
                                                                      <View
                                                                                style={{
                                                                                          width: '99.5%',
                                                                                          alignSelf: 'center',
                                                                                          borderWidth: mobileW * 0.5 / 100,
                                                                                          borderColor: Colors.BorderColor,
                                                                                          backgroundColor: Colors.CartBackColor,
                                                                                }}>
                                                                                <View style={{
                                                                                          paddingVertical: mobileH * 1 / 100,
                                                                                          alignSelf: 'center'
                                                                                }}>
                                                                                          <Text style={{
                                                                                                    color: Colors.GreyTextColor,
                                                                                                    fontSize: mobileW * 4.5 / 100,
                                                                                                    fontFamily: Font.FontMedium
                                                                                          }}>{Lang_chg.TotalPnL[config.language]}</Text>
                                                                                          <Text style={{
                                                                                                    color: Colors.GreenText,
                                                                                                    fontSize: mobileW * 4.5 / 100,
                                                                                                    fontFamily: Font.FontMedium,
                                                                                                    textAlign: 'center'
                                                                                          }}>{Lang_chg.TotalPnLNumber[config.language]}</Text>
                                                                                </View>
                                                                      </View>

                                                                      {/* -------------SecondBox-------------- */}
                                                                      <View
                                                                                style={{
                                                                                          marginTop: mobileH * 2 / 100,
                                                                                          width: '99.5%',
                                                                                          alignSelf: 'center',
                                                                                          borderWidth: mobileW * 0.5 / 100,
                                                                                          borderColor: Colors.BorderColor,
                                                                                          backgroundColor: Colors.CartBackColor,
                                                                                }}>

                                                                                <View style={{
                                                                                          width: mobileW * 84 / 100,
                                                                                          paddingVertical: mobileH * 1 / 100,
                                                                                          alignSelf: 'center',
                                                                                          flexDirection: 'row',
                                                                                          justifyContent: 'space-between',
                                                                                }}>

                                                                                          <View style={{ width: mobileW * 50 / 100, }}>
                                                                                                    <View style={{ backgroundColor: Colors.GreenButton, width: mobileW * 12 / 100 }}>
                                                                                                              <Text style={{
                                                                                                                        color: Colors.GreyTextColor,
                                                                                                                        fontSize: mobileW * 3 / 100,
                                                                                                                        fontFamily: Font.FontMedium,
                                                                                                                        paddingVertical: mobileH * 0.2 / 100,
                                                                                                                        textAlign: 'center'
                                                                                                              }}>{'Long'}</Text>
                                                                                                    </View>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 4.4 / 100,
                                                                                                              fontFamily: Font.FontSemiBold,
                                                                                                    }}>{Lang_chg.BTCUSDT1X[config.language]}</Text>
                                                                                          </View>

                                                                                          <View>
                                                                                                    <View style={{ flexDirection: 'row' }}>
                                                                                                              <Text style={{
                                                                                                                        color: Colors.GreyTextColor,
                                                                                                                        fontSize: mobileW * 3.3 / 100,
                                                                                                                        fontFamily: Font.FontMedium
                                                                                                              }}>{Lang_chg.PnL[config.language]} <Text style={{
                                                                                                                        color: Colors.GreenText,
                                                                                                                        fontSize: mobileW * 3.7 / 100,
                                                                                                                        fontFamily: Font.FontMedium
                                                                                                              }}>{Lang_chg.PnLNumber[config.language]}</Text></Text>
                                                                                                    </View>
                                                                                                    <View style={{ flexDirection: 'row' }}>
                                                                                                              <Text style={{
                                                                                                                        color: Colors.GreyTextColor,
                                                                                                                        fontSize: mobileW * 3.3 / 100,
                                                                                                                        fontFamily: Font.FontMedium
                                                                                                              }}>{Lang_chg.LTP[config.language]} <Text style={{
                                                                                                                        color: Colors.whiteColor,
                                                                                                                        fontSize: mobileW * 3 / 100,
                                                                                                                        fontFamily: Font.FontMedium
                                                                                                              }}>{Lang_chg.LTPNumber[config.language]}</Text></Text>
                                                                                                    </View>
                                                                                          </View>
                                                                                </View>

                                                                                <View style={{
                                                                                          borderBottomWidth: mobileW * 0.5 / 100,
                                                                                          borderBottomColor: Colors.BorderColor,
                                                                                          marginTop: mobileW * 4 / 100,
                                                                                          width: mobileW * 88 / 100,
                                                                                          alignSelf: 'center'
                                                                                }}></View>

                                                                                <View style={{
                                                                                          flexDirection: 'row',
                                                                                          justifyContent: 'space-between',
                                                                                          width: mobileW * 84 / 100,
                                                                                          alignSelf: 'center'
                                                                                }}>
                                                                                          <View>
                                                                                                    <Text style={styles.SizeInContracttxt}>{Lang_chg.SizeInContract[config.language]}</Text>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>
                                                                                          <View>
                                                                                                    <Text style={styles.SizeInContracttxt}>{Lang_chg.EntryPrice[config.language]}</Text>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>
                                                                                          <View>
                                                                                                    <Text style={styles.SizeInContracttxt}>{Lang_chg.LiqudationPrice[config.language]}</Text>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>
                                                                                </View>

                                                                                <View style={{
                                                                                          paddingTop: mobileH * 2 / 100,
                                                                                          flexDirection: 'row',
                                                                                          justifyContent: 'space-between',
                                                                                          width: mobileW * 84 / 100,
                                                                                          alignSelf: 'center'
                                                                                }}>
                                                                                          <View>
                                                                                                    <Text style={styles.SizeInContracttxt}>{Lang_chg.SizeInValue[config.language]}</Text>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>
                                                                                          <View>
                                                                                                    <Text style={styles.SizeInContracttxt}>{Lang_chg.MarginRatio[config.language]}</Text>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>
                                                                                          <View>
                                                                                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                                                                              <Text style={styles.SizeInContracttxt}>{Lang_chg.MarginUsed[config.language]}</Text>
                                                                                                              <TouchableOpacity
                                                                                                                        onPress={() => this.setState({ EditModel: true })}
                                                                                                              >
                                                                                                                        <Image style={{
                                                                                                                                  height: mobileH * 1.5 / 100,
                                                                                                                                  width: mobileW * 3 / 100,
                                                                                                                                  marginLeft: mobileW * 2 / 100
                                                                                                                        }}
                                                                                                                                  source={localimag.EditIcon}></Image>
                                                                                                              </TouchableOpacity>
                                                                                                    </View>
                                                                                                    <Text style={{
                                                                                                              color: Colors.whiteColor,
                                                                                                              fontSize: mobileW * 3.5 / 100,
                                                                                                              fontFamily: Font.FontMedium
                                                                                                    }}>{'0.4551'}</Text>
                                                                                          </View>

                                                                                </View>

                                                                                {/* //==========Continue Submit =========// */}
                                                                                <View style={{
                                                                                          marginTop: mobileH * 4 / 100,
                                                                                          width: mobileW * 75 / 100,
                                                                                          flexDirection: 'row',
                                                                                          alignSelf: 'center',
                                                                                          alignItems: 'center',
                                                                                          justifyContent: 'space-between',
                                                                                          paddingBottom: mobileH * 2 / 100
                                                                                }}>
                                                                                          <Appsmallbutton
                                                                                                    handlepress={() => {
                                                                                                              this.setState({ BuyOrderModel: true })
                                                                                                    }}
                                                                                                    title={Lang_chg.ClosePosition[config.language]}
                                                                                          />
                                                                                          <Image style={{
                                                                                                    height: mobileH * 3 / 100,
                                                                                                    width: mobileW * 5 / 100,
                                                                                                    marginLeft: mobileW * 2 / 100
                                                                                          }}
                                                                                                    source={localimag.ShareIcon}></Image>
                                                                                </View>

                                                                      </View>

                                                                      {/* -------------------------------------- */}
                                                                      <FlatList
                                                                                data={this.state.BTCUSDTArr
                                                                                }
                                                                                contentContainerStyle={{ paddingBottom: mobileW * 25 / 100 }}
                                                                                renderItem={({ item, index }) => {
                                                                                          console.log('item', item)
                                                                                          return (
                                                                                                    <View
                                                                                                              style={{
                                                                                                                        marginTop: mobileH * 2 / 100,
                                                                                                                        width: '99.5%',
                                                                                                                        alignSelf: 'center',
                                                                                                                        borderWidth: mobileW * 0.5 / 100,
                                                                                                                        borderColor: Colors.BorderColor,
                                                                                                                        backgroundColor: Colors.CartBackColor,
                                                                                                              }}>

                                                                                                              <View style={{
                                                                                                                        width: mobileW * 84 / 100,
                                                                                                                        paddingVertical: mobileH * 1 / 100,
                                                                                                                        alignSelf: 'center',
                                                                                                                        flexDirection: 'row',
                                                                                                                        justifyContent: 'space-between',
                                                                                                              }}>

                                                                                                                        <View style={{ width: mobileW * 50 / 100, }}>
                                                                                                                                  <View style={{ backgroundColor: item.Type == 'Short' ? Colors.OrangeColor : Colors.GreenButton, width: mobileW * 12 / 100 }}>
                                                                                                                                            <Text style={{
                                                                                                                                                      color: Colors.GreyTextColor,
                                                                                                                                                      fontSize: mobileW * 3 / 100,
                                                                                                                                                      fontFamily: Font.FontMedium,
                                                                                                                                                      paddingVertical: mobileH * 0.2 / 100,
                                                                                                                                                      textAlign: 'center'
                                                                                                                                            }}>{item.Type}</Text>
                                                                                                                                  </View>
                                                                                                                                  <Text style={{
                                                                                                                                            color: Colors.whiteColor,
                                                                                                                                            fontSize: mobileW * 4.4 / 100,
                                                                                                                                            fontFamily: Font.FontSemiBold,
                                                                                                                                  }}>{Lang_chg.BTCUSDT1X[config.language]}</Text>
                                                                                                                        </View>

                                                                                                                        <View style={{
                                                                                                                                  width: mobileW * 25 / 100,
                                                                                                                                  flexDirection: 'row',
                                                                                                                                  backgroundColor: 'Green',
                                                                                                                                  justifyContent: 'space-between',
                                                                                                                                  alignItems: 'center',
                                                                                                                                  alignContent: 'center',
                                                                                                                        }}>
                                                                                                                                  <View>
                                                                                                                                            <View style={{ flexDirection: 'row' }}>
                                                                                                                                                      <Text style={{
                                                                                                                                                                color: Colors.GreyTextColor,
                                                                                                                                                                fontSize: mobileW * 3.3 / 100,
                                                                                                                                                                fontFamily: Font.FontMedium
                                                                                                                                                      }}>{Lang_chg.PnL[config.language]}  <Text style={{
                                                                                                                                                                color: item.Type == 'Short' ? Colors.OrangeColor : Colors.GreenText,
                                                                                                                                                                fontSize: mobileW * 3.7 / 100,
                                                                                                                                                                fontFamily: Font.FontMedium
                                                                                                                                                      }}>{item.PnL}</Text></Text>
                                                                                                                                            </View>
                                                                                                                                            <View style={{ flexDirection: 'row' }}>
                                                                                                                                                      <Text style={{
                                                                                                                                                                color: Colors.GreyTextColor,
                                                                                                                                                                fontSize: mobileW * 3.3 / 100,
                                                                                                                                                                fontFamily: Font.FontMedium
                                                                                                                                                      }}>{Lang_chg.LTP[config.language]}  <Text style={{
                                                                                                                                                                color: Colors.whiteColor,
                                                                                                                                                                fontSize: mobileW * 3 / 100,
                                                                                                                                                                fontFamily: Font.FontMedium
                                                                                                                                                      }}>{item.LTP}</Text></Text>
                                                                                                                                            </View>
                                                                                                                                  </View>
                                                                                                                        </View>

                                                                                                                        <View style={{ height: mobileH * 2 / 100, paddingTop: mobileH * 2.8 / 100 }}>
                                                                                                                                  <Image style={{
                                                                                                                                            height: mobileH * 2 / 100,
                                                                                                                                            width: mobileW * 4 / 100
                                                                                                                                  }}
                                                                                                                                            source={localimag.DownYerrowIcon}></Image>
                                                                                                                        </View>
                                                                                                              </View>
                                                                                                    </View>
                                                                                          )
                                                                                }}
                                                                      />

                                                            </View>


                                                            {/* ---------------Model--------------- */}
                                                            <Modal
                                                                      animationType="slide"
                                                                      transparent
                                                                      visible={this.state.BuyOrderModel}
                                                                      onRequestClose={() => {
                                                                      }}>

                                                                      <View
                                                                                style={{
                                                                                          flex: 1,
                                                                                          backgroundColor: '#00000090',
                                                                                          alignItems: 'center',
                                                                                          justifyContent: 'center',
                                                                                          // bottom:-mobileH*2/100,
                                                                                          borderRadius: 0,
                                                                                }}>
                                                                                <View style={{
                                                                                          backgroundColor: Colors.ModelColor,
                                                                                          width: mobileW * 80 / 100,

                                                                                          paddingVertical: mobileH * 2 / 100
                                                                                }}>
                                                                                          <View style={{ paddingVertical: mobileH * 2 / 100, alignSelf: 'center' }}>
                                                                                                    <View style={{
                                                                                                              width: mobileW * 70 / 100,
                                                                                                              alignSelf: 'center',
                                                                                                              alignItems: 'center'
                                                                                                    }}>
                                                                                                              <Image style={{
                                                                                                                        height: mobileH * 6 / 100,
                                                                                                                        width: mobileW * 12 / 100,
                                                                                                                        marginTop: mobileH * 1 / 100
                                                                                                              }}
                                                                                                                        source={localimag.ErrorIcon}></Image>
                                                                                                              <Text style={{
                                                                                                                        marginLeft: mobileW * 1 / 100,
                                                                                                                        fontSize: mobileW * 4 / 100,
                                                                                                                        fontFamily: Font.FontMedium,
                                                                                                                        paddingTop: mobileH * 2 / 100,
                                                                                                                        color: Colors.whiteColor,
                                                                                                                        textAlign: 'center'
                                                                                                              }}>{Lang_chg.BuyOrderModelText1}
                                                                                                              </Text>
                                                                                                              <Text style={{
                                                                                                                        fontFamily: Font.FontBold,
                                                                                                                        color: Colors.whiteColor,
                                                                                                                        paddingTop: mobileH * 1 / 100,
                                                                                                                        fontSize: mobileW * 4 / 100,
                                                                                                              }}>{Lang_chg.BuyOrderModelText2} <Text>{Lang_chg.BuyOrderModelText3}
                                                                                                                        </Text>
                                                                                                              </Text>

                                                                                                              <Text style={{
                                                                                                                        fontSize: mobileW * 4 / 100,
                                                                                                                        fontFamily: Font.FontMedium,
                                                                                                                        color: Colors.whiteColor,
                                                                                                                        textAlign: 'center'
                                                                                                              }}>{Lang_chg.ExitToModel}
                                                                                                              </Text>
                                                                                                    </View>

                                                                                                    <View style={{
                                                                                                              marginVertical: mobileH * 1 / 100,
                                                                                                              paddingTop: mobileH * 3 / 100,
                                                                                                              flexDirection: 'row',
                                                                                                              justifyContent: 'space-between',
                                                                                                              width: mobileW * 74 / 100,
                                                                                                              alignSelf: 'center',
                                                                                                    }}>
                                                                                                              <TouchableOpacity
                                                                                                                        onPress={() => { this.setState({ BuyOrderModel: 'false' }) }}
                                                                                                                        activeOpacity={0.7} style={{
                                                                                                                                  backgroundColor: Colors.ModelColor,
                                                                                                                                  borderWidth: mobileW * 0.5 / 100,
                                                                                                                                  borderColor: Colors.whiteColor,
                                                                                                                                  height: mobileH * 5 / 100,
                                                                                                                                  width: mobileW * 35 / 100,
                                                                                                                                  justifyContent: 'center',

                                                                                                                        }}>
                                                                                                                        <Text style={{
                                                                                                                                  fontSize: mobileW * 4.5 / 100,
                                                                                                                                  fontFamily: Font.FontSemiBold,
                                                                                                                                  textAlign: 'center',
                                                                                                                                  color: Colors.whiteColor
                                                                                                                        }}>{Lang_chg.cancel_txt[config.language]}</Text>
                                                                                                              </TouchableOpacity>

                                                                                                              <TouchableOpacity
                                                                                                                        onPress={() => { this.props.navigation.navigate('PositionsAfterModel'), this.setState({ BuyOrderModel: 'false' }) }}
                                                                                                                        activeOpacity={0.7} style={{
                                                                                                                                  backgroundColor: Colors.whiteColor,
                                                                                                                                  borderWidth: mobileW * 0.5 / 100,
                                                                                                                                  borderColor: Colors.whiteColor,
                                                                                                                                  height: mobileH * 5 / 100,
                                                                                                                                  width: mobileW * 35 / 100,
                                                                                                                                  justifyContent: 'center',
                                                                                                                        }}>
                                                                                                                        <Text style={{
                                                                                                                                  fontSize: mobileW * 4.5 / 100,
                                                                                                                                  fontFamily: Font.FontSemiBold,
                                                                                                                                  textAlign: 'center',
                                                                                                                                  color: Colors.black_color
                                                                                                                        }}>{Lang_chg.Confirm[config.language]}</Text>
                                                                                                              </TouchableOpacity>
                                                                                                    </View>
                                                                                          </View>
                                                                                </View>
                                                                      </View>
                                                            </Modal>




                                                            <Modal
                                                                      animationType="slide"
                                                                      transparent
                                                                      visible={this.state.EditModel}
                                                                      onRequestClose={() => {
                                                                      }}>

                                                                      <View
                                                                                style={{
                                                                                          flex: 1,
                                                                                          backgroundColor: '#00000090',
                                                                                          alignItems: 'center',
                                                                                          justifyContent: 'center',
                                                                                          // bottom:-mobileH*2/100,
                                                                                          borderRadius: 0,
                                                                                }}>
                                                                                <View style={{
                                                                                          backgroundColor: Colors.ModelColor,
                                                                                          width: mobileW * 100 / 100,
                                                                                          paddingVertical: mobileH * 2 / 100,
                                                                                          borderTopRightRadius: mobileW * 5 / 100,
                                                                                          borderTopLeftRadius: mobileW * 5 / 100
                                                                                }}>
                                                                                          {/* ----------TopLine----------- */}
                                                                                          <View style={{
                                                                                                    borderBottomWidth: mobileW * 1.5 / 100,
                                                                                                    borderBottomColor: Colors.whiteColor,
                                                                                                    width: mobileW * 60 / 100,
                                                                                                    alignSelf: 'center'
                                                                                          }}></View>
                                                                                          {/* --------------------------- */}
                                                                                          <View style={{
                                                                                                    alignSelf: 'center',
                                                                                                    width: mobileW * 90 / 100,
                                                                                                    marginTop: mobileH * 7 / 100
                                                                                          }}>

                                                                                                    <View style={{
                                                                                                              borderBottomWidth: mobileW * 0.5 / 100,
                                                                                                              borderBottomColor: Colors.BorderColor,
                                                                                                              width: mobileW * 100 / 100,
                                                                                                              alignSelf: 'center'
                                                                                                    }}></View>
                                                                                                    {/* --------------------Close---------------------- */}

                                                                                                    <View style={{
                                                                                                              flexDirection: 'row',
                                                                                                              alignSelf: 'center',
                                                                                                              justifyContent: 'space-between',
                                                                                                              alignItems: 'center',
                                                                                                              width: mobileW * 90 / 100,
                                                                                                              marginTop: mobileH * 1 / 100
                                                                                                    }}>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt
                                                                                                              }>{Lang_chg.CurrentlyMrginText[config.language]}</Text>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt1
                                                                                                              }>6.86 {Lang_chg.UsdtTxt[config.language]}</Text>
                                                                                                    </View>

                                                                                                    <View style={{
                                                                                                              flexDirection: 'row',
                                                                                                              justifyContent: 'space-between',
                                                                                                              marginTop: mobileH * 2 / 100
                                                                                                    }}>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt
                                                                                                              }>{Lang_chg.MaxAddable[config.language]}</Text>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt1
                                                                                                              }>2,814.30 {Lang_chg.UsdtTxt[config.language]}</Text>
                                                                                                    </View>

                                                                                                    <View style={{
                                                                                                              flexDirection: 'row',
                                                                                                              justifyContent: 'space-between',
                                                                                                              marginTop: mobileH * 2 / 100
                                                                                                    }}>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt
                                                                                                              }>{Lang_chg.PriceAfterIncrease[config.language]}</Text>
                                                                                                              <Text style={styles.
                                                                                                                        EditModeltxt1
                                                                                                              }>20,864.57 {Lang_chg.UsdtTxt[config.language]}</Text>
                                                                                                    </View>

                                                                                                    <View style={{
                                                                                                              borderBottomWidth: mobileW * 0.5 / 100,
                                                                                                              borderBottomColor: Colors.whiteColor,
                                                                                                              width: mobileW * 90 / 100,
                                                                                                              alignSelf: 'center',
                                                                                                              marginTop: mobileH * 3 / 100
                                                                                                    }}></View>
                                                                                                    {/* -----------------Button------------------- */}

                                                                                                    <View style={{
                                                                                                              marginVertical: mobileH * 1 / 100,
                                                                                                              paddingTop: mobileH * 3 / 100,
                                                                                                              flexDirection: 'row',
                                                                                                              justifyContent: 'space-between',
                                                                                                              width: mobileW * 90 / 100,
                                                                                                              alignSelf: 'center',
                                                                                                    }}>

                                                                                                              <TouchableOpacity
                                                                                                                        onPress={() => { this.props.navigation.navigate('PositionsAfterModel'), this.setState({ BuyOrderModel: 'false' }) }}
                                                                                                                        activeOpacity={0.7} style={{
                                                                                                                                  backgroundColor: Colors.whiteColor,
                                                                                                                                  borderWidth: mobileW * 0.5 / 100,
                                                                                                                                  borderColor: Colors.whiteColor,
                                                                                                                                  height: mobileH * 5 / 100,
                                                                                                                                  width: mobileW * 42.5 / 100,
                                                                                                                                  justifyContent: 'center',
                                                                                                                        }}>
                                                                                                                        <Text style={{
                                                                                                                                  fontSize: mobileW * 4.5 / 100,
                                                                                                                                  fontFamily: Font.FontSemiBold,
                                                                                                                                  textAlign: 'center',
                                                                                                                                  color: Colors.black_color
                                                                                                                        }}>{Lang_chg.Add[config.language]}</Text>
                                                                                                              </TouchableOpacity>


                                                                                                              <TouchableOpacity
                                                                                                                        onPress={() => { this.setState({ BuyOrderModel: 'false' }) }}
                                                                                                                        activeOpacity={0.7} style={{
                                                                                                                                  backgroundColor: Colors.ModelColor,
                                                                                                                                  borderWidth: mobileW * 0.5 / 100,
                                                                                                                                  borderColor: Colors.whiteColor,
                                                                                                                                  height: mobileH * 5 / 100,
                                                                                                                                  width: mobileW * 42.5 / 100,
                                                                                                                                  justifyContent: 'center',

                                                                                                                        }}>
                                                                                                                        <Text style={{
                                                                                                                                  fontSize: mobileW * 4.5 / 100,
                                                                                                                                  fontFamily: Font.FontSemiBold,
                                                                                                                                  textAlign: 'center',
                                                                                                                                  color: Colors.whiteColor
                                                                                                                        }}>{Lang_chg.Remove[config.language]}</Text>
                                                                                                              </TouchableOpacity>

                                                                                                    </View>

                                                                                                    <View style={{
                                                                                                              alignSelf: 'center',
                                                                                                              width: mobileW * 90 / 100,
                                                                                                    }}>
                                                                                                              <Text style={{
                                                                                                                        fontSize: mobileW * 3 / 100,
                                                                                                                        fontFamily: Font.FontSemiBold,
                                                                                                                        textAlign: 'center',
                                                                                                                        color: Colors.whiteColor
                                                                                                              }}>{Lang_chg.AmountUSDT[config.language]}</Text>
                                                                                                              <View style={{
                                                                                                                        height: mobileH * 5 / 100,
                                                                                                                        width: mobileW * 90 / 100,
                                                                                                                        justifyContent: 'center',
                                                                                                                        backgroundColor: Colors.ModelInsideButton,
                                                                                                                        marginTop: mobileH * 1 / 100
                                                                                                              }}>
                                                                                                                        <View style={{
                                                                                                                                  width: mobileW * 80 / 100,
                                                                                                                                  flexDirection: 'row',
                                                                                                                                  alignSelf: 'center',
                                                                                                                                  justifyContent: 'space-between',
                                                                                                                        }}>
                                                                                                                                  <Text style={{
                                                                                                                                            fontSize: mobileW * 3 / 100,
                                                                                                                                            fontFamily: Font.FontSemiBold,
                                                                                                                                            textAlign: 'center',
                                                                                                                                            color: Colors.GreyTextColor
                                                                                                                                  }}>{Lang_chg.Amount[config.language]}</Text>
                                                                                                                                  <Text style={{
                                                                                                                                            fontSize: mobileW * 3 / 100,
                                                                                                                                            fontFamily: Font.FontSemiBold,
                                                                                                                                            textAlign: 'center',
                                                                                                                                            color: Colors.YellowTextColor
                                                                                                                                  }}>{Lang_chg.Max[config.language]}</Text>
                                                                                                                        </View>
                                                                                                              </View>
                                                                                                    </View>

                                                                                                    <View style={{ marginTop: mobileH * 20 / 100 }}>
                                                                                                              <Appbutton
                                                                                                                        handlepress={() => {
                                                                                                                                  this.loginBtn()
                                                                                                                        }}
                                                                                                                        title={Lang_chg.continue_txt[config.language]}
                                                                                                              />
                                                                                                    </View>

                                                                                          </View>
                                                                                </View>
                                                                      </View>
                                                            </Modal>


                                                  </KeyboardAwareScrollView>

                                                  <Footer
                                                            activepage='Positions'
                                                            usertype={1}
                                                            footerpage={[
                                                                      {
                                                                                name: 'Home',
                                                                                fname: 'Home',
                                                                                image: localimag.home_inactive,
                                                                                activeimage: localimag.home_active,
                                                                      },
                                                                      {
                                                                                name: 'Orders',
                                                                                fname: 'Orders', image: localimag.orders_inactive,
                                                                                activeimage: localimag.orders_active,
                                                                      },
                                                                      {
                                                                                name: 'Trade',
                                                                                fname: 'Trade',
                                                                                image: localimag.trade_inactive,
                                                                                activeimage: localimag.trade_active,
                                                                      },
                                                                      {
                                                                                name: 'Positions',
                                                                                fname: 'Positions',
                                                                                image: localimag.position_inactive,
                                                                                activeimage: localimag.position_active,
                                                                      },
                                                                      {
                                                                                name: 'Wallet',
                                                                                fname: 'Wallet', image: localimag.wallet_inactive,
                                                                                activeimage: localimag.wallet_active,
                                                                      },
                                                            ]}
                                                            navigation={this.props.navigation}
                                                            imagestyle1={{
                                                                      width: mobileW * 6 / 100, height: mobileW * 6 / 100,
                                                                      backgroundColor: Colors.themeblack_color,
                                                                      countcolor: Colors.white_color,
                                                            }}
                                                  />

                                        </SafeAreaView >
                              </View>
                    )
          }
}
const styles = StyleSheet.create({
          container:
          {
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    //  backgroundColor: Colors.HomeBackColor
          },
          view1:
          {
                    height: mobileH * 8 / 100,
                    flexDirection: 'row',
                    width: mobileW * 88 / 100,
                    alignSelf: 'center',
                    alignItems: 'center',
          },
          icon1s: {
                    width: mobileW * 5 / 100,
                    height: mobileW * 5 / 100,
                    resizeMode: 'contain', alignSelf: 'center'
          },
          SizeInContracttxt:
          {
                    color: Colors.GreyTextColor,
                    fontSize: mobileW * 3.5 / 100,
                    fontFamily: Font.FontMedium
          },
          EditModeltxt: {
                    fontSize: mobileW * 3.5 / 100,
                    fontFamily: Font.FontSemiBold,
                    textAlign: 'center',
                    color: Colors.GreyTextColor
          },
          EditModeltxt1: {
                    fontSize: mobileW * 4 / 100,
                    fontFamily: Font.FontSemiBold,
                    textAlign: 'center',
                    color: Colors.whiteColor
          }


})


