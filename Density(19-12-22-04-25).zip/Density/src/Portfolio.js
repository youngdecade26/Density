import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity, ScrollView, ImageBackground } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, Footer, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appsmallbutton } from './AllComponents';

export default class Portfolio extends Component {
  constructor(props) {
    super(props)
    this.state = {
      CurrentDashboard: false,
      HrDasboard: true,
      LifetimeDasboard: false,

      HourArr: [
        {
          'id': '0',
          'Amount': '30m',
          'status': true
        },
        {
          'id': '1',
          'Amount': '1H',
          'status': false
        },
        {
          'id': '2',
          'Amount': '3H',
          'status': false
        },
        {
          'id': '3',
          'Amount': '6H',
          'status': false
        },
        {
          'id': '4',
          'Amount': '10H',
          'status': false
        },
        {
          'id': '5',
          'Amount': '24H',
          'status': false
        },
      ]
    }
  }
  componentDidMount() {

  }

  render() {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.HomeBackColor }} >
        <SafeAreaView style={styles.container}>
          <StatusBar
            hidden={false}
            translucent={false}
            barStyle="light-content"
            networkActivityIndicatorVisible={true}
          />


          {/* //==========Get Started Now Text=========// */}
          <View
            style={{
              flexDirection: 'row',
              marginTop: mobileH * 2 / 100,
              marginBottom: mobileH * 1.2 / 100,
              paddingHorizontal: mobileW * 5 / 100,
            }} >
            <View
              style={{
                width: mobileW * 89 / 100,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignSelf: 'center',
                alignItems: 'center',
              }}>
              <View>
                <Text style={{
                  color: Colors.whiteColor,
                  fontFamily: Font.FontSemiBold,
                  fontSize: mobileW * 6.3 / 100
                }}>
                  {Lang_chg.Portfolio[config.language]}
                </Text>
                <View style={{
                  width: mobileW * 22 / 100,
                  backgroundColor: Colors.yellow_color,
                  borderColor: Colors.yellow_color,
                  borderWidth: mobileW * 0.9 / 100
                }}>
                </View>
              </View>
              <View>
                <Image style={{
                  height: mobileH * 3.3 / 100,
                  width: mobileW * 6.6 / 100,
                  marginTop: mobileH * 1 / 100
                }}
                  source={localimag.YellowSearchIcon}></Image>
              </View>
            </View>
          </View>
          <View style={{
            width: mobileW * 90 / 100,
            alignSelf: 'center',
            paddingBottom: mobileH * 1.5 / 100
          }}>
            <Text style={{
              color: Colors.LoremColor,
              fontSize: mobileW * 3.5 / 100,
              fontFamily: Font.FontSemiBold
            }}>
              {Lang_chg.LoremIpsuConsecteturText[config.language]}
            </Text>
          </View>

          <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingBottom: mobileH * 20 / 100 }} keyboardShouldPersistTaps='handled'>

            <View style={{
              width: mobileW * 100 / 100, alignSelf: 'center',
            }}>

              {/* -----------HeadingBar------------ */}
              <ScrollView
                horizontal={true}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{
                  width: mobileW * 100 / 100,
                  flexDirection: 'row',
                  alignItems: 'center',
                  alignSelf: 'center'
                }}>
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => {
                    this.setState({
                      CurrentDashboard: true,
                      HrDasboard: false,
                      LifetimeDasboard: false,
                    });
                  }}
                  style={{ width: mobileW * 33.3 / 100, alignSelf: 'center', }}>

                  <Text
                    style={this.state.CurrentDashboard == true ? styles.activetabstyle : styles.inactivetabstyle}>
                    {Lang_chg.CurrentDasboard[config.language]}
                  </Text>
                  <View style={{
                    borderBottomWidth: mobileW * 0.6 / 100,
                    borderBottomColor: this.state.CurrentDashboard == true ? Colors.ButtonBarColor : Colors.whiteColor, width: '100%'
                  }}></View>
                </TouchableOpacity>

                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => {
                    this.setState({
                      CurrentDashboard: false,
                      HrDasboard: true,
                      LifetimeDasboard: false,
                    });
                  }}
                  style={{ width: mobileW * 32 / 100, alignSelf: 'center' }}>

                  <Text style={this.state.HrDasboard == true ? styles.activetabstyle : styles.inactivetabstyle}>
                    {Lang_chg.HrDasboard[config.language]}
                  </Text>
                  <View style={{
                    borderBottomWidth: mobileW * .6 / 100,
                    borderBottomColor: this.state.HrDasboard == true ? Colors.ButtonBarColor : Colors.whiteColor, width: '100%'
                  }}></View>

                </TouchableOpacity>

                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => {
                    this.setState({
                      CurrentDashboard: false,
                      HrDasboard: false,
                      LifetimeDasboard: true,
                    });
                  }}
                  style={{
                    width: mobileW * 35 / 100, alignSelf: 'center'
                  }}>
                  <Text
                    style={this.state.LifetimeDasboard == true ? styles.activetabstyle : styles.inactivetabstyle}>
                    {Lang_chg.LifetimeDasboard[config.language]}
                  </Text>
                  <View style={{
                    borderBottomWidth: mobileW * 0.6 / 100,
                    borderBottomColor: this.state.LifetimeDasboard == true ? Colors.ButtonBarColor : Colors.whiteColor, width: '100%'
                  }}></View>
                </TouchableOpacity>
              </ScrollView>


              {/* -----------Containt------------- */}
              {this.state.HrDasboard == true &&
                <View>
                  <Text style={{
                    color: Colors.PnlTextColor,
                    fontSize: mobileW * 3 / 100,
                    fontFamily: Font.FontMedium,
                    paddingVertical: mobileH * 0.2 / 100,
                    textAlign: 'center',
                    marginTop: mobileH * 2 / 100
                  }}>{Lang_chg.PortfoliValue[config.language]}</Text>
                  <Text style={[styles.Largetxt, { color: Colors.whiteColor }]}>{'$19,953.41'}
                  </Text>
                  <Text style={{
                    color: Colors.GreenText,
                    fontSize: mobileW * 3 / 100,
                    fontFamily: Font.FontMedium,
                    paddingVertical: mobileH * 0.2 / 100,
                    textAlign: 'center'
                  }}>{'+$11.22 (1.22%)'}
                  </Text>

                  {/* -------------TotalmarginUsed/maxBuyingPower------------ */}
                  <View style={[styles.justifyContentStyle, { width: mobileW * 88 / 100, marginTop: mobileH * 3 / 100 }]}>
                    <View style={{
                      width: mobileW * 43 / 100,
                      paddingVertical: mobileH * 0.5 / 100,
                      borderRightWidth: mobileW * 0.4 / 100,
                      borderRightColor: Colors.whiteColor,
                    }} >
                      <Text style={styles.MarginBuyingtxt}>{Lang_chg.TotalMarginUsed[config.language]}
                      </Text>
                      <Text style={styles.MarginBuyingtxt1}>{'$1,285'}
                      </Text>
                    </View>

                    <View style={{
                      width: mobileW * 43 / 100,
                      paddingVertical: mobileH * 0.5 / 100,
                    }} >
                      <Text style={styles.MarginBuyingtxt}>{Lang_chg.MaxBuyingPower[config.language]}
                      </Text>
                      <Text style={styles.MarginBuyingtxt1}>{'$11,091.10'}
                      </Text>
                    </View>
                  </View>
                  {/*-------------------Image------------------*/}
                  <View style={{
                    alignSelf: 'center',
                    width: mobileW * 100 / 100,
                    alignItems: 'center'
                  }}>
                    <ImageBackground
                      source={localimag.PortfoliImage}
                      style={{
                        height: mobileH * 50 / 100,
                        width: mobileW * 100 / 100,
                      }}>
                      <View style={{
                        alignSelf: 'center',
                        width: mobileW * 90 / 100,
                        alignItems: 'center'
                      }}>
                        {/* -----------FlatelistForHours-------------*/}
                        <FlatList
                          data={this.state.HourArr
                          }
                          showsHorizontalScrollIndicator={false}
                          horizontal={true}
                          contentContainerStyle={{ marginTop: mobileH * 35 / 100 }}
                          renderItem={({ item, index }) => {
                            console.log('item', item)
                            return (
                              <TouchableOpacity
                                // onPress={() => this.setAmount(5000)}
                                style={{
                                  paddingVertical: mobileH * 0.75 / 100,
                                  flexDirection: 'row',
                                  paddingHorizontal: mobileW * 1.5 / 100,
                                  alignItems: 'center'
                                }}>
                                <Text style={{
                                  borderColor: Colors.PnlTextColor,
                                  backgroundColor: item.status == true ? Colors.white_color : Colors.usdt_bg,
                                  borderWidth: mobileW * 0.25 / 100,
                                  fontFamily: Font.FontMedium,
                                  textAlign: 'center',
                                  paddingVertical: mobileH * 0.5 / 100,
                                  width: mobileW * 10 / 100,
                                  color: item.status == true ? Colors.black_color : Colors.PnlTextColor,
                                  fontSize: mobileW * 3.75 / 100
                                }}>
                                  {item.Amount}
                                </Text>
                              </TouchableOpacity>
                            )
                          }}
                        />
                      </View>

                      <View style={{
                        marginTop: mobileH * 2 / 100,
                        borderBottomWidth: mobileW * 0.3 / 100,
                        borderColor: Colors.greyColor,
                      }}>
                      </View>

                      {/* ----------------Box---------------- */}
                      <View
                        style={{
                          width: '90%',
                          alignSelf: 'center',
                          borderWidth: mobileW * 0.5 / 100,
                          borderColor: Colors.BorderColor,
                          backgroundColor: Colors.themeblack_color,
                          marginTop: mobileH * 2 / 100
                        }}>
                        <View style={[styles.justifyContentStyle, { width: mobileW * 88 / 100, }]}>
                          <View style={{
                            width: mobileW * 43 / 100,
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            paddingVertical: mobileH * 1 / 100,
                          }} >
                            <View style={[styles.justifyContentStyle, { width: mobileW * 42 / 100, }]}>
                              <Text style={styles.Boxtxt}>{Lang_chg.RealisedPnl[config.language]}
                              </Text>
                              <Text style={{
                                fontSize: mobileW * 2 / 100,
                                color: Colors.GreenText
                              }}>({'+1.23%'})
                              </Text>
                            </View>
                            <Text style={[styles.Boxtxt1, { color: Colors.GreenText }]}>{'$1,234,567.11'}
                            </Text>

                          </View>

                          <View style={{
                            width: mobileW * 43 / 100,
                            paddingVertical: mobileH * 0.5 / 100,
                          }} >
                            <Text style={styles.Boxtxt}>{Lang_chg.MarginUsed[config.language]}
                            </Text>
                            <Text style={[styles.Boxtxt1, { color: Colors.whiteColor }]}>{'$12,345.92'}
                            </Text>
                          </View>
                        </View>

                        <View style={{
                          borderBottomWidth: mobileW * 0.5 / 100,
                          borderBottomColor: Colors.BorderColor,
                          width: mobileW * 90 / 100,
                          alignSelf: 'center'
                        }}></View>

                        <View style={[styles.justifyContentStyle, { width: mobileW * 88 / 100, }]}>
                          <View style={{
                            width: mobileW * 43 / 100,
                            borderRightWidth: mobileW * 0.5 / 100,
                            borderRightColor: Colors.BorderColor,
                            paddingVertical: mobileH * 1 / 100,
                          }} >
                            <Text style={styles.Boxtxt}>{Lang_chg.VolumeTraded[config.language]}
                            </Text>
                            <Text style={[styles.Boxtxt1, { color: Colors.whiteColor }]}>{'$1,234,56.01'}
                            </Text>
                          </View>

                          <View style={{
                            width: mobileW * 43 / 100,
                            paddingVertical: mobileH * 0.5 / 100,
                          }} >
                            <Text style={styles.Boxtxt}>{Lang_chg.FeePaid[config.language]}
                            </Text>
                            <Text style={[styles.Boxtxt1, { color: Colors.whiteColor }]}>{'$123,45.33'}
                            </Text>
                          </View>
                        </View>
                      </View>
                    </ImageBackground>
                  </View>

                </View>
              }

              {/* ---------------Data For Lifetime Dasboard----------------  */}
              {this.state.LifetimeDasboard == true &&
                <View
                  style={{
                    marginTop: mobileH * 4 / 100,
                    width: mobileW * 90 / 100,
                    alignSelf: 'center',
                    borderWidth: mobileW * 0.5 / 100,
                    borderColor: Colors.BorderColor,
                    backgroundColor: Colors.CartBackColor,
                  }}>
                  <View style={{ paddingVertical: mobileH * 2 / 100 }}>
                    <Text style={{
                      color: Colors.PnlTextColor,
                      fontFamily: Font.FontSemiBold,
                      fontSize: mobileW * 3.5 / 100,
                      marginTop: mobileW * 1.4 / 100,
                      textAlign: 'center'
                    }}>{Lang_chg.ProfitLoss[config.language]}</Text>
                    <Text style={[styles.Largetxt, { color: Colors.GreenText }]}>{'$40,000'}</Text>
                  </View>

                  <View style={{
                    borderBottomWidth: mobileW * 0.5 / 100,
                    borderBottomColor: Colors.BorderColor,
                    marginTop: mobileW * 5 / 100,
                    width: mobileW * 90 / 100,
                    alignSelf: 'center'
                  }}></View>

                  <View style={[styles.justifyContentStyle, { width: mobileW * 88 / 100, }]}>
                    <View style={{
                      width: mobileW * 43 / 100,
                      borderRightWidth: mobileW * 0.5 / 100,
                      borderRightColor: Colors.BorderColor,
                      paddingVertical: mobileH * 3 / 100,
                    }} >
                      <Text style={styles.MarginBuyingtxt}>
                        {Lang_chg.MarginUsed[config.language]}
                      </Text>
                      <Text style={styles.MarginBuyingtxt1}>{'$1,285'}
                      </Text>
                    </View>

                    <View style={{
                      width: mobileW * 43 / 100,
                      paddingVertical: mobileH * 0.5 / 100,
                    }} >
                      <Text style={styles.MarginBuyingtxt}>
                        {Lang_chg.VolumeTraded[config.language]}
                      </Text>
                      <Text style={styles.MarginBuyingtxt1}>{'$11,091.10'}
                      </Text>
                    </View>
                  </View>

                </View>
              }



            </View>


          </KeyboardAwareScrollView>
        </SafeAreaView >
      </View>
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    //backgroundColor: Colors.themeblack_color
  },
  justifyContentStyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignSelf: 'center',
    alignItems: 'center',
  },

  activetabstyle: {
    color: Colors.whiteColor,
    fontFamily: Font.FontBold,
    fontSize: mobileW * 3.5 / 100,
    textAlign: config.textalign,
    alignSelf: 'center',
    paddingVertical: mobileW * 3 / 100,
  },
  inactivetabstyle: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontBold,
    fontSize: mobileW * 3.5 / 100,
    textAlign: config.textalign,
    alignSelf: 'center',
    paddingVertical: mobileW * 3 / 100,
  },
  MarginBuyingtxt: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 3.5 / 100,
    textAlign: 'center'
  },
  MarginBuyingtxt1: {
    color: Colors.whiteColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4 / 100,
    marginTop: mobileW * 0.2 / 100,
    textAlign: 'center'
  },
  Largetxt: {
    fontFamily: Font.FontBold,
    fontSize: mobileW * 8 / 100,
    marginTop: mobileW * 1.4 / 100,
    textAlign: 'center'
  },
  Boxtxt: {
    color: Colors.PnlTextColor,
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 3 / 100,
    marginLeft: mobileW * 1.5 / 100
  },
  Boxtxt1: {
    fontFamily: Font.FontSemiBold,
    fontSize: mobileW * 4.2 / 100,
    marginTop: mobileW * 0.2 / 100,
    marginLeft: mobileW * 1.5 / 100
  }

})
