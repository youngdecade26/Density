
export const localimag = {
    email: require('../Icons/email.png'),
    password: require('../Icons/password.png'),
    splash: require('../Icons/new_logo.png'),
    back: require('../Icons/back.png'),
    user: require('../Icons/user.png'),
    notification: require('../Icons/notification.png'),
    resetpassword: require('../Icons/resetpassword.png'),
    terms: require('../Icons/terms.png'),
    privacy: require('../Icons/privacy.png'),
    about: require('../Icons/about.png'),
    contact: require('../Icons/contact.png'),
    rate: require('../Icons/rate.png'),
    shareapp: require('../Icons/shareapp.png'),
    logout: require('../Icons/logout.png'),
    userplaceholder: require('../Icons/userplaceholder.png'),
    dots: require('../Icons/dots.png'),
    camera: require('../Icons/camera.png'),
    share: require('../Icons/share.png'),
    pen: require('../Icons/pen.png'),
    no_data: require('../Icons/no_data.png'),
    cancel: require('../Icons/cancel.png'),
    down: require('../Icons/down.png'),


    Applogo: require('../Icons/1024x1024_bg.png'),

    up_arrow: require('../Icons/up_arrow.png'),
    splashlogo: require('../Icons/1024x1024_logo.png'),
    density_256: require('../Icons/density_256.png'),
    show: require('../Icons/show.png'),
    Hide: require('../Icons/hide.png'),
    checkbox: require('../Icons/checkbox.png'),
    checkbox_Checked: require('../Icons/checkbox_Checked.png'),
    CheckBlack: require('../Icons/checked_black.png'),
    UncheckBlack: require('../Icons/box_grey_box.png'),
    google: require('../Icons/google.png'),
    checked: require('../Icons/checked.png'),
    empty: require('../Icons/empty.png'),
    left: require('../Icons/left.png'),
    wallet_bg: require('../Icons/wallet_bg.png'),
    person_bg: require('../Icons/person_bg.png'),
    illustration: require('../Icons/illustration.png'),
    message: require('../Icons/message.png'),

    // ---------------------------------
    ObjectiveOneImage: require('../Icons/OBJECTS_one.png'),
    ObjectiveTwoImage: require('../Icons/OBJECTS_two.png'),
    ObjectiveThreeImage: require('../Icons/OBJECTS_three.png'),
    ObjectiveBottomOneImage: require('../Icons/Group_image_one.png'),
    ObjectiveBottomTwoImage: require('../Icons/Group_image_two.png'),
    ObjectiveBottomThreeImage: require('../Icons/Group_image_three.png'),
    // ---------------------------------

    // ------------Position-------------
    YellowSearchIcon: require('../Icons/Search_color.png'),
    DownYerrowIcon: require('../Icons/dropdown_bg.png'),
    EditIcon: require('../Icons/edit_icon.png'),
    ShareIcon: require('../Icons/share_icon.png'),
    ErrorIcon: require('../Icons/message_error.png'),

    // -----------Home/Order-----------
    market_1: require('../Icons/market_1.png'),
    market_2: require('../Icons/market_2.png'),
    searchwhite: require('../Icons/searchwhite.png'),

    star_fill: require('../Icons/star_fill.png'),
    star_unfill: require('../Icons/star_unfill.png'),
    cancel_white: require('../Icons/cancel_white.png'),
    copy: require('../Icons/copy.png'),
    dropdown_bg: require('../Icons/dropdown_bg.png'),

    market_1: require('../Icons/market_1.png'),
    market_2: require('../Icons/market_2.png'),
    searchwhite: require('../Icons/searchwhite.png'),
    dropdown: require('../Icons/dropdown.png'),
    dropdown_up: require('../Icons/dropdown_up.png'),

    market_3: require('../Icons/market_3.png'),
    red_dropdown: require('../Icons/red_dropdown.png'),
    green_dropdown: require('../Icons/green_dropdown.png'),
    RedDown: require('../Icons/red_Down.png'),
    GreenRightArrow: require('../Icons/arrow_right_icon.png'),

    refresh: require('../Icons/refresh.png'),
    ReverseRefresh: require('../Icons/reverse.png'),

    calender_deactive: require('../Icons/calender_deactive.png'),
    calender_Active: require('../Icons/calender_Active.png'),
    calenderSs: require('../Icons/calenderSs.png'),

    // -------------Trade------------
    UpwardArrow: require('../Icons/upward_arrow.png'),
    DownWordArrow: require('../Icons/dropdown_Yellow.png'),
    Settings: require('../Icons/settings.png'),
    Widepng: require('../Icons/wide.png'),
    TreadingImage: require('../Icons/trading.png'),
    AddIcon: require('../Icons/add_icon.png'),
    YellowRadioActice: require('../Icons/radio_Active.png'),
    RadioInactice: require('../Icons/radion_inactive.png'),
    RedTradeBackImage: require('../Icons/GroupTrade.png'),
    GreenTradeBackImage: require('../Icons/Grouptradeone.png'),


    // --------Portfoli--------
    PortfoliImage: require('../Icons/bg.png'),


    ShareFrame: require('../Icons/shareframe.png'),
    ShareEmail: require('../Icons/Frame_email.png'),
    ShareWhatsapp: require('../Icons/whatsapp.png'),
    FrameTalegram: require('../Icons/Group.png'),
    FrameLinkedin: require('../Icons/Frame_linkedin.png'),
    Framesave: require('../Icons/Frame_save.png'),


    //------------FooterImages-------------
    home_active: require('../Icons/home.png'),
    home_inactive: require('../Icons/home_inactive.png'),
    orders_active: require('../Icons/ordeer_active.png'),
    orders_inactive: require('../Icons/orders.png'),
    trade_active: require('../Icons/trade.png'),
    trade_inactive: require('../Icons/trade_inActive.png'),
    wallet_active: require('../Icons/wallet_Active.png'),
    wallet_inactive: require('../Icons/wallet.png'),
    position_active: require('../Icons/positon_Active.png'),
    position_inactive: require('../Icons/position.png'),


}