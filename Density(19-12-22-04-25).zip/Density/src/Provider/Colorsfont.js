// import Positions from "../Positions"

export const Colors = {

    //------fixed color

    statusbarcolor: '#1F1F24',

    whiteColor: '#FFFFFF',
    black_color: '#000000',
    PlaceholderTextcolor: '#3a3a3a',
    BorderColor: '#454545',
    InputTextColor: '#E5E5EA',
    placeholder_color: '#d4d0d6',
    Placeholdercolor: '#A5A5A5',
    themeblack_color: '#1F1F24',
    HomeBackColor: '#28282E',
    text_color: '#737374',
    yellow_color: '#8E9F4E',
    text_color: '#3a3a3a',
    text_color2: '#454545',
    ModelColor: '#383840',
    ModelInsideButton: '#44444D',

    faltlistBorderHome: '#343439',
    green_type_color: '#0A966C',
    usdt_bg: '#313131',
    green_color: '#06A676',
    ButtonBarColor: '#E2FF6F',
    TermsColor: '#C7C7C8',
    GreyText: '#9FAFBB',
    YellowTextColor: '#E2FF6F',


    // -------Positions-------
    CartBackColor: '#2C2C34',
    PnlTextColor: '#9999A7',
    GreenText: '#00BD84',
    GreenButton: '#00BD84',
    RedButton: '#F24E53',
    OrangeColor: '#F46151',
    TogglebuttonBack: '#32333A',
    LoremColor: '#6B6B6E',
    GreyTextColor: '#676771',

    // --------Order---------
    greyTextColor: '#787878',



    theme_color: '#1985ff',
    statusbar: '#1985ff',
    internetbackcolor: 'green',
    onlinebackcolor: 'green',
    internettextcolor: '#FFFFFF',
    onlinetextcolor: '#FFFFFF',
    mediabackground: '#FFFFFF',
    mediatextcolor: 'black',
    cancletextcolor: 'black',
    buttoncolor: 'red',
    whiteColor: '#FFFFFF',
    white_color: '#FFFFFF',
    greyColor: 'gray',
    Otpresedcolor: 'green',
    otpcountcolor: 'red',
    otpverifycolor: '#1985ff',
    back_color: 'FFFFFF',
    border_color: '#efefee',
    text_color: '#3a3a3a',
    text_color2: '#454545',

    drawer_text_color: '#1E1E1E',


    explore_text_color: '#131313',
    res_time_color: '#B9B3B3',
    complete_color: '#88D594',
    imcomplete_color: '#C14F4F',
    textbackground_color: '#28282E',
    redColor: 'red',
    text_color3: '#5F5F60'


    //----developer color----------//
    // color for this app ---------------




    // RadioArr: [
    //     {
    //       'id': '0',
    //       'Name': '1Day',
    //       'statusRadio': false
    //     },
    //     {
    //       'id': '1',
    //       'Name': '1Week',
    //       'statusRadio': false
    //     },
    //     {
    //       'id': '2',
    //       'Name': '1Month',
    //       'statusRadio': true
    //     },
    //     {
    //       'id': '3',
    //       'Name': '3Months',
    //       'statusRadio': false
    //     },
    //     {
    //       'id': '2',
    //       'Name': 'Custom',
    //       'statusRadio': false
    //     },
    //   ]


}
export const Font = {
    FontBold: 'Overpass-Bold',
    FontBoldItalic: 'Overpass-BoldItalic',
    FontExtraBold: 'Overpass-ExtraBold',
    FontExtraBoldItalic: 'Overpass-ExtraBoldItalic',
    FontItalic: 'Overpass-Italic',
    FontLight: 'Overpass-Light',
    FontExtraLightItalic: 'Overpass-ExtraLightItalic',
    FontLightItalic: 'Overpass-LightItalic',
    FontRegular: 'Overpass-Regular',
    FontSemiBold: 'Overpass-SemiBold',
    FontSemiBoldItalic: 'Overpass-SemiBoldItalic',
    FontBlack: 'Overpass-Black',
    FontBlackItalic: 'Overpass-BlackItalic',
    FontExtraLight: 'Overpass-ExtraLight',
    FontMedium: 'Overpass-Medium',
    FontMediumItalic: 'Overpass-MediumItalic',
    FontThin: 'Overpass-Thin',
    FontThinItalic: 'Overpass-ThinItalic',
}