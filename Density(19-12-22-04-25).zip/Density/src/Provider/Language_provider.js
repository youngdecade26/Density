import { Alert, ToastAndroid, I18nManager, Platform } from "react-native";
import { localStorage } from './localStorageProvider';
import { AsyncStorage } from 'react-native';
import { config } from "./configProvider";
import RNRestart from 'react-native-restart';
import { consolepro } from './Messageconsolevalidationprovider/Consoleprovider'
global.language_key = 1;
class Language_provider {

  language_get = async () => {
    var item = await localStorage.getItemObject('language');
    console.log('check launguage option', item)

    consolepro.consolelog('is rtl', I18nManager.isRTL)
    consolepro.consolelog('is rtl config', config.textalign)

    if (item != null) {
      console.log('kya bat h developer', config.language)
      config.language = item;
    }
    console.log('language_key123', config.language)
    if (item != null) {
      if (item == 0) {

        config.textalign = 'left'
        config.inverted = false
      } else {

        config.textalign = 'right'
        config.inverted = true
      }

    } else {
      I18nManager.forceRTL(false);
      I18nManager.allowRTL(false);
      config.textalign = 'left'
      config.inverted = false
      localStorage.setItemObject('language', 0)

    }
  }

  language_set = async (languagem) => {

    console.log('I18nManager.isRTL Developer', I18nManager.isRTL)
    if (languagem == 0) {
      I18nManager.forceRTL(false);
      I18nManager.allowRTL(false);
      config.textalign = 'left';
      config.inverted = false
      localStorage.setItemObject('language', 0)
      localStorage.removeItem('languagecathc')
      localStorage.removeItem('languagesetenglish');
      config.language = 0
    }
    else {
      I18nManager.forceRTL(true);
      I18nManager.allowRTL(true);
      config.textalign = 'right';
      config.inverted = true
      localStorage.setItemObject('language', 1)
      localStorage.setItemObject('languagecathc', 0)
      config.language = 1
    }

    setTimeout(() => {
      RNRestart.Restart()
    }, 500);
  }
  // Media option ///////////////////
  MediaCamera = ['Choose Camera', ''];
  Mediagallery = ['Choose Gallery', ''];
  cancelmedia = ['Cancel', ''];

  //-----------not for developer use start ------------------//
  go_back_txt = ['Go back', 'Go back']
  do_you_want_exit_txt = ['Do you want to exit app', 'Do you want to exit app']
  do_you_want_goback_txt = ['Do you want to go back', 'Do you want to go back']
  verify_txt = ['Verify', 'Verify']
  resend_txt = ['Resend', 'Resend']
  email_txt = ['Email', 'Email']
  OTP_txt = ['OTP', 'OTP']
  Logout_txt = ['Logout', 'Logout']
  are_you_logout = ['Are you sure , you want to logout?', 'Are you sure , you want to logout?']
  notification_arr = ['Notification', 'Notification']
  terms_and_condition_txt = ['Terms and Conditions', 'Terms and Conditions']
  privacy_policy_txt = ['Privacy Policy', 'Privacy Policy']
  about_us_txt = ['About Us', 'About Us']
  delete_account_txt = ['Delete Account', 'حذف الحساب']
  are_you_sure_delete_txt = ['Are you sure ?', 'هل انت متأكد من حذف الحساب؟']
  content_not_found = ['Content Not Available', 'Content Not Available']
  Contactus = ['Contact Us', 'Contact Us']
  changepassword_txt = ['Change Password', 'Change Password']
  Setting = ['Setting', 'Setting']
  notification = ['notification', 'notification']
  rate_app = ['Rate App', 'Rate App']
  share_app = ['Share App', 'Share App']
  Logout = ['Logout', 'Logout']
  Show = ['Show', 'Show']
  Hide = ['Hide', 'Hide']

  //--for chat start --------

  online_txt = ['Online',]
  offline_txt = ['Offline',]
  type_something_txt = ['Type Something',]

  //-----------------------chat page-------------------------------//
  chattextinputmessage = ['Message', '']
  chataction = ['Action', 'Action', '']
  chatreport = ['Report User', '']
  chatclear = ['Clear Chat', '']
  chatcancel = ['Cancel', '']
  reportmessagepopup = ['Are your sure you want to ? report', '']
  chatclearpopup = ['Are your sure you to ? clear chat', '']
  ChooseMedia = ['Choose', ''];
  Confirm = ["Confirm", '']
  block_permission = ['Are you sure? you want to block this user', '']
  unblock_permission = ['Are you sure? you want to unblock this user', '']
  select_option_txt = ['Select Option', '']
  report_txt = ['Report', '']
  chats_txt = ['Chats', '']
  block_txt = ['Block', '']
  unblock_txt = ['Unblock', '']
  cancel_txt = ['Cancel', '']
  submit_txt = ['Submit', '']
  reason_txt = ['Reason', '']
  search_here_txt = ['Search here',]
  you_blocked_this_user = ['You Block this person']
  no_txt = ['No', 'No']
  yes_txt = ['Yes', 'Yes']
  //--for chat end --------

  //-------create password start-------------//
  create_password_txt = ['Create Password']
  //-------create password end -------------//
  //-------Delete Account start-------------//
  delete_acc_txt = ['Delete Account']
  //-------Delete Account end -------------//
  //-------FAQ's"start-------------//
  faq_txt = ["FAQ's"]
  //-------FAQ's"end -------------//

  //-----------notification start ---------//
  notifications_txt = ['Notifications']
  clear_all = ['Clear All']
  info = ['Information']
  areyousure_txt = ['Are you sure , you want to clear notifications?']
  //-----------notification end

  //----------signup----------//
  signup_txt = ['Signup']
  fullname_txt = ['Full Name']
  mobile_no_txt = ['Mobile Number']
  address_txt = ['Address']
  pincode_txt = ['Pin Code']
  cpass_txt = ['Confirm Password']
  iaccept_txt = ['I Accept all']
  terms_txt = ['Terms & Conditions']
  changepassword_txt = ['Change Password']
  and_txt = ['and']
  Privacy_policy_txt = ['Privacy Policy.']
  you_already_txt = ['You already have an account?']
  enter_registered_txt = ['Enter Registered E-mail Id ']
  india_txt = ['India']
  canada_txt = ['Canada']
  enter_password = ['Password'];
  login_txt = ['Login'];
  density_txt = ['density'];
  welcomeback_txt = ['Welcome Back !'];
  password_txt = ['Password'];
  remember_me_txt = ['Remember me'];
  forgot_password_txt = ['Forgot Password ?'];
  continue_txt = ['Continue'];
  or_txt = ['or'];
  continuenwithgoogle_txt = ['Continue With Google '];
  not_registered_yet_txt = ['Not registered yet ?'];
  signup_here_txt = ['Signup here'];
  get_started_now_txt = ['Get started now'];
  your_password_should_txt = ['Your password should contain'];
  should_contain_txt = ['Should contain 8-16 characters'];
  one_lower_case_txt = ['One lower case'];
  one_upper_case_txt = ['One upper case'];
  one_number_txt = ['One number'];
  one_special_character_txt = ['One Special character(eg.@,&,*)'];
  got_a_referral_code_txt = ['Got a referral code ?'];
  i_agree_to_the_txt = ["By Signing Up you are agreeing to the Density "];
  Exchanges = ["Exchange's"]
  terms_of_use_txt = ["Terms of Use  "];
  get_started_txt = ["Get Started!  "];
  already_a_user_txt = ["Already a user ? "];
  Login_here_txt = ["Login here "];
  confirm_your_txt = ["Confirm your email "];
  I_didnt_receive_txt = ["I didn't receive my email."];
  send_again_txt = ["Send Again"];
  enter_your_phone_txt = ["Enter Your Phone Number"];
  mobile_number_txt = ["Phone Number"];
  enter_mobile_number_txt = ["Enter Phone Number"];
  send_otp_txt = ["Send OTP"];
  please_enter_the_otp_txt = ["Please Enter The OTP"];
  same_to_validate_continue_txt = ["A 6 digit OTP has been sent to 9******908 kindly enter the same to validate and continue with your trading journey"];

  resend_otp_txt = ["Resend OTP"];
  didnt_recieve_it_txt = ["Didn't receive it ?"];
  market_txt = ["Market"];
  lorem_ipsum_dolot_txt = ["Lorem ipsum dolor sit amet"];
  highest_24h_turnover_txt = ["Highest 24h Turnover"];
  ethereum_txt = ["Ethereum"];
  usdt_txt = ["USDT"];
  all_txt = ["ALL"];
  Favourites_txt = ["Favourites"];
  Bitcoin_txt = ["Bitcoin"];
  inr_txt = ["INR"];
  Solana_txt = ["Solana"];
  Solana_txt = ["USDT"];

  // ------------10-12-22-11-24-AM------------
  refferalNumber = ["123456"]
  SendOTP = ["Send OTP"]


  // --------ObjectiveScreenText---------
  ConsecteturDummyText = ["consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam"]
  EmailPlaceholder = ["Enter Email"]
  PasswordPlaceholder = ["Enter Password"]









  // -----------Home-----------
  rise_percent = ['24%'];
  vol_562b_text = ['Vol 5.62B']
  search_for_crypto_txt = ['Search for cryptos here...',]
  MostSearched = ['Most Searched']
  Cryptos_everyone = ['Cryptos everyone is looking for.']
  BTC_USDT = ['BTC/USDT']
  num_19953 = ['$19,953.4']
  num_122 = ['+1.22%']
  ETH_USDT = [' ETH/USDT']
  num_1322 = [' $1,322.7']
  num_328 = ['+3.28%']
  DOGE_USDT = ['DOGE/USDT']
  num_0 = ['$0.003.31']
  num_7 = ['-7.71%']
  TRX_USDT = ['TRX/USDT']
  num_53 = ['$53.66']
  num_1 = ['-1.22%']
  INRWALLET = ['INR WALLET']
  USDTWALLET = ['USDT WALLET']
  TotalINRBalance = ['Total INR Balance']
  num_1234 = ['12,3459']
  Deposit = ['Deposit']
  Withdraw = ['Withdraw']
  BuyUSDT = ['Buy USDT']
  SellUSDT = ['Sell USDT']
  TransactionHistory = ['Transaction History']
  Volume = ['Volume']


  // -----------Orders-----------
  Orders = ['Orders']

  OpenOrders = ['Open Orders']
  OrderHistory = ['Order History']
  TradeHistory = ['Trade History']
  BUY = ['BUY']
  BTCUSDT = ['BTCUSDT']
  june6 = ['6 Jun 22:12']
  ltp = ['LTP']
  num_1962 = ['$19620.50']
  Size = ['Size(in contract)']
  Price = ['Price']
  ReduceOnly = ['Reduce Only']
  num045 = ['0.4551']
  num92 = ['-92.5']
  NO = ['NO']
  sizeusdt = ['Size (in USDT)']
  Filled011 = ['0/11 Filled']
  TriggerPrice = ['Trigger Price']
  OrderId = ['Order Id']
  num38140121 = ['38140121']
  CancelOrder = ['Cancel Order']
  solana_text = ['Solana']

  rise_percent2 = ['+24%'];
  all_text = ["All"];
  Cancel_order_text = ["You're about to close the Position"]
  Cancel_order_text2 = ["for BTCUSDT. Are you sure you"]
  Cancel_order_text3 = ["want to exit ?  "]
  average = ['Average']

  num193 = ['19357.200']
  Price = ['Price']
  num1900 = ['19000']
  Executed = ['Executed']
  Amount = ['Amount']

  quantity_text = ["Quantity"]
  fee = ['Fee']
  realized_profit = ['Realized Profit']
  day1 = ['1 Day']
  month1 = ['1 Month']
  week1 = ['1 Week']
  months3 = ['3 Months']
  custom = ['Custom']

  // ----------SelectDate----------
  select_date_range = ['Select Date Range']
  select_date = ['Select Date']
  reset_text = ["Reset"]


  // ------------TradePage-------------
  MarkPrice = ["Mark Price"]
  IndexPrice = ["Index Price"]
  FundingCountdown = ["Funding/Countdown"]
  HChange = ["24h Change"]
  HHigh = ["24h High"]
  HLow = ["24h Low"]
  HValueUSDT = ["24h Val (USDT)"]
  OpenInterset = ["Open Interest"]
  Buy = ['Buy']
  Sell = ['Sell']
  ReferenceId = ["Reference Id: "]
  OneH = ["1H"]
  Line = ["Line"]
  Compare = ['Compare']
  Sell = ['Sell']
  Indicators = ["Indicators"]
  AvailableBalance = ["Available Balance:"]
  AvailableBalanceTXT = ["20 USDT"]
  Leverange = ["Leverage"]
  MaxBuyPower = ["Max Buying Power:"]
  SizeInUSDT = ["Size in USDT"]
  SizeTaxt = ["Size"]
  TriggerPrice = ["Trigger Price"]
  MinimumQuality = ["Minimum Quantity:"]
  StepSize = ["Step Size:"]
  MarginUsed2 = ["Margin Used:"]
  BTC = ["BTC"]
  TP = ["TP"]
  SL = ["SL"]
  TakeProfit = ["Take Profit"]
  StopLose = ["Stop Loss"]
  Max = ["Max"]
  Cost = ["Cost"]
  Market = ["Market"]
  Limit = ["Limit"]
  StopMarket = ["Stop Market"]
  StopLimit = ["Stop Limit"]
  Last = ["Last"]
  UsdtTxt = ["USDT"]
  Perpetual = ["Perpetual"]

  CurrentlyMrginText = ["Currently margin for BTCUSDT perpetual"]
  MaxAddable = ["Max addable"]
  PriceAfterIncrease = ["Est. Liq. price after increase"]

  Add = ["Add"]
  Remove = ["Remove"]
  AmountUSDT = ["Amount (USDT)"]

  ShareTxt = ["Share with your friend!"]
  Whatsapp = ["Whatsapp"]
  Telegram = ["Telegram"]
  Gmail = ["Gmail"]
  LinkedIn = ["LinkedIn"]
  SaveImage = ["Save Image"]

  // -------PositionsPage-------
  Positions = ["Positions"]
  TotalPnL = ["Total PnL"]
  TotalPnLNumber = ["+89.10"]
  PnL = ["PnL"]
  PnLNumber = ["39.058"]
  LTP = ["LTP"]
  LTPNumber = ["$19620.50"]
  SizeInContract = ["Size(In contract)"]
  EntryPrice = ["Entry Price"]
  LiqudationPrice = ["Liqudation Price"]
  SizeInValue = ["Size(In value)"]
  MarginRatio = ["Margin Ratio"]
  MarginUsed = ["Margin Used"]
  ClosePosition = ["Close Position"]
  BTCUSDT1X = ["BTCUSDT | 1x"]
  BuyOrderModelText = ["You're about to close the BUY"]
  BuyOrderModelText1 = ["Order for"]
  BuyOrderModelText2 = ["BTCUSDT"]
  BuyOrderModelText3 = ["(6/11/Filled)."]
  ExitToModel = ["Are you sure you want to exit ?"]
  AdjustMargin = ["Adjust Margin"]
  Available = ["Available"]

  // ------------Wallet-------------
  LoremIpsumElitText = ["Lorem ipsum consectetur adipiscing elit."]
  ADay = ["1Day"]
  AWeek = ["1Week"]
  AMonth = ["1Month"]
  threeDay = ["3months"]
  Custom = ["Custom"]
  TotalMarginBalance = ["TOTAL MARGIN BALANCE"]
  FreeMarginBalance = ["FREE MARGIN BALANCE"]
  Realised24HPnl = ["REALISED 24h Pnl"]
  Chart = ["Chart"]
  Orderbook = ["Orderbook"]
  RecentTrades = ["Recent Trades"]
  PriceUSDT = ["Price(USDT)"]
  SizeUSDT = ["Size(USDT)"]
  SumUSDT = ["Sum(USDT)"]
  Time = ["Time"]
  Bids = ["Bids"]
  Asks = ["Asks"]
  EnterAmountInINR = ["Enter Amount in INR"]
  AmountInUSDT = ["Amount In USDT:"]
  INR = ["INR"]
  OneUSDT = ["1 USDT:"]
  EnterAmountInUSDT = ["Enter Amount in USDT"]
  AmountInINR = ["Amount in INR:"]
  TDSChargesLevied = ["TDS Charges Levied:"]


  // -----------Deposit/Withdrow------------
  Deposit = ['Deposit']
  Registered_acc_num = ['Registered Account Number']
  Density = ['Density']
  enter_deposit = ['Enter Deposit Amount']
  num5000 = ['5,000']
  num2000 = ['2,000']
  num1000 = ['1,000']
  num500 = ['500']
  transfer_money = ['Transfer Money to this Bank Account']
  Beneficiary_entity = ['Beneficiary Entity']
  Pagarpay_ind_pvt = ['PAGARPAY INDIA PRIVATE LIMITED']

  Beneficiary_acc_num = ['Beneficiary Account Number']
  Beneficiary_acc_num2 = ['0937480SBXHBA2E12E']
  Benefic_ifsc = ['Beneficiary IFSC Number']
  Benefic_ifsc2 = ['ESFB0003031']
  bank_acc_type = ['Bank Account Type']
  bank_acc_num = ['8924789740']
  deposit_msg = ["The amount should be deposited with above bank account only.Amount coming from any other bank account would be refunded back."]
  transfer_usdt = ['Transfer to USDT Wallet directly']
  WithdrowToAccountDir = ['Withdraw to your account directly']

  // ---------PortFolio---------
  Portfolio = ["Portfolio"]
  LoremIpsuConsecteturText = ["Lorem ipsum consectetur adipiscing elit."]
  CurrentDasboard = ["Current Dasboard"]
  HrDasboard = ["24 Hr Dasboard"]
  LifetimeDasboard = ["Lifetime Dasboard"]
  PortfoliValue = ["PORTFOLIO VALUE"]
  TotalMarginUsed = ["TOTAL MARGIN USED"]
  MaxBuyingPower = ["MAX BUYING POWER"]
  MarginUsed = ["Margin Used"]
  ProfitLoss = ["Profit/Loss"]
  VolumeTraded = ["Volume Traded"]
  RealisedPnl = ["Realised PnL"]
  FeePaid = ["Fee Paid"]

  //  ----------14-12-22-01-09-----------
  enter_withdraw = ['Enter Withdraw Amount']
  BuyUsdt = ['Buy USDT']
  SellUsdt = ['Sell USDT']
  enter_amount = ['Enter Amount in INR']
  enter_amount_usdt = ['Enter Amount in USDT']
  amount_usdt = ['Amount in USDT : ']
  usdt_1 = ['1 USDT :']
  num_44220 = ['44,220']
  num_8844 = ['88.44 INR']
  max_text = ['MAX']
  tds_charges = ['TDS Charges Levied:']
  percent_1 = ['1% (0 INR)']
  Withdraw_account = ['Withdraw to your account directly']



  //-----------not for developer use end ------------------//


}
export const Lang_chg = new Language_provider();