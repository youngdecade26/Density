import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, Modal, ImageBackground, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { color } from 'react-native-reanimated';
import { Keyboard } from 'react-native';
import { Appbutton ,TextInputCmp} from './AllComponents';


export default class Deposit extends Component {

    constructor(props) {
        super(props)
        this.state = {
            amount: '',
            refferal: false,

            TranseferMoneyArr: [
                {
                    'id': '0',
                    'Name': Lang_chg.transfer_money[config.language],
                    'Detail': Lang_chg.Pagarpay_ind_pvt[config.language],
                },
                {
                    'id': '1',
                    'Name': Lang_chg.Beneficiary_acc_num[config.language],
                    'Detail': Lang_chg.Pagarpay_ind_pvt[config.language],
                },
                {
                    'id': '2',
                    'Name': Lang_chg.Benefic_ifsc[config.language],
                    'Detail': Lang_chg.Benefic_ifsc2[config.language],
                },
                {
                    'id': '3',
                    'Name': Lang_chg.bank_acc_type[config.language],
                    'Detail': Lang_chg.bank_acc_num[config.language],
                }
            ],
            AmountArr: [
                {
                    'id': '0',
                    'Amount': '5,000',
                    'status': true
                },
                {
                    'id': '1',
                    'Amount': '2,000',
                    'status': false
                },
                {
                    'id': '2',
                    'Amount': '1,000',
                    'status': false
                },
                {
                    'id': '3',
                    'Amount': '5,000',
                    'status': false
                },
            ]


        }
    }
    componentDidMount() {

        this.props.navigation.addListener('focus', payload => {

        })
    }
//-------------for accept terms and conditions---------------
refferal = () => {
    if (this.state.refferal) {
      this.setState({ refferal: false })
    } else {
      this.setState({ refferal: true })
    }
  }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        translucent={false}
                        barStyle="light-content"
                        networkActivityIndicatorVisible={true}
                    />

                    {/* heading  and back icon */}

                    <View style={{
                        width: mobileW * 95 / 100, alignItems: 'center',
                        marginTop: mobileH * 2 / 100,
                        alignSelf: 'center', flexDirection: 'row',
                    }}>

                        {/* -----------back icon image--------- */}
                        <TouchableOpacity
                            onPress={() => this.props.navigation.goBack()
                            }
                            style={{
                                alignSelf: 'center',
                                paddingVertical: mobileH * 1 / 100,
                                paddingHorizontal: mobileW * 2.5 / 100,
                                alignItems: 'center',
                            }}>
                            <Image style={{
                                width: mobileW * 5 / 100,
                                height: mobileW * 5 / 100
                            }}
                                resizeMode='contain' source={localimag.left}></Image>
                        </TouchableOpacity>

                        {/* -------Deposit range heading Text--------- */}

                            <Text style={{
                                color: Colors.placeholder_color,
                                fontSize: mobileW * 5 / 100, fontFamily: Font.FontSemiBold
                            }}>{Lang_chg.Deposit[config.language]}</Text>

                    </View>

                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={{ width: mobileW, paddingBottom: mobileH * 5 / 100 }}
                        keyboardShouldPersistTaps='handled'>

                        {/*  Registered Account num Text and its value */}

                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>

                            {/* -------Registered Account num Text-------*/}
                            <View style={{
                                flexDirection: 'row',
                                marginTop: mobileH * 2 / 100,
                                alignItems: 'center',
                                paddingBottom: mobileH * 1.2 / 100,
                            }}>
                                <Text style={{
                                    color: Colors.PnlTextColor,
                                    fontSize: mobileW * 3.5 / 100,
                                    fontFamily: Font.FontSemiBold
                                }}>{Lang_chg.Registered_acc_num[config.language]}</Text>
                            </View>

                            <View style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                width: mobileW * 90 / 100,
                                backgroundColor: Colors.usdt_bg,
                            }}>
                                <Text
                                    numberOfLines={1}
                                    style={{
                                        color: Colors.PnlTextColor,
                                        fontSize: mobileW * 4 / 100,
                                        fontFamily: Font.FontMedium,
                                        paddingHorizontal: mobileW * 3 / 100,
                                        paddingVertical: mobileH * 2.5 / 100,
                                    }}>
                                    1234567890 {Lang_chg.Density}</Text>
                            </View>

                        </View>

                        {/* ---------Enter deposit amount and its value----------*/}

                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>

                                <TextInputCmp
                                    htitle={Lang_chg.enter_deposit[config.language]}
                                    Keyboard={'numeric'}
                                    maxLength={100}
                                />
                         
                        </View>

                        {/* all amounts(5000, 1000,500 ) view*/}
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginTop: mobileH * 2 / 100 }}>
                            <FlatList
                                data={this.state.AmountArr
                                }
                                showsHorizontalScrollIndicator={false}
                                horizontal={true}
                                contentContainerStyle={{}}
                                renderItem={({ item, index }) => {
                                    console.log('item', item)
                                    return (
                                        <View>
                                            <TouchableOpacity
                                                // onPress={() => this.setAmount(5000)}
                                                style={{
                                                    paddingVertical: mobileH * 0.75 / 100,
                                                    flexDirection: 'row',
                                                    paddingHorizontal: mobileW * 1.5 / 100
                                                }}>
                                                <Text style={{
                                                    borderColor: Colors.PnlTextColor,
                                                    backgroundColor: item.status == true ? Colors.white_color : Colors.usdt_bg,
                                                    borderWidth: mobileW * 0.25 / 100,
                                                    fontFamily: Font.FontMedium,
                                                    alignSelf: 'center',
                                                    paddingVertical: mobileH * 0.5 / 100,
                                                    paddingHorizontal: mobileW * 3 / 100,
                                                    color: item.status == true ? Colors.black_color : Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.75 / 100
                                                }}>
                                                    ₹{item.Amount}
                                                </Text>
                                            </TouchableOpacity>
                                        </View>
                                    )
                                }}
                            />
                        </View>


                        {/* ---transfer money Text and  Beneficiary entity---*/}
                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>
                            {/*  -------transfer money Text------- */}
                            <View style={{
                                flexDirection: 'row',
                                marginTop: mobileH * 2 / 100,
                                alignItems: 'center',
                                paddingBottom: mobileH * 1.2 / 100,
                            }}>
                                <Text style={{
                                    color: Colors.white_color,
                                    fontSize: mobileW * 4.25 / 100,
                                    fontFamily: Font.FontSemiBold
                                }}>{Lang_chg.transfer_money[config.language]}</Text>
                            </View>
                            {/* ---------------Flatelist--------------- */}
                            <FlatList
                                data={this.state.TranseferMoneyArr
                                }
                                contentContainerStyle={{}}
                                renderItem={({ item, index }) => {
                                    console.log('item', item)
                                    return (
                                        <View>
                                            <View style={{
                                                flexDirection: 'row', marginTop: mobileH * 2 / 100,
                                                alignItems: 'center',
                                                justifyContent: 'space-between',
                                            }}>
                                                <Text style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.5 / 100,
                                                    fontFamily: Font.FontSemiBold
                                                }}>{item.Name}</Text>
                                                <TouchableOpacity>
                                                    <Image style={{
                                                        top: mobileH * 1.5 / 100,
                                                        width: mobileW * 4 / 100,
                                                        height: mobileW * 4 / 100,
                                                    }} resizeMode='contain' source={localimag.copy}></Image>
                                                </TouchableOpacity>
                                            </View>

                                            {/* --------------------------- */}
                                            <View>
                                                <Text style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100,
                                                    fontFamily: Font.FontSemiBold
                                                }}>{item.Detail}</Text>
                                            </View>

                                            <View style={{
                                                marginTop: mobileH * 2 / 100,
                                                borderBottomWidth: mobileW * 0.3 / 100,
                                                borderColor: Colors.greyColor,
                                            }}>
                                            </View>
                                        </View>
                                    )
                                }}
                            />
                        </View>

                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                            paddingBottom: mobileW * 15 / 100
                        }}>
                            <View style={{
                                flexDirection: 'row', marginTop: mobileH * 2 / 100,
                            }}>
                                <Image style={{
                                    top: mobileH * 0.5 / 100,
                                    width: mobileW * 4 / 100,
                                    height: mobileW * 4 / 100,
                                    tintColor: Colors.PnlTextColor
                                }} resizeMode='contain' source={localimag.empty}></Image>

                                <Text style={{
                                    color: Colors.PnlTextColor,
                                    marginLeft: mobileW * 2 / 100,
                                    fontSize: mobileW * 3.5 / 100,
                                    fontFamily: Font.FontSemiBold
                                }}>{Lang_chg.deposit_msg[config.language]}</Text>
                            </View>
                        </View>

                        {/*  transfer to usdt text view */}

                        <View style={{
                            width: mobileW * 90 / 100,
                            paddingBottom: mobileH * 2 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>
                            {/*  transfer to usdt text view */}
                            <TouchableOpacity 
                             onPress={() => this.refferal()}
                            style={{
                                flexDirection: 'row',
                            }}>
                                 <Image style={{
              
              width: mobileW * 4 / 100,
              height: mobileW * 4 / 100,
            }} resizeMode='contain' source={this.state.refferal ? localimag.CheckBlack : localimag.UncheckBlack}></Image>

           <Text style={{
                                  color: Colors.PnlTextColor,
                                  marginLeft: mobileW * 2 / 100,
                                  fontSize: mobileW * 3.5 / 100,
                                  fontFamily: Font.FontSemiBold
                              }}>{Lang_chg.transfer_usdt[config.language]}</Text>
                            </TouchableOpacity>
                        </View>

                       
                        {/* confirm button */}

                        <Appbutton
                            handlepress={() => {
                                this.props.navigation.navigate('Wallet')
                            }}
                            title={Lang_chg.Confirm[config.language]}
                        />

                    </KeyboardAwareScrollView>
                </SafeAreaView >
            </View >
        )
    }
}
const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: Colors.HomeBackColor
    },
})
