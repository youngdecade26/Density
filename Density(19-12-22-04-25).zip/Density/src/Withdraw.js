import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, Modal, ImageBackground, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { color } from 'react-native-reanimated';
import { Keyboard } from 'react-native';
import { Appbutton ,TextInputCmp} from './AllComponents';


export default class Withdraw extends Component {
    constructor(props) {
        super(props)
        this.state = {
            amount: '',
            TranseferMoneyArr: [

                {
                    'id': '0',
                    'Name': Lang_chg.Beneficiary_acc_num[config.language],
                    'Detail': Lang_chg.Beneficiary_acc_num2[config.language],
                },
                {
                    'id': '1',
                    'Name': Lang_chg.Benefic_ifsc[config.language],
                    'Detail': Lang_chg.Benefic_ifsc2[config.language],
                },

            ],
            AmountArr: [
                {
                    'id': '0',
                    'Amount': '5,000',
                    'status': true
                },
                {
                    'id': '1',
                    'Amount': '2,000',
                    'status': false
                },
                {
                    'id': '2',
                    'Amount': '1,000',
                    'status': false
                },
                {
                    'id': '3',
                    'Amount': '5,000',
                    'status': false
                },
            ]
        }
    }
    componentDidMount() {

        this.props.navigation.addListener('focus', payload => {

        })
    }


    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        translucent={false}
                        barStyle="light-content"
                        networkActivityIndicatorVisible={true}
                    />

                    {/* heading  and back icon */}

                    <View style={{
                        width: mobileW * 91.25 / 100, alignItems: 'center',
                        marginTop: mobileH * 2 / 100,
                        alignSelf: 'center', flexDirection: 'row',
                    }}>

                        {/* ---------back icon image------- */}
                        <TouchableOpacity
                            onPress={() => this.props.navigation.goBack()
                            }
                            style={{
                                alignSelf: 'center',
                                paddingVertical: mobileH * 1 / 100,
                                alignItems: 'center',
                            }}>
                            <Image style={{
                                width: mobileW * 5 / 100,
                                height: mobileW * 5 / 100
                            }}
                                resizeMode='contain' source={localimag.left}></Image>
                        </TouchableOpacity>

                        {/*----------- Withdraw  heading Text--------- */}
                    
                            <Text style={{
                                marginLeft:mobileW*2.5/100,
                                color: Colors.placeholder_color,
                                fontSize: mobileW * 5 / 100, fontFamily: Font.FontSemiBold
                            }}>{Lang_chg.Withdraw[config.language]}</Text>
                    </View>

                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={{ width: mobileW, paddingBottom: mobileH * 5 / 100 }}
                        keyboardShouldPersistTaps='handled'>

                        {/* Enter deposit amount and its value*/}
                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>

                            {/*  Enter withdraw amount Text */}
                            <TextInputCmp
                                    htitle={Lang_chg.enter_withdraw[config.language]}
                                    Keyboard={'numeric'}
                                    maxLength={100}
                                />
                        </View>


                        {/* all amounts(5000, 1000,500 ) view*/}
                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', marginTop: mobileH * 2 / 100 }}>
                            <FlatList
                                data={this.state.AmountArr
                                }
                                showsHorizontalScrollIndicator={false}
                                horizontal={true}
                                contentContainerStyle={{}}
                                renderItem={({ item, index }) => {
                                    console.log('item', item)
                                    return (
                                        <View>
                                            <TouchableOpacity
                                                // onPress={() => this.setAmount(5000)}
                                                style={{
                                                    paddingVertical: mobileH * 0.75 / 100,
                                                    flexDirection: 'row',
                                                    paddingHorizontal: mobileW * 1.5 / 100
                                                }}>
                                                <Text style={{
                                                    borderColor: Colors.PnlTextColor,
                                                    backgroundColor: item.status == true ? Colors.white_color : Colors.usdt_bg,
                                                    borderWidth: mobileW * 0.25 / 100,
                                                    fontFamily: Font.FontMedium,
                                                    alignSelf: 'center',
                                                    paddingVertical: mobileH * 0.5 / 100,
                                                    paddingHorizontal: mobileW * 3 / 100,
                                                    color: item.status == true ? Colors.black_color : Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.75 / 100
                                                }}>
                                                    ₹{item.Amount}
                                                </Text>
                                            </TouchableOpacity>
                                        </View>
                                    )
                                }}
                            />
                        </View>

                        {/* ---------------Flatelist--------------- */}
                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            justifyContent: 'space-between',
                        }}>
                            <FlatList
                                data={this.state.TranseferMoneyArr
                                }
                                contentContainerStyle={{ paddingBottom: mobileW * 25 / 100 }}
                                renderItem={({ item, index }) => {
                                    console.log('item', item)
                                    return (
                                        <View>
                                            <View style={{
                                                flexDirection: 'row', marginTop: mobileH * 2 / 100,
                                                alignItems: 'center',
                                                justifyContent: 'space-between',
                                            }}>
                                                <Text style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.5 / 100,
                                                    fontFamily: Font.FontSemiBold
                                                }}>{item.Name}</Text>
                                                <TouchableOpacity>
                                                    <Image style={{
                                                        top: mobileH * 1.5 / 100,
                                                        width: mobileW * 4 / 100,
                                                        height: mobileW * 4 / 100,
                                                    }} resizeMode='contain' source={localimag.copy}></Image>
                                                </TouchableOpacity>
                                            </View>

                                            {/* --------------------------- */}
                                            <View>
                                                <Text style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100,
                                                    fontFamily: Font.FontSemiBold
                                                }}>{item.Detail}</Text>
                                            </View>

                                            <View style={{
                                                marginTop: mobileH * 2 / 100,
                                                borderBottomWidth: mobileW * 0.3 / 100,
                                                borderColor: Colors.greyColor,
                                            }}>
                                            </View>
                                        </View>
                                    )
                                }}
                            />
                        </View>

                        {/* ------------Continue button---------- */}
                        <Appbutton
                            handlepress={() => {
                                this.props.navigation.navigate('Wallet')
                            }}
                            title={Lang_chg.continue_txt[config.language]}
                        />

                    </KeyboardAwareScrollView>
                </SafeAreaView >
            </View >
        )
    }
}
const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: Colors.HomeBackColor
    },
})
