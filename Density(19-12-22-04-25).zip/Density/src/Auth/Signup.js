import React, { Component } from 'react';
import { Text, BackHandler, SafeAreaView, StatusBar, KeyboardAvoidingView, Alert, View, StyleSheet, Keyboard, Dimensions, ImageBackground, TouchableOpacity, Image, Modal, FlatList, ScrollView, RadioButton, Button, TextInput, ActivityIndicator, } from 'react-native'
import { config, msgProvider, localStorage, apifuntion, msgText, msgTitle, consolepro, Lang_chg, Font, Colors, mobileH, mobileW, localimag, notification } from '../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import CountDown from 'react-native-countdown-component';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons'
import { Appbutton, TextInputCmp } from '../AllComponents';

class Signup extends Component {

    constructor(props) {
        super(props)
        this.state = {
            activeinput: '0',
            txt: '0',
            mobile: '',
            btn: true,
            email: '',
            password: '',
            securetext: true,
            // securetext2: false,
            password: '',
            confirmpassword: '',
            firstname: '',
            lastname: '',
            refferal: false,
            user_id: '',
            otp: '',
            showbtn: false,
            fullname: '',
            country_code: '91',
            country_code_modal: false,
            country_code_arr: [{
                code: '1',
                status: false,
                flag: localimag.canada,
                name: 'Canada'
            },
            {
                code: '91',
                status: true,
                flag: localimag.india,
                name: 'India'
            },
            ],
            social_data: 'NA',
            password_hide: false,
            email_edit: true,
            fullname_edit: true,
            otp_loader: false,

            AddTab: '0',

            PassGuidArr: [
                {
                    'id': '0',
                    'instruction': 'Should contain 8-16 characters'
                },
                {
                    'id': '1',
                    'instruction': 'One Lower case'
                },
                {
                    'id': '2',
                    'instruction': 'One upper case'
                },
                {
                    'id': '3',
                    'instruction': 'One Number'
                },
                {
                    'id': '4',
                    'instruction': 'One Special character (g.@,&,*)'
                },

            ]
        }

    }


    onFocus() {
        this.setState({
            backgroundColor: 'green'
        })
    }

    onBlur() {
        this.setState({
            backgroundColor: '#ededed'
        })
    }


    componentDidMount() {
        const { navigation } = this.props;
        this.focusListener = navigation.addListener('focus', () => {
            this.setProfileData();
        });
        this.setState({ social_data: 'NA' })
        this.setProfileData();
    }
    //---------set profile while social login---------//
    setProfileData = async () => {
        let result = await localStorage.getItemObject('socialdata');
        // alert(JSON.stringify(result))
        consolepro.consolelog({ result })
        if (result != null) {
            let email = result.social_email;
            let fullname = result.social_name;
            if (email != null) {
                this.setState({ email: email, email_edit: false, social_data: result, password_hide: true })
            }
            if (fullname != null) {
                this.setState({ fullname: fullname, fullname_edit: false, social_data: result, password_hide: true })
            }
        }
    }

    //---------for password-------------
    eyepress1 = () => {
        if (this.state.securetext1) {
            this.setState({ securetext1: false })
        } else {
            this.setState({ securetext1: true })
        }
    }

    //-----------------for confirm password-----------------
    eyepress2 = () => {
        if (this.state.securetext) {
            this.setState({ securetext: false })
        } else {
            this.setState({ securetext: true })
        }
    }

    //-------------for accept terms and conditions---------------
    refferal = () => {
        if (this.state.refferal) {
            this.setState({ refferal: false })
        } else {
            this.setState({ refferal: true })
        }
    }


    //------------------signup function--------------
    signup_btn = () => {
        Keyboard.dismiss();
        let { fullname, email, mobile, password, confirmpassword, remember_me, address, pincode, country_code } = this.state;
        consolepro.consolelog({ fullname, email, mobile, password, confirmpassword, remember_me, address, pincode, country_code })
        //  alert(fullname+email+mobile+password+confirmpassword)
        //------------------fullname===================
        if (fullname.length <= 0) {
            msgProvider.toast(msgText.emptyName[config.language], 'center')
            return false
        }
        if (fullname.length <= 2) {
            msgProvider.toast(msgText.nameMinLength[config.language], 'center')
            return false
        }
        //======================================mobile============================
        if (mobile.length <= 0) {
            msgProvider.toast(msgText.emptyMobile[config.language], 'center')
            return false
        }
        if (mobile.length < 7) {
            msgProvider.toast(msgText.mobileMinLength[config.language], 'center')
            return false
        }
        var mobilevalidation = config.mobilevalidation;
        if (mobilevalidation.test(mobile) !== true) {
            msgProvider.toast(msgText.validMobile[config.language], 'center')
            return false
        }
        //=======================================email============================
        if (email.length <= 0) {
            msgProvider.toast(msgText.emptyEmail[config.language], 'center')
            return false
        }
        var emailvalidation = config.emailvalidation;
        if (emailvalidation.test(email) !== true) {
            msgProvider.toast(msgText.validEmail[config.language], 'center')
            return false
        }


        //==================================password===================
        if (password.length <= 0) {
            msgProvider.toast(msgText.emptyPassword[config.language], 'center')
            return false
        }
        if (password.length <= 5) {
            msgProvider.toast(msgText.passwordMinLength[config.language], 'center')
            return false
        }
        if (password.length > 15) {
            msgProvider.toast(msgText.passwordMaxLength[config.language], 'center')
            return false
        }
        var pattern = config.passwordvalidation;
        if (pattern.test(password) !== true) {
            msgProvider.toast(msgText.validPassword[config.language], 'center')
            return false
        }

        //==================================confirmpassword===================
        if (confirmpassword.length <= 0) {
            msgProvider.toast(msgText.emptyConfirmPassword[config.language], 'center')
            return false
        }
        if (confirmpassword.length <= 5) {
            msgProvider.toast(msgText.confirmPasswordMinLength[config.language], 'center')
            return false
        }
        if (confirmpassword !== password) {
            msgProvider.toast(msgText.passwordNotMatch[config.language], 'center')
            return false
        }
        if (remember_me == false) {
            msgProvider.toast(msgText.acceptTerms[config.language], 'center')
            return false
        }
        let url = config.baseURL + "signup.php";
        var data = new FormData();
        data.append('name', fullname)
        data.append('email', email)
        data.append('mobile', mobile)
        data.append('password', password)
        data.append("login_type", config.login_type)
        data.append("device_type", config.device_type)
        data.append("player_id", player_id_me1)

        consolepro.consolelog('data', data)
        consolepro.consolelog('url', url)
        // return false
        apifuntion.postApi(url, data).then((obj) => {
            consolepro.consolelog('user_arr', obj)
            if (obj.success == 'true') {
                var user_arr = obj.user_details;
                var user_id = user_arr.user_id;
                var email_arr = obj.email_arr;
                var otp = user_arr.otp;
                var otp_verify = user_arr.otp_verify;

                localStorage.setItemString('user_id', JSON.stringify(user_id));
                localStorage.setItemObject('user_arr', user_arr);
                localStorage.setItemString('password', this.state.password);
                localStorage.setItemString('email', this.state.email);
                //-------otp page redirection here....
                this.props.navigation.navigate('OtpVerification');
            }
            else {
                setTimeout(() => {
                    msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                    return false;
                }, 300);

            }
        }).catch((error) => {
            consolepro.consolelog("-------- error ------- " + error);

        });
    }

    //----------function for social login ----------------//

    _btnSocialDataSubmit = () => {
        consolepro.consolelog('I am in social login')
        Keyboard.dismiss()
        return false
        let { fullname, email, mobile, password, confirmpassword, remember_me, address, pincode, country_code } = this.state;
        consolepro.consolelog({ fullname, email, mobile, password, confirmpassword, remember_me, address, pincode, country_code })
        //  alert(fullname+email+mobile+password+confirmpassword)
        //======================================mobile============================
        if (mobile.length <= 0) {
            msgProvider.toast(msgText.emptyMobile[config.language], 'center')
            return false
        }
        if (mobile.length < 9) {
            msgProvider.toast(msgText.mobileMinLength[config.language], 'center')
            return false
        }
        if (mobile.length > 10) {
            msgProvider.toast(msgText.mobileMaxLength[config.language], 'center')
            return false
        }
        var mobilevalidation = config.mobilevalidation;
        if (mobilevalidation.test(mobile) !== true) {
            msgProvider.toast(msgText.validMobile[config.language], 'center')
            return false
        }


        //------------------address===================
        if (address.length <= 0) {
            msgProvider.toast(msgText.emptyAddress[config.language], 'center')
            return false
        }
        if (address.length <= 2) {
            msgProvider.toast(msgText.addressMinLength[config.language], 'center')
            return false
        }
        // if (address.length > 500) {
        //     msgProvider.toast(msgText.addressMaxLength[config.language], 'center')
        //     return false
        // }
        // var addressvalidation = config.addressvalidation;
        // if (addressvalidation.test(address) !== true) {
        //     msgProvider.toast(msgText.validAddress[config.language], 'center')
        //     return false
        // }


        //------------------pincode===================
        if (pincode.trim().length <= 0) {
            msgProvider.toast(msgText.emptyPincode[config.language], 'center')
            return false
        }

        if (pincode.trim().length > 6) {
            msgProvider.toast(msgText.pincodeMaxLength[config.language], 'center')
            return false
        }
        var mobilevalidation = config.mobilevalidation;
        if (mobilevalidation.test(pincode) !== true) {
            msgProvider.toast(msgText.validPincode[config.language], 'center')
            return false
        }

        if (remember_me == false) {
            msgProvider.toast(msgText.acceptTerms[config.language], 'center')
            return false
        }



        let url = config.baseURL + "signup.php";
        var data = new FormData();
        data.append('name', fullname)
        data.append('email', email)
        data.append('mobile', mobile)
        data.append('address', address.trim())
        data.append('pincode', pincode)
        data.append('phone_code', country_code)
        data.append("login_type", this.state.social_data.logintype)
        data.append("social_id", this.state.social_data.social_id)
        data.append("device_type", config.device_type)
        data.append("player_id", player_id_me1)

        consolepro.consolelog('data', data)
        apifuntion.postApi(url, data).then((obj) => {
            consolepro.consolelog('user_arr', obj)
            // alert(JSON.stringify(obj))
            if (obj.success == 'true') {
                var user_arr = obj.user_details;
                var user_id = user_arr.user_id;
                var notification_arr = obj.notification_arr;
                consolepro.consolelog({ notification_arr })
                consolepro.consolelog({ notification_arr })
                if (notification_arr != "NA") {
                    consolepro.consolelog({ notification_arr })
                    notification.notification_arr(notification_arr);
                }


                localStorage.setItemString('user_id', JSON.stringify(user_id));
                localStorage.setItemObject('user_arr', user_arr);
                localStorage.setItemString('email', this.state.email);
                localStorage.removeItem('socialdata')
                this.props.navigation.navigate('Home');

            }
            else {
                msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                return false;
            }
        }).catch((error) => {
            consolepro.consolelog("-------- error ------- " + error);

        });

    }


    //---------------------SetCountryCode function -------------
    SetCountryCode = (item, index) => {
        consolepro.consolelog({ item, index })
        let data = this.state.country_code_arr;
        let len = this.state.country_code_arr.length;
        for (let i = 0; i < len; i++) {
            data[i].status = false;
        }

        data[index].status = !data[index].status;
        this.setState({
            country_code: data[index].code,
            country_code_modal: false,
            country_code_arr: data,
        })
    }

    //----------------SetCountryCode funtion end------------//

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        backgroundColor={Colors.themeblack_color}
                        translucent={false}
                        barStyle="light-content"
                        networkActivityIndicatorVisible={true}
                    />
                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'
                    >
                        {/* //==========Image & density Text=========// */}
                        <View style={{
                            width: mobileW,
                            alignItems: 'center',
                            alignSelf: 'center'
                        }}>
                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                                flexDirection: 'row',
                                marginTop: mobileH * 3 / 100,
                                alignItems: 'center'
                            }}>
                                <Image style={{
                                    width: mobileW * 4.5 / 100,
                                    height: mobileW * 4.5 / 100
                                }}
                                    resizeMode='contain'
                                    source={localimag.density_256}>
                                </Image>
                                <View style={{ paddingHorizontal: mobileW * 1 / 100, }}>
                                    <Text style={{
                                        color: Colors.whiteColor,
                                        fontSize: mobileW * 5.5 / 100,
                                        fontFamily: Font.FontSemiBold
                                    }}>{Lang_chg.density_txt[config.language]}</Text>
                                </View>
                            </View>
                            {/* //==========Get Started Now Text=========// */}
                            <View style={{
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                                flexDirection: 'row',
                                marginTop: mobileH * 7 / 100
                            }}>
                                <Text style={{
                                    color: Colors.whiteColor,
                                    fontSize: mobileW * 6.3 / 100,
                                    fontFamily: Font.FontBold
                                }}>{Lang_chg.get_started_now_txt[config.language]}
                                </Text>
                            </View>
                            {/* //==========Email Text=========// */}
                            <View style={{
                                width: mobileW * 90 / 100,
                                alignItems: 'center',
                                alignSelf: 'center',
                                marginTop: mobileH * 3 / 100
                            }}>
                                <TextInputCmp
                                    htitle={Lang_chg.email_txt[config.language]}
                                    placeholder={Lang_chg.EmailPlaceholder[config.language]}
                                    Keyboard={'email-address'}
                                    maxLength={100}
                                    onChangeText={(txt) => { this.setState({ email: txt }) }}
                                />


                                {/* <TextInputCmp
                                    htitle={Lang_chg.password_txt[config.language]}
                                    placeholder={Lang_chg.PasswordPlaceholder[config.language]}
                                    Keyboard={'default'}
                                    onpresshandler={() => {
                                        this.eyepress2()
                                    }}
                                    securetext={this.state.securetext}
                                    Close={localimag.Hide}
                                    Open={localimag.show}
                                    maxLength={16}
                                    onChangeText={(txt) => { this.setState({ password: txt }) }}
                                    onBlur={() => this.onBlur()}
                                    onFocus={() => this.onFocus()}
                                    style={{ height: 60, backgroundColor: this.state.backgroundColor, color: this.state.color }} /> */}


                                <View style={{
                                    width: mobileW * 90 / 100,
                                    alignSelf: 'center',
                                    flexDirection: 'row',
                                    marginTop: mobileH * 2 / 100
                                }}>
                                    <Text style={{
                                        color: Colors.whiteColor,
                                        fontSize: mobileW * 3.9 / 100,
                                        fontFamily: Font.FontRegular
                                    }}>{Lang_chg.password_txt[config.language]}</Text>
                                </View>
                                <View style={{
                                    width: mobileW * 90 / 100,
                                    marginTop: mobileH * 1 / 100,
                                    height: mobileH * 7 / 100,
                                    backgroundColor: Colors.textbackground_color,
                                    borderRadius: mobileW * 1 / 100,
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    borderColor: Colors.text_color2,
                                    borderWidth: 0.5
                                }}>
                                    <TextInput style={{
                                        fontFamily: Font.FontRegular,
                                        width: mobileW * 80 / 100,
                                        fontSize: mobileW * 4 / 100,
                                        backgroundColor: Colors.textbackground_color,
                                        marginLeft: mobileW * 2 / 100,
                                        color: Colors.placeholder_color
                                    }}
                                        placeholderTextColor={Colors.Placeholdercolor}
                                        placeholder={Lang_chg.PasswordPlaceholder[config.language]}
                                        Keyboard={'default'}
                                        returnKeyLabel='done'
                                        returnKeyType='done'
                                        ref={(input) => { this.mobilefield = input; }}
                                        onSubmitEditing={() => { Keyboard.dismiss() }}
                                        maxLength={16}
                                        secureTextEntry={this.state.securetext}
                                        onFocus={() => { this.setState({ errorno: 0, AddTab: 1 }) }}
                                    />
                                    <TouchableOpacity activeOpacity={0.7} style={{
                                        justifyContent: 'center',
                                        alignSelf: 'center',
                                    }}
                                        onPress={() => {
                                            this.eyepress2()
                                        }}>
                                        {this.state.securetext == true ?
                                            <Image style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }}
                                                source={localimag.Hide}>
                                            </Image>
                                            :
                                            <Image style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100 }}
                                                source={localimag.show}>
                                            </Image>
                                        }
                                    </TouchableOpacity>
                                </View>



                                {/* //==========Got a referral code text ========// */}

                                {this.state.AddTab == 1 &&
                                    (this.state.refferal == false &&
                                        <View style={{ height: mobileH * 26 / 100 }}>
                                            <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', flexDirection: 'row', marginTop: mobileH * 1 / 100 }}>
                                                <Text style={{ color: Colors.whiteColor, fontSize: mobileW * 3.7 / 100, fontFamily: Font.FontRegular }}>{Lang_chg.your_password_should_txt[config.language]}</Text>
                                            </View>

                                            <FlatList
                                                data={this.state.PassGuidArr}
                                                contentContainerStyle={{}}
                                                showsVerticalScrollIndicator={false}
                                                renderItem={({ item, index }) => {
                                                    console.log('item', item)
                                                    return (
                                                        <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'center', marginTop: mobileH * 1.5 / 100 }}>
                                                            <Image style={{ width: mobileW * 3.5 / 100, height: mobileW * 3.5 / 100, }} source={localimag.checked}></Image>
                                                            <Text style={{ color: Colors.placeholder_color, fontFamily: Font.FontRegular, fontSize: mobileW * 3.7 / 100, marginLeft: mobileW * 2 / 100 }}>{item.instruction}</Text>
                                                        </View>
                                                    )
                                                }}
                                            />
                                        </View>
                                    )
                                }


                                <View style={{
                                    width: mobileW * 90 / 100,
                                    marginTop: mobileH * 2 / 100,
                                    flexDirection: 'row',
                                    alignItems: 'center'
                                }}>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => this.refferal()}
                                        style={{ flexDirection: 'row', alignItems: 'center' }}>

                                        {this.state.refferal ?
                                            <Image style={{ width: mobileW * 3.5 / 100, height: mobileW * 3.5 / 100 }} source={localimag.checkbox_Checked}>
                                            </Image>
                                            :
                                            <Image style={{ width: mobileW * 3.5 / 100, height: mobileW * 3.5 / 100 }} source={localimag.checkbox}>
                                            </Image>
                                        }
                                        <Text style={{ color: Colors.yellow_color, fontFamily: Font.FontSemiBold, fontSize: mobileW * 3.9 / 100, marginLeft: mobileW * 2 / 100 }}>{Lang_chg.got_a_referral_code_txt[config.language]}</Text>

                                    </TouchableOpacity>
                                </View>



                                {/* //============I agree text ========// */}
                                <View style={{
                                    width: mobileW * 90 / 100,
                                    marginTop: mobileH * 20 / 100,
                                }}>
                                    <Text style={{
                                        color: Colors.TermsColor,
                                        fontFamily: Font.FontBold,
                                        fontSize: mobileW * 3.7 / 100,
                                    }}>{Lang_chg.i_agree_to_the_txt[config.language]}
                                    </Text>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Text style={{
                                            color: Colors.TermsColor,
                                            fontFamily: Font.FontBold,
                                            fontSize: mobileW * 3.7 / 100,
                                        }}>{Lang_chg.Exchanges[config.language]}
                                        </Text>
                                        <TouchableOpacity
                                            onPress={() => this.props.navigation.navigate('Contentpage', { pagename: Lang_chg.terms_txt[config.language], contentpage: 2 })}
                                            style={{
                                                marginLeft: mobileW * 1 / 100,
                                            }}>
                                            <Text style={{
                                                color: Colors.yellow_color,
                                                fontFamily: Font.FontBold,
                                                fontSize: mobileW * 3.8 / 100
                                            }}>{Lang_chg.terms_of_use_txt[config.language]}
                                            </Text>
                                        </TouchableOpacity>
                                        <Text style={{
                                            color: Colors.yellow_color,
                                            fontFamily: Font.FontBold,
                                            fontSize: mobileW * 3.8 / 100,
                                            marginLeft: mobileW * 0 / 100
                                        }}>{Lang_chg.and_txt[config.language]}</Text>
                                        <TouchableOpacity
                                            onPress={() => this.props.navigation.navigate('Contentpage', { pagename: Lang_chg.Privacy_policy_txt[config.language], contentpage: 1 })}
                                            style={{ marginLeft: mobileW * 1 / 100, }}>
                                            <Text style={{
                                                color: Colors.yellow_color,
                                                fontFamily: Font.FontBold,
                                                fontSize: mobileW * 3.8 / 100
                                            }}>{Lang_chg.Privacy_policy_txt[config.language]}
                                            </Text>

                                        </TouchableOpacity>
                                    </View>
                                </View>

                                {/* //==========Continue Submit =========// */}
                                <View style={{ marginTop: mobileH * 2 / 100 }}>
                                    <Appbutton
                                        handlepress={() => {
                                            this.props.navigation.navigate('ConfirmEmail')
                                        }}
                                        title={Lang_chg.get_started_txt[config.language]}
                                    />
                                </View>

                                {/* //=========OR======// */}
                                <View style={{
                                    alignSelf: 'center',
                                    width: mobileW * 90 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    marginTop: mobileH * 1 / 100,
                                    alignItems: 'center'
                                }}>
                                    <View style={{
                                        height: mobileW * 0.4 / 100,
                                        backgroundColor: Colors.placeholder_color,
                                        width: mobileW * 34 / 100,
                                    }}></View>
                                    <View style={{}}>
                                        <Text style={{
                                            fontFamily: Font.FontSemiBold,
                                            fontSize: mobileW * 4.7 / 100,
                                            color: Colors.text_color
                                        }}>{Lang_chg.or_txt[config.language]}</Text>
                                    </View>
                                    <View style={{
                                        height: mobileW * 0.4 / 100,
                                        backgroundColor: Colors.placeholder_color,
                                        width: mobileW * 34 / 100
                                    }}></View>
                                </View>
                                {/* //===========Google======// */}
                                <TouchableOpacity
                                    activeOpacity={0.7} style={{
                                        height: mobileH * 6.5 / 100,
                                        width: mobileW * 90 / 100,
                                        alignSelf: 'center',
                                        borderColor: Colors.placeholder_color,
                                        borderWidth: mobileW * 0.3 / 100,
                                        justifyContent: 'center',
                                        alignItems: 'center',
                                        marginTop: mobileH * 1 / 100
                                    }}>
                                    <View style={{
                                        flexDirection: 'row',
                                        width: mobileW * 49 / 100,
                                        alignSelf: 'center',
                                        alignItems: 'center',
                                        justifyContent: 'space-between'
                                    }}>
                                        <Image style={styles.icon1s} source={localimag.google}></Image>
                                        <Text style={{
                                            color: Colors.whiteColor,
                                            fontSize: mobileW * 4 / 100,
                                            fontFamily: Font.FontBold,
                                            textAlign: 'center'
                                        }}>
                                            {Lang_chg.continuenwithgoogle_txt[config.language]}
                                        </Text>
                                    </View>
                                </TouchableOpacity>

                                <View
                                    style={{
                                        alignItems: 'center',
                                        alignSelf: 'center',
                                        flexDirection: 'row',
                                        marginTop: mobileH * 2 / 100,
                                        marginBottom: mobileH * 4 / 100
                                    }} >
                                    <Text style={{
                                        color: Colors.res_time_color,
                                        fontFamily: Font.FontSemiBold,
                                        fontSize: mobileW * 4 / 100
                                    }}>{Lang_chg.already_a_user_txt[config.language]}</Text>
                                    <TouchableOpacity
                                        onPress={() => this.props.navigation.navigate('Login')}
                                        activeOpacity={0.7}
                                        style={{
                                            marginLeft: mobileW * 1 / 100
                                        }}>
                                        <Text style={{
                                            color: Colors.yellow_color,
                                            fontFamily: Font.FontBold,
                                            fontSize: mobileW * 4 / 100
                                        }}>{Lang_chg.Login_here_txt[config.language]}</Text>
                                        <View style={{
                                            width: mobileW * 20 / 100,
                                            justifyContent: 'center',
                                            alignSelf: 'center',
                                            borderColor: Colors.BorderColor,
                                            borderWidth: mobileW * 0.2 / 100,
                                            marginRight: mobileW * 0.5 / 100
                                        }}>
                                        </View>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </View>
                    </KeyboardAwareScrollView>
                </SafeAreaView >
            </View>
        )
    }
} export default Signup

const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: Colors.themeblack_color
    },
    // otp pop start ===================
    otptitle: {
        fontFamily: Font.FontBold,
        fontSize: 26,
        textAlign: 'center',
        marginTop: 10,
    },
    optTxt: {
        textAlign: 'center',
        fontFamily: Font.FontSemiBold,
        fontSize: 14,
        color: '#CBC9C9'
    },
    otpInpoutType: {
        borderWidth: 1,
        borderColor: '#ccc',
        width: '80%',
        alignSelf: 'center',
        textAlign: 'center',
        height: 40,
        marginTop: 15,
        marginBottom: 20,
    },
    verifyBox: {
        flexDirection: 'row',
        borderTopWidth: 1,
        borderColor: '#ccc',
        marginTop: 10,
    },
    resendboxLeft: {
        width: '50%',
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        borderRightWidth: 1,
        borderColor: '#ccc',
        paddingTop: 15,
        paddingBottom: 15,
    },
    resendbox: {
        width: '50%',
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        paddingTop: 15,
        paddingBottom: 15,
    },
    OTpLeftverify: {
        color: Colors.theme_color,
        fontFamily: Font.FontBold,
        fontSize: mobileW * 4 / 100,
    },
    icon1s: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        resizeMode: 'contain', alignSelf: 'center'
    },

})

