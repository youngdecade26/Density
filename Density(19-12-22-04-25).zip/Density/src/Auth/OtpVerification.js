import React, { Component, useRef } from 'react'
import { View, Text, SafeAreaView, StatusBar, ImageBackground, Image, TouchableOpacity, TextInput, BackHandler, Alert, Keyboard } from 'react-native'
import OTPTextView from 'react-native-otp-textinput'
import { config, msgProvider, localStorage, apifuntion, msgText, msgTitle, consolepro, Lang_chg, Font, Colors, mobileH, mobileW, localimag, notification } from '../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import CountDown from 'react-native-countdown-component';
import { Appbutton } from '../AllComponents';

export default class OtpVerification extends Component {
    constructor(props) {
        super(props)
        this.state = {
            otpText: '',
            otp: '',
            user_id: 0,
            showbtn: false,
        }
    }
    componentDidMount() {
        consolepro.consolelog('Iam otp page ')
    }


    //--------------------------resend funcation ---------------------
    Resendotpbtn = async () => {
        if (config.app_status == 0) {
            this.setState({ showbtn: false, })
            return false
        } else {
            Keyboard.dismiss()
            let result = await localStorage.getItemString('user_id');
            consolepro.consolelog('result', result);
            let user_id_get = 0;
            if (result != null) {
                user_id_get = result;
                this.setState({
                    user_id: user_id_get,
                })
            }
            let url = config.baseURL + "resend_otp.php";
            var data = new FormData();
            data.append('user_id', user_id_get)
            consolepro.consolelog('data', data)
            apifuntion.postApi(url, data, 1).then((obj) => {
                consolepro.consolelog('user_arr', obj)
                if (obj.success == 'true') {
                    let otp = (obj.otp).toString();
                    var email_arr = obj.email_arr;
                    consolepro.consolelog('resend', obj);
                    this.setState({ showbtn: false, })
                }
                else {
                    msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                    return false;
                }
            }).catch((error) => {
                consolepro.consolelog("-------- error ------- " + error);

            });
        }
    }

    //-------------------otp verification funcation----------------------
    Otpveryfication = async () => {

        if (config.app_status == 0) {
            this.props.navigation.navigate('Home')
            return false
        } else {
            Keyboard.dismiss()
            let result = await localStorage.getItemString('user_id');
            consolepro.consolelog('result', result);
            let user_id_get = 0;
            if (result != null) {
                user_id_get = result;
                this.setState({
                    user_id: user_id_get,
                })
            }
            var otp = this.state.otp;
            if (otp.length <= 0) {
                msgProvider.toast(msgText.emptyOtp[config.language], 'center')
                return false
            }
            if (otp.length < 4) {
                msgProvider.toast(msgText.otpMinLength[config.language], 'center')
                return false
            }
            let url = config.baseURL + "otp_verify.php";
            var data = new FormData();
            data.append('user_id', user_id_get)
            data.append('otp', otp)
            consolepro.consolelog('data', data)
            apifuntion.postApi(url, data, 1).then((obj) => {
                consolepro.consolelog('otp res', obj)
                if (obj.success == 'true') {
                    var user_arr = obj.user_details;
                    let user_id = user_arr.user_id;
                    let email = user_arr.email;
                    let otp_verify = user_arr.otp_verify;
                    let profile_complete = user_arr.profile_complete;
                    var notification_arr = obj.notification_arr;
                    consolepro.consolelog({ notification_arr })
                    if (otp_verify == 0) {
                        this.setState({
                            user_id: user_id,
                            email: email,
                            showbtn: false
                        })
                    }
                    if (otp_verify == 1) {
                        {
                            consolepro.consolelog({ notification_arr })
                            if (notification_arr != "NA") {
                                consolepro.consolelog({ notification_arr })
                                notification.notification_arr(notification_arr);
                            }
                            this.setState({
                                otppopup: false,
                            })
                            localStorage.setItemString('user_id', JSON.stringify(user_id));
                            localStorage.setItemObject('user_arr', user_arr);
                            localStorage.setItemString('email', this.state.email);
                            this.props.navigation.navigate('Home')
                        }
                    }
                }
                else {
                    setTimeout(() => {
                        msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                        return false;
                    }, 300);

                }
            }).catch((error) => {
                consolepro.consolelog("-------- error ------- " + error);
            });
        }
    }


    render() {
        return (

            <SafeAreaView style={{ flex: 1, backgroundColor: Colors.themeblack_color }}>
                <StatusBar
                    barStyle='light-content'
                    backgroundColor={Colors.statusbarcolor}
                    hidden={false} translucent={false}
                    networkActivityIndicatorVisible={true} />
                {/* ........................Background...................... */}
                <KeyboardAwareScrollView
                    showsVerticalScrollIndicator={false}>
                    <View style={{ justifyContent: 'center', backgroundColor: Colors.themeblack_color, height: mobileH * 10 / 100 }}>
                        {/* ======Header======== */}
                        <TouchableOpacity
                            style={{ width: mobileW * 9 / 100, height: mobileW * 9 / 100, marginLeft: mobileW * 3.5 / 100, alignItems: 'center', justifyContent: 'center', borderRadius: mobileW * 4.5 / 100 }}
                            onPress={() => this.props.navigation.goBack()}
                        >
                            <Image resizeMode='contain' style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100, }}
                                source={localimag.left}></Image>
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        paddingHorizontal: mobileW * 4 / 100,
                        paddingVertical: mobileW * 2 / 100,
                        flexDirection: 'row',
                        justifyContent: 'center', marginTop: mobileH * 2 / 100

                    }}>
                        <Text
                            style={{
                                color: Colors.whiteColor,
                                fontSize: mobileW * 6.3 / 100,
                                fontFamily: Font.FontBold
                            }}>
                            {Lang_chg.please_enter_the_otp_txt[config.language]}
                        </Text>

                    </View>

                    {/* =======Text View======// */}

                    <View
                        style={{
                            flexDirection: 'row',
                            paddingHorizontal: mobileW * 4 / 100,
                            paddingVertical: mobileW * 0 / 100,
                            alignSelf: 'center',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                        <Text
                            style={{
                                color: Colors.placeholder_color,
                                fontSize: mobileW * 3.7 / 100,
                                fontFamily: Font.FontSemiBold,
                                textAlign: 'center'
                            }}>
                            {Lang_chg.same_to_validate_continue_txt[config.language]}
                        </Text>
                    </View>
                    {/* ==========Image view========= */}
                    <View
                        style={{
                            flexDirection: 'row',
                            paddingHorizontal: mobileW * 4 / 100,
                            marginTop: mobileH * 5 / 100,
                            alignSelf: 'center',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}>
                        <Image style={{ width: mobileW * 17 / 100, height: mobileW * 17 / 100 }} source={localimag.message}></Image>
                    </View>
                    {/* .....................Text input............... */}

                    <OTPTextView
                        handleTextChange={(text) => {
                            this.setState({ otp: text }),
                                console.log(text)
                        }}
                        containerStyle={{
                            marginVertical: mobileW * 10 / 100,

                            width: mobileW * 60 / 100,
                            alignSelf: 'center', justifyContent: 'center'
                        }}
                        textInputStyle={{
                            marginLeft: mobileH * 1.2 / 100,
                            borderWidth: mobileW * 0.4 / 100,
                            width: mobileW * 11.7 / 100,
                            color: Colors.placeholder_color
                        }}
                        inputCount={6}
                        inputCellLength={1}
                        tintColor={Colors.res_time_color}
                        offTintColor={Colors.text_color2}
                    />
                    {this.state.showbtn == false ?
                        <CountDown
                            // until={5 * 2}
                            size={mobileW * 3.3 / 100}
                            onFinish={() => { this.setState({ showbtn: true }) }}
                            digitStyle={{ backgroundColor: Colors.whiteColor }}
                            digitTxtStyle={{ color: Colors.redColor }}
                            timeLabelStyle={{ color: Colors.time_lable_color, fontSize: 1, }}
                            timeToShow={['M', 'S']}
                            timeLabels={{ m: '', s: '' }}
                            showSeparator={true}
                            separatorStyle={{ color: Colors.redColor }}
                            style={{
                                paddingTop: 5.5,
                                paddingBottom: 5.5
                            }}
                        />
                        :
                       
                             <View style={{ 
                             alignItems:'center',
                             width:mobileW*54/100,
                             alignSelf:'center',
                             flexDirection:'row',}}>
                             <Text style={{
                                    color: Colors.res_time_color,
                                    fontSize: mobileW * 4 / 100, fontFamily: Font.FontRegular,
                                    alignItems: 'center'
                                }}>{Lang_chg.didnt_recieve_it_txt[config.language]}</Text>
                           
                           <TouchableOpacity
                            onPress={() => this.Resendotpbtn()}
                            activeOpacity={0.7}
                            style={{ alignItems: 'center', marginLeft: mobileW * 1.5 / 100 }}
                        >
                                <Text style={{
                                    color: Colors.yellow_color,
                                    fontSize: mobileW * 4 / 100,
                                    fontFamily: Font.FontBold,
                                    alignItems: 'center',
                                   
                                }}>{Lang_chg.resend_otp_txt[config.language]}</Text>
                                   <View style={{
                                width: mobileW * 22 / 100,
                                borderBottomColor: Colors.BorderColor,
                                borderBottomWidth: mobileW * 0.2 / 100,
                            }}>
                            </View>
                                </TouchableOpacity>
                           
        
                            </View>
                        }

                    {/* //==========Continue Submit =========// */}
                    <View style={{ marginTop: mobileH * 23 / 100 }}>
                        <Appbutton
                            handlepress={() => {
                                this.Otpveryfication()
                            }}
                            title={Lang_chg.Confirm[config.language]}
                        />
                    </View>

                </KeyboardAwareScrollView>
            </SafeAreaView>
        )
    }
}
