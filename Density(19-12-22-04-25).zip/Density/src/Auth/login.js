import React, { Component } from 'react';
import { Text, BackHandler, SafeAreaView, StatusBar, Alert, View, StyleSheet, Keyboard, TouchableOpacity, Image, TextInput } from 'react-native'
import { config, msgProvider, localStorage, apifuntion, msgText, msgTitle, consolepro, Lang_chg, Font, Colors, mobileH, mobileW, localimag, firebaseprovider } from '../Provider/utilslib/Utils';
import Fontisto from 'react-native-vector-icons/Fontisto'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appbutton, TextInputCmp } from '../AllComponents';

class Login extends Component {

    _didFocusSubscription;
    _willBlurSubscription;
    constructor(props) {
        super(props)
        this.state = {
            //predefined don't change
            securetext: true,
            remember_me: false,
            email: '',
            password: '',
            //your variable start here
        }
        this._didFocusSubscription = props.navigation.addListener('focus', payload =>
            BackHandler.addEventListener('hardwareBackPress', this.handleBackPress)
        );
    }
    componentDidMount() {
        this.checkRememberMe();
        this._willBlurSubscription = this.props.navigation.addListener('blur', payload =>
            BackHandler.removeEventListener('hardwareBackPress', this.handleBackPress)
        );
    }
    //-------do not change ------------//
    //--------------remember me check function---------------------
    checkRememberMe = async () => {
        var remember_me = await localStorage.getItemString('remember_me');
        consolepro.consolelog('rememberme', remember_me);
        if (remember_me == 'yes') {
            let email = await localStorage.getItemString('email');
            let password = await localStorage.getItemString('password');
            consolepro.consolelog('email', email);
            consolepro.consolelog('password', password);
            this.setState({
                email: email,
                password: password,
                remember_me: true,
            });
        }
        else {
            this.setState({
                email: '',
                password: '',
                remember_me: false,
            });
        }
    }
    //    for backhandler
    handleBackPress = () => {
        Alert.alert(
            Lang_chg.go_back_txt[config.language],
            Lang_chg.do_you_want_exit_txt[config.language], [{
                text: Lang_chg.no_txt[config.language],
                onPress: () => consolepro.consolelog('Cancel Pressed'),
            }, {
                text: Lang_chg.yes_txt[config.language],
                onPress: () => BackHandler.exitApp()
            }], {
            cancelable: false
        }
        ); // works best when the goBack is async
        return true;
    };
    // for password hide show
    eyepress = () => {

        if (this.state.securetext) {
            this.setState({ securetext: false })
        } else {
            this.setState({ securetext: true })
        }
    }
    // for remember me 
    remember_me = () => {

        if (this.state.remember_me) {
            this.setState({ remember_me: false })
        } else {
            this.setState({ remember_me: true })
        }
    }
    //-------function for login start---
    loginBtn = () => {
        Keyboard.dismiss()
        if (config.app_status == 0) {
            //----for prototype----------//
            consolepro.consolelog('iam prototype')
            this.props.navigation.navigate('Home')
            return false
        } else {
            //----for dynamic----------//
            consolepro.consolelog('iam dynamic')
            let { email, password, remember_me } = this.state;
            consolepro.consolelog({ email, password, remember_me })


            //======================================email============================
            if (email.length <= 0) {
                msgProvider.toast(msgText.emptyEmail[config.language], 'center')
                return false
            }
            var reg = config.emailvalidation;
            if (reg.test(email) !== true) {
                msgProvider.toast(msgText.validEmail[config.language], 'center')
                return false
            }
            //=====================================password===================
            if (password.length <= 0) {
                msgProvider.toast(msgText.emptyPassword[config.language], 'center')
                return false
            }
            if (password.length <= 5) {
                msgProvider.toast(msgText.passwordMinLength[config.language], 'center')
                return false
            }
            let url = config.baseURL + "login.php";
            var data = new FormData();
            data.append('email', email)
            data.append('password', password)
            data.append("login_type", config.login_type)
            data.append("device_type", config.device_type)
            data.append("player_id", player_id_me1)

            consolepro.consolelog('data', data)
            consolepro.consolelog('url', url)
            apifuntion.postApi(url, data).then((obj) => {
                consolepro.consolelog('user_arr', obj)

                if (obj.success == 'true') {
                    var user_arr = obj.user_details;
                    var user_id = user_arr.user_id;
                    var email_arr = obj.email_arr;
                    var otp_verfiy = user_arr.otp_verify;
                    if (remember_me) {
                        localStorage.setItemString('remember_me', 'yes');
                    } else {
                        localStorage.setItemString('remember_me', 'no');
                    }
                    localStorage.setItemString('user_id', JSON.stringify(user_id));
                    localStorage.setItemObject('user_arr', user_arr);
                    localStorage.setItemString('password', this.state.password);
                    localStorage.setItemString('email', this.state.email);
                    firebaseprovider.firebaseUserCreate();
                    // firebaseprovider.getMyInboxAllData();
                    firebaseprovider.getMyInboxAllDataBooking();
                    if (otp_verfiy == 1) {
                        this.props.navigation.navigate('Home');

                    }
                    else {
                        //-------otp page redirection here....
                        this.props.navigation.navigate('OtpVerification');
                    }
                }
                else {
                    if (obj.active_status == 0) {
                        config.checkUserDeactivate(this.props.navigation);
                        return false;
                    }
                    setTimeout(() => {
                        msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                        return false;
                    }, 300);

                }
            }).catch((error) => {
                consolepro.consolelog("-------- error ------- " + error);

            });
        }
    }

    eyepress2 = () => {
        if (this.state.securetext) {
            this.setState({ securetext: false })
        } else {
            this.setState({ securetext: true })
        }
    }

    //-------function for login end---
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        translucent={false}
                        barStyle="light-content"
                        backgroundColor={Colors.statusbarcolor}
                        networkActivityIndicatorVisible={true}
                    />
                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>
                        {/* //==========Image & density Text=========// */}
                        <View style={{
                            width: mobileW,
                            alignItems: 'center',
                            alignSelf: 'center'
                        }}>
                            <View style={{
                                width: mobileW * 90 / 100, alignSelf: 'center',
                                flexDirection: 'row',
                                marginTop: mobileH * 3 / 100,
                                alignItems: 'center'
                            }}>
                                <Image style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100 }} resizeMode='contain'
                                    source={localimag.density_256}></Image>
                                <View style={{ paddingHorizontal: mobileW * 1 / 100, }}>
                                    <Text style={{
                                        color: Colors.whiteColor, fontSize: mobileW * 5.5 / 100,
                                        fontFamily: Font.FontSemiBold
                                    }}>{Lang_chg.density_txt[config.language]}</Text>
                                </View>
                            </View>
                            {/* //==========Welcome Back Text=========// */}
                            <View style={{
                                width: mobileW * 90 / 100, alignSelf: 'center',
                                flexDirection: 'row',
                                marginTop: mobileH * 7 / 100
                            }}>
                                <Text style={{
                                    color: Colors.whiteColor,
                                    fontSize: mobileW * 6.3 / 100,
                                    fontFamily: Font.FontBold
                                }}>{Lang_chg.welcomeback_txt[config.language]}</Text>
                            </View>
                            {/* //==========Email Text=========// */}
                            <View style={{
                                width: mobileW * 90 / 100, alignItems: 'center',
                                alignSelf: 'center',
                                marginTop: mobileH * 3 / 100
                            }}>

                                <TextInputCmp
                                    htitle={Lang_chg.email_txt[config.language]}
                                    placeholder={Lang_chg.EmailPlaceholder[config.language]}
                                    Keyboard={'email-address'}
                                    maxLength={100}
                                    onChangeText={(txt) => { this.setState({ email: txt }) }}
                                />
                                <TextInputCmp
                                    htitle={Lang_chg.password_txt[config.language]}
                                    placeholder={Lang_chg.PasswordPlaceholder[config.language]}
                                    Keyboard={'default'}
                                    onpresshandler={() => {
                                        this.eyepress2()
                                    }}
                                    securetext={this.state.securetext}
                                    Close={localimag.Hide}
                                    Open={localimag.show}
                                    maxLength={16}
                                    onChangeText={(txt) => { this.setState({ password: txt }) }}
                                />


                                {/* //==========Remember & ForgotPassword Text=========// */}
                                <View style={[styles.justifyContentStyle, {
                                    width: mobileW * 90 / 100,
                                    marginTop: mobileH * 2 / 100,
                                    alignItems: 'center',

                                }]}
                                >
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => this.remember_me()}
                                        style={[styles.justifyContentStyle, { width: mobileW * 32.8 / 100 }]}>
                                        {this.state.remember_me == true ?
                                            <Image style={{ width: mobileW * 3.5 / 100, height: mobileW * 3.5 / 100 }} source={localimag.checkbox_Checked}>
                                            </Image>
                                            :
                                            <Image style={{ width: mobileW * 3.5 / 100, height: mobileW * 3.5 / 100 }} source={localimag.checkbox}>
                                            </Image>
                                        }
                                        <Text style={[styles.RemeberForgottxt, { marginTop: config.device_type == 'ios' ? mobileH * 0.4 / 100 : mobileH * -0.2 / 100 }]}>{Lang_chg.remember_me_txt[config.language]}</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity
                                        activeOpacity={0.8}
                                        onPress={() => this.props.navigation.navigate('Forgotpassword')}
                                    >
                                        <Text style={[styles.RemeberForgottxt, { marginLeft: mobileW * 2 / 100, marginTop: config.device_type == 'ios' ? mobileH * 0.2 / 100 : mobileH * 0 / 100 }]}>{Lang_chg.forgot_password_txt[config.language]}</Text>
                                    </TouchableOpacity>
                                </View>
                                {/* //==========Continue Submit =========// */}
                                <View style={{ marginTop: mobileH * 20 / 100 }}>
                                    <Appbutton
                                        handlepress={() => {
                                            this.loginBtn()
                                        }}
                                        title={Lang_chg.continue_txt[config.language]}
                                    />
                                </View>
                            </View>
                        </View>
                        {/* //=========OR======// */}
                        <View style={{
                            alignSelf: 'center',
                            width: mobileW * 90 / 100,
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginTop: mobileH * 1 / 100,
                            alignItems: 'center'
                        }}>
                            <View style={{
                                height: mobileW * 0.4 / 100,
                                backgroundColor: Colors.placeholder_color,
                                width: mobileW * 34 / 100,
                            }}></View>
                            <View style={{}}>
                                <Text style={{
                                    fontFamily: Font.FontSemiBold,
                                    fontSize: mobileW * 4.7 / 100,
                                    color: Colors.text_color
                                }}>{Lang_chg.or_txt[config.language]}</Text>
                            </View>
                            <View style={{
                                height: mobileW * 0.4 / 100, backgroundColor: Colors.placeholder_color,
                                width: mobileW * 34 / 100
                            }}></View>
                        </View>
                        {/* //===========Google======// */}
                        <TouchableOpacity
                            activeOpacity={0.7} style={{
                                height: mobileH * 6.5 / 100,
                                width: mobileW * 90 / 100,
                                alignSelf: 'center',
                                borderColor: Colors.placeholder_color,
                                borderWidth: mobileW * 0.3 / 100,
                                justifyContent: 'center',
                                alignItems: 'center',
                                marginTop: mobileH * 1 / 100
                            }}>
                            <View style={{
                                flexDirection: 'row',
                                width: mobileW * 49 / 100,
                                alignSelf: 'center',
                                alignItems: 'center',
                                justifyContent: 'space-between'
                            }}>
                                <Image style={styles.icon1s} source={localimag.google}></Image>
                                <Text style={{
                                    color: Colors.whiteColor,
                                    fontSize: mobileW * 4 / 100,
                                    fontFamily: Font.FontBold,
                                    textAlign: 'center'
                                }}>
                                    {Lang_chg.continuenwithgoogle_txt[config.language]}
                                </Text>
                            </View>
                        </TouchableOpacity>

                        {/* //==========Signup Text =========// */}
                        <View style={{
                            alignItems: 'center',
                            alignSelf: 'center',
                            flexDirection: 'row',
                            marginTop: mobileH * 2 / 100,
                            marginBottom: mobileH * 4 / 100, justifyContent: 'center'
                        }} >
                            <Text style={{
                                color: Colors.res_time_color, fontFamily: Font.FontSemiBold,
                                fontSize: mobileW * 4 / 100
                            }}>{Lang_chg.not_registered_yet_txt[config.language]}</Text>

                            <TouchableOpacity
                                onPress={() => this.props.navigation.navigate('Signup')}
                                activeOpacity={0.7} style={{
                                    marginLeft: mobileW * 1.4 / 100
                                }}>
                                <Text style={{
                                    color: Colors.yellow_color,
                                    fontFamily: Font.FontBold,
                                    fontSize: mobileW * 4 / 100
                                }}>{Lang_chg.signup_here_txt[config.language]}</Text>
                                <View style={{
                                    width: mobileW * 22.5 / 100,
                                    justifyContent: 'center',
                                    alignSelf: 'center',
                                    borderColor: Colors.BorderColor,
                                    borderWidth: mobileW * 0.2 / 100
                                }}>
                                </View>
                            </TouchableOpacity>
                        </View>
                    </KeyboardAwareScrollView>
                </SafeAreaView>
            </View>
        )
    }
} export default Login

const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.themeblack_color
    },

    icon1s: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        resizeMode: 'contain', alignSelf: 'center'
    },
    justifyContentStyle: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignSelf: 'center',
        alignItems: 'center'
    },
    RemeberForgottxt: {
        color: Colors.yellow_color,
        fontFamily: Font.FontSemiBold,
        fontSize: mobileW * 4 / 100
    }

})

