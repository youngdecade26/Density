import React, { Component } from 'react';
import { Text, BackHandler, SafeAreaView, StatusBar, KeyboardAvoidingView, Alert, View, StyleSheet, Keyboard, Dimensions, ImageBackground, TouchableOpacity, Image, Modal, FlatList, ScrollView, RadioButton, Button, TextInput, keyboardType } from 'react-native'
import { config, msgProvider, localStorage, apifuntion, msgText, msgTitle, consolepro, Lang_chg, Font, Colors, mobileH, mobileW, localimag, notification } from '../Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appbutton, TextInputCmp } from '../AllComponents';

class Forgotpassword extends Component {
    constructor(props) {
        super(props)
        this.state = {
            email: '',
            type: 1 //1=email,2=mobile
        }
    }
    componentDidMount() {
        consolepro.consolelog('I am on forgot password page')
    }

    forgot_btn = () => {
        Keyboard.dismiss()
        if (config.app_status == 0) {
            this.props.navigation.navigate('ForgotOTPVerify', {
                forgot_type: this.state.type,
                email_mobile: 'jack@mailinator.com',
                user_id: 0,
                forgot_id: 0,
                otp: 4512,
                otp_auto_fill: true
            })
        } else {
            let { email, type } = this.state;
            if (type == 1) {
                //=======================================email============================
                if (email.length <= 0) {
                    msgProvider.toast(msgText.emptyEmail[config.language], 'center')
                    return false
                }
                var reg = config.emailvalidation;
                if (reg.test(email) !== true) {
                    msgProvider.toast(msgText.validEmail[config.language], 'center')
                    return false
                }
            } else {
                if (email.length <= 0) {
                    msgProvider.toast(msgText.emptyMobile[config.language], 'center')
                    return false
                }
                if (email.length < 7) {
                    msgProvider.toast(msgText.mobileMinLength[config.language], 'center')
                    return false
                }
                var mobilevalidation = config.mobilevalidation;
                if (mobilevalidation.test(email) !== true) {
                    msgProvider.toast(msgText.validMobile[config.language], 'center')
                    return false
                }
            }

            let url = config.baseURL + "forgot_password.php";
            var data = new FormData();
            data.append('email_mobile', email)
            data.append('forgot_type', type) //----1=email,2=mobile
            consolepro.consolelog('data', data)
            apifuntion.postApi(url, data).then((obj) => {
                consolepro.consolelog('res', obj)
                if (obj.success == 'true') {
                    var user_id = obj.user_id;
                    var forgot_id = obj.forgot_id;
                    var otp = obj.otp;
                    var otp_auto_fill = obj.otp_auto_fill;
                    if (otp_auto_fill == false) {
                        otp = ''
                    }
                    consolepro.consolelog({ user_id })
                    this.props.navigation.navigate('ForgotOTPVerify', {
                        forgot_type: type,
                        email_mobile: email,
                        user_id: user_id,
                        forgot_id: forgot_id,
                        otp: otp,
                        otp_auto_fill: otp_auto_fill
                    })
                }
                else {
                    if (obj.active_status == 0) {
                        config.checkUserDeactivate(this.props.navigation);
                        return false;
                    }
                    setTimeout(() => {
                        msgProvider.alert(msgTitle.information[config.language], obj.msg[config.language], false);
                        return false;
                    }, 300);
                }
            }).catch((error) => {
                consolepro.consolelog("-------- error ------- " + error);
            });
        }
    }

    render() {
        return (
            <SafeAreaView style={styles.container}>
                <StatusBar
                    hidden={false}
                    translucent={false}
                    barStyle="light-content"
                    backgroundColor={Colors.statusbarcolor}
                    networkActivityIndicatorVisible={true}
                />
                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                    showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

                    <View style={{
                        justifyContent: 'center', backgroundColor: Colors.themeblack_color,
                        height: mobileH * 10 / 100
                    }}>
                        {/* ======Header======== */}
                        <TouchableOpacity
                            style={{
                                width: mobileW * 9 / 100,
                                height: mobileW * 9 / 100,
                                marginLeft: mobileW * 3.5 / 100,
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRadius: mobileW * 4.5 / 100
                            }}
                            onPress={() => this.props.navigation.goBack()}
                        >
                            <Image resizeMode='contain' style={{ width: mobileW * 5.5 / 100, height: mobileW * 5.5 / 100, }}
                                source={localimag.left}>
                            </Image>
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        width: mobileW * 90 / 100,
                        alignSelf: 'center',
                        marginTop: mobileH * 6 / 100
                    }}>
                        <Text style={{
                            fontSize: mobileW * 6.3 / 100,
                            fontFamily: Font.FontBold,
                            color: Colors.whiteColor
                        }}>{Lang_chg.forgot_password_txt[config.language]}
                        </Text>
                    </View>

                    {/* //==========Email Text=========// */}
                    <View style={{ width: mobileW * 90 / 100, alignItems: 'center', alignSelf: 'center', marginTop: mobileH * 3 / 100 }}>
                        <TextInputCmp
                            htitle={Lang_chg.forgot_password_txt[config.language]}
                            placeholder={Lang_chg.PasswordPlaceholder[config.language]}
                            Keyboard={'default'}
                            maxLength={16}
                            onChangeText={(txt) => { this.setState({ newpassword: txt }) }}
                        />
                    </View>

                    {/* //==========Continue Submit =========// */}
                    <View style={{ marginTop: mobileH * 20 / 100 }}>
                        <Appbutton
                            handlepress={() => {
                                this.props.navigation.navigate('Login')
                            }}
                            title={Lang_chg.submit_txt[config.language]}
                        />
                    </View>
                </KeyboardAwareScrollView>
            </SafeAreaView>
        )
    }
} export default Forgotpassword

const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.themeblack_color
    },
})

