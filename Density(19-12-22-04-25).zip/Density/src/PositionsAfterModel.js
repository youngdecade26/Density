import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appsmallbutton } from './AllComponents';

export default class Positions extends Component {
  constructor(props) {
    super(props)
    this.state = {
      BuyOrderModel: false,
      BTCUSDTArr: [
        {
          'id': '0',
          'Type': 'Long',
          'PnL': '39.058',
          'LTP': '$1962.50'
        },
        {
          'id': '1',
          'Type': 'Short',
          'PnL': '39.058',
          'LTP': '$1962.50'
        },
        {
          'id': '2',
          'Type': 'Short',
          'PnL': '39.058',
          'LTP': '$1962.50'
        }
      ]

    }
  }
  componentDidMount() {

  }


  render() {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar
          hidden={false}
          translucent={false}
          barStyle="light-content"
          networkActivityIndicatorVisible={true}
          backgroundColor={Colors.statusbarcolor}
        />
        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>

          {/* //==========Get Started Now Text=========// */}
          <View
            style={{
              flexDirection: 'row',
              marginTop: mobileH * 2 / 100,
              marginBottom: mobileH * 4 / 100,
              paddingHorizontal: mobileW * 5 / 100,
            }} >
            <View
              style={{
                width: mobileW * 89 / 100,
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignSelf: 'center',
                alignItems: 'center',
              }}>
              <View>
                <Text style={{
                  color: Colors.whiteColor,
                  fontFamily: Font.FontSemiBold,
                  fontSize: mobileW * 6.3 / 100
                }}>
                  {Lang_chg.Positions[config.language]}
                </Text>
                <View style={{
                  width: mobileW * 22 / 100,
                  backgroundColor: Colors.yellow_color,
                  borderColor: Colors.yellow_color,
                  borderWidth: mobileW * 0.9 / 100
                }}>
                </View>
              </View>
              <View>
                <Image style={{
                  height: mobileH * 3.3 / 100,
                  width: mobileW * 6.6 / 100,
                  marginTop: mobileH * 1 / 100
                }}
                  source={localimag.YellowSearchIcon}></Image>
              </View>
            </View>
          </View>

          <View style={{
            width: mobileW * 90 / 100, alignSelf: 'center',
          }}>

            {/* -------------FirstBox-------------- */}
            <View
              style={{
                width: '99.5%',
                alignSelf: 'center',
                borderWidth: mobileW * 0.5 / 100,
                borderColor: Colors.BorderColor,
                backgroundColor: Colors.CartBackColor,
              }}>
              <View style={{
                paddingVertical: mobileH * 1 / 100,
                alignSelf: 'center'
              }}>
                <Text style={{
                  color: Colors.PnlTextColor,
                  fontSize: mobileW * 4.5 / 100,
                  fontFamily: Font.FontMedium,
                }}>{Lang_chg.TotalPnL[config.language]}</Text>
                <Text style={{
                  color: Colors.GreenText,
                  fontSize: mobileW * 4.5 / 100,
                  fontFamily: Font.FontMedium,
                  textAlign: 'center'
                }}>{Lang_chg.TotalPnLNumber[config.language]}</Text>
              </View>
            </View>

            {/* -------------------------------------- */}
            <FlatList
              data={this.state.BTCUSDTArr
              }
              contentContainerStyle={{ paddingBottom: mobileW * 25 / 100 }}
              renderItem={({ item, index }) => {
                console.log('item', item)
                return (
                  <TouchableOpacity
                    onPress={() => this.props.navigation.navigate('Positions')}
                    activeOpacity={0.8}
                    style={{
                      marginTop: mobileH * 2 / 100,
                      width: '99.5%',
                      alignSelf: 'center',
                      borderWidth: mobileW * 0.5 / 100,
                      borderColor: Colors.BorderColor,
                      backgroundColor: Colors.CartBackColor,
                    }}>

                    <View style={{
                      width: mobileW * 84 / 100,
                      paddingVertical: mobileH * 1 / 100,
                      alignSelf: 'center',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>

                      <View style={{ width: mobileW * 40 / 100 }}>
                        <View style={{ backgroundColor: item.Type == 'Long' ? Colors.OrangeColor : Colors.GreenButton, width: mobileW * 12 / 100 }}>
                          <Text style={{
                            color: Colors.PnlTextColor,
                            fontSize: mobileW * 3 / 100,
                            fontFamily: Font.FontMedium,
                            paddingVertical: mobileH * 0.2 / 100,
                            textAlign: 'center'
                          }}>{item.Type}</Text>
                        </View>
                        <Text style={{
                          color: Colors.whiteColor,
                          fontSize: mobileW * 4.4 / 100,
                          fontFamily: Font.FontSemiBold,
                        }}>{Lang_chg.BTCUSDT1X[config.language]}</Text>
                      </View>

                      <View style={{
                        justifyContent: 'flex-end',
                        alignSelf: 'center',
                        width: mobileW * 35 / 100,
                        alignItems: 'flex-end',
                      }}>
                        <View>
                          <View style={{ flexDirection: 'row' }}>
                            <Text style={{
                              color: Colors.PnlTextColor,
                              fontSize: mobileW * 3.3 / 100,
                              fontFamily: Font.FontMedium
                            }}>{Lang_chg.PnL[config.language]}  <Text style={{
                              color: item.Type == 'Long' ? Colors.OrangeColor : Colors.GreenText,
                              fontSize: mobileW * 3.7 / 100,
                              fontFamily: Font.FontMedium
                            }}>{item.PnL}</Text></Text>
                          </View>
                          <View style={{ flexDirection: 'row' }}>
                            <Text style={{
                              color: Colors.PnlTextColor,
                              fontSize: mobileW * 3.3 / 100,
                              fontFamily: Font.FontMedium
                            }}>{Lang_chg.LTP[config.language]}  <Text style={{
                              color: Colors.whiteColor,
                              fontSize: mobileW * 3 / 100,
                              fontFamily: Font.FontMedium
                            }}>{item.LTP}</Text></Text>
                          </View>
                        </View>
                      </View>

                      <View style={{ height: mobileH * 2 / 100, paddingTop: mobileH * 2.8 / 100 }}>
                        <Image style={{
                          height: mobileH * 2 / 100,
                          width: mobileW * 4 / 100
                        }}
                          source={localimag.DownYerrowIcon}></Image>
                      </View>
                    </View>
                  </TouchableOpacity>
                )
              }}
            />
          </View>

        </KeyboardAwareScrollView>
      </SafeAreaView >
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.themeblack_color
  },
  view1:
  {
    height: mobileH * 8 / 100,
    flexDirection: 'row',
    width: mobileW * 88 / 100,
    alignSelf: 'center',
    alignItems: 'center',
  },
  icon1s: {
    width: mobileW * 5 / 100,
    height: mobileW * 5 / 100,
    resizeMode: 'contain', alignSelf: 'center'
  },

})
