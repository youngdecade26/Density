import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, Modal, ImageBackground, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { color } from 'react-native-reanimated';
import DateTimePicker from '@react-native-community/datetimepicker';
import DateTimePickerModal from "react-native-modal-datetime-picker";

export default class SelectDateRange extends Component {

    constructor(props) {
        super(props)
        this.state = {
            row_date: new Date(),
            my_date: '',
            my_dob: '',
            my_dob1: '',
            isDateTimePickerVisible: false
        }
    }

    showDateTimePicker = () => {
        this.setState({ isDateTimePickerVisible: true });
    };
    handleDatePicked = (res) => {
        consolepro.consolelog("res", res)
        this.setState({ row_date: res })
        let date = res.getDate()
        let month = res.getMonth() + 1
        let year = res.getFullYear()
        consolepro.consolelog("monthhhhh", res.getMonth())
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
            "July", "Aug", "Sept", "Oct", "Nov", "Dec"
        ];
        let my_date = date + '-' + monthNames[res.getMonth()] + '-' + year;
        this.setState({ my_dob: my_date, dateshow: false })
        consolepro.consolelog("date response", this.state.my_dob)
        this.setState({ isDateTimePickerVisible: false })
    }
    hideDateTimePicker = () => {
        this.setState({ isDateTimePickerVisible: false })
    }

    go_back() {
        this.setState({ dateModal: false })
        this.props.navigation.goBack()
    }
    render() {

        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        translucent={false}
                        barStyle="light-content"
                        networkActivityIndicatorVisible={true}
                    />
                    <View>

                        <DateTimePickerModal
                            isVisible={this.state.isDateTimePickerVisible}
                            mode="date"
                            date={new Date(this.state.row_date)}
                            onConfirm={this.handleDatePicked}
                            onCancel={this.hideDateTimePicker}
                        />
                    </View>

                    {/* heading  and back icon */}

                    <View style={{
                        width: mobileW * 95 / 100, alignItems: 'center',
                        marginTop: mobileH * 2 / 100,
                        alignSelf: 'center', flexDirection: 'row',
                    }}>

                        {/* back icon image */}

                        <TouchableOpacity
                            onPress={() => this.go_back()}
                            style={{
                                alignSelf: 'center',
                                paddingVertical: mobileH * 1 / 100,
                                paddingHorizontal: mobileW * 2.5 / 100,
                                alignItems: 'center',
                            }}>
                            <Image style={{
                                width: mobileW * 4.5 / 100,
                                height: mobileW * 4.5 / 100
                            }}
                                resizeMode='contain' source={localimag.left}></Image>
                        </TouchableOpacity>


                        {/* select date range heading Text */}
                        <View style={{
                            width: mobileW * 80 / 100, alignSelf: 'center',
                            paddingVertical: mobileH * 1 / 100,
                            flexDirection: 'row', alignItems: 'center'
                        }}>
                            <Text style={{
                                color: Colors.placeholder_color,
                                fontSize: mobileW * 4.5 / 100, fontFamily: Font.FontSemiBold
                            }}>{Lang_chg.select_date_range[config.language]}</Text>
                        </View>
                    </View>

                    <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={{ width: mobileW, }}
                        keyboardShouldPersistTaps='handled'>

                        {/* select date text and reset text */}
                        <View style={{
                            width: mobileW * 90 / 100, alignItems: 'center',
                            alignSelf: 'center', flexDirection: 'row',
                            justifyContent: 'space-between',
                        }}>
                            {/* select date Text */}
                            <View style={{
                                alignSelf: 'center',
                                flexDirection: 'row', marginTop: mobileH * 2 / 100,
                                alignItems: 'center'
                            }}>
                                <Text style={{
                                    color: Colors.PnlTextColor,
                                    fontSize: mobileW * 4 / 100,
                                    fontFamily: Font.FontSemiBold
                                }}>{Lang_chg.select_date[config.language]}</Text>
                            </View>

                            {/* reset image and text */}

                            <TouchableOpacity style={{
                                alignSelf: 'center', flexDirection: 'row',
                                marginTop: mobileH * 3 / 100, alignItems: 'center'
                            }}>
                                <Image style={{
                                    width: mobileW * 4 / 100,
                                    height: mobileW * 4 / 100,
                                    tintColor: Colors.PnlTextColor
                                }} resizeMode='contain' source={localimag.refresh}></Image>

                                <Text style={{
                                    color: Colors.PnlTextColor,
                                    fontSize: mobileW * 4 / 100,
                                    fontFamily: Font.FontSemiBold,
                                    paddingLeft: mobileW * 2 / 100,
                                }}>{Lang_chg.reset_text[config.language]}</Text>
                            </TouchableOpacity>
                        </View>

                        {/* date picker boxes*/}
                        <View style={{
                            paddingVertical: mobileH * 1.5 / 100,
                            justifyContent: 'space-between',
                            alignSelf: 'center',
                            flexDirection: 'row',
                            width: mobileW * 90 / 100
                        }}>
                            <TouchableOpacity
                                activeOpacity={0.7}
                                onPress={this.showDateTimePicker}
                                style={{
                                    borderColor: Colors.PnlTextColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    width: mobileW * 35 / 100,
                                    paddingVertical: mobileH * 0.75 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}>
                                <View style={{
                                    width: mobileW * 28 / 100,
                                }}>
                                    <Text style={{
                                        fontFamily: Font.FontMedium,
                                        alignSelf: 'center',
                                        color: Colors.white_color,
                                        fontSize: mobileW * 4 / 100
                                    }}>
                                        {this.state.my_dob == '' ? '--------------' : this.state.my_dob}
                                    </Text>
                                </View>
                                <Image
                                    resizeMode='contain'
                                    style={{
                                        height: mobileW * 5.5 / 100,
                                        width: mobileW * 5.5 / 100
                                    }}
                                    source={this.state.my_dob == '' ? localimag.calender_deactive :
                                        localimag.calender_Active}>
                                </Image>
                            </TouchableOpacity>

                            <TouchableOpacity
                                activeOpacity={0.7}
                                onPress={this.showDateTimePicker}
                                style={{
                                    borderColor: Colors.PnlTextColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    width: mobileW * 35 / 100,
                                    paddingVertical: mobileH * 0.75 / 100,
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}>
                                <View style={{
                                    width: mobileW * 28 / 100,
                                }}>
                                    <Text style={{
                                        fontFamily: Font.FontMedium,
                                        alignSelf: 'center',
                                        color: Colors.white_color,
                                        fontSize: mobileW * 4 / 100
                                    }}>
                                        {this.state.my_dob1 == '' ? '--------------' : this.state.my_dob1}
                                    </Text>
                                </View>
                                <Image
                                    resizeMode='contain'
                                    style={{
                                        height: mobileW * 5.5 / 100,
                                        width: mobileW * 5.5 / 100
                                    }}
                                    source={this.state.my_dob1 == '' ? localimag.calender_deactive :
                                        localimag.calender_Active}>
                                </Image>
                            </TouchableOpacity>

                        </View>


                    </KeyboardAwareScrollView>

                </SafeAreaView >
            </View>
        )
    }
}
const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: Colors.HomeBackColor
    },
})
