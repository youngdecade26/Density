import React, { Component } from 'react'
import { Text, SafeAreaView, StatusBar, TextInput, View, StyleSheet, Image, FlatList, Modal, TouchableOpacity } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, Footer, consolepro } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Appsmallbutton1 } from './AllComponents';
import { CardStyleInterpolators } from '@react-navigation/stack';


export default class Orders extends Component {

    constructor(props) {
        super(props)
        this.state = {
            heading_arr: [
                {
                    id: 0,
                    scriptName: Lang_chg.OpenOrders[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: true
                },
                {
                    id: 1,
                    scriptName: Lang_chg.OrderHistory[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: false
                },
                {
                    id: 2,
                    scriptName: Lang_chg.TradeHistory[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: false
                },
            ],
            order_arr: [
                {
                    scriptName: Lang_chg.BTCUSDT[config.language],
                    buy_sell: Lang_chg.BUY[config.language],
                    filled: Lang_chg.Filled011[config.language],
                    datetime: Lang_chg.june6[config.language],
                    ltp: Lang_chg.ltp[config.language],
                    ltp_price: Lang_chg.num_19953[config.language],
                    size_contract: Lang_chg.Size[config.language],
                    size_contract_value: Lang_chg.num045[config.language],
                    size_usdt: Lang_chg.sizeusdt[config.language],
                    price_value: Lang_chg.num92[config.language],
                    ReduceOnly: Lang_chg.ReduceOnly[config.language],
                    ReduceOnly_value: Lang_chg.NO[config.language],
                    order_id: Lang_chg.OrderId[config.language],
                    order_id_value: Lang_chg.num38140121[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: true
                },
                {
                    scriptName: Lang_chg.BTCUSDT[config.language],
                    buy_sell: Lang_chg.BUY[config.language],
                    filled: Lang_chg.Filled011[config.language],
                    datetime: Lang_chg.june6[config.language],
                    ltp: Lang_chg.ltp[config.language],
                    ltp_price: Lang_chg.num_19953[config.language],
                    size_contract: Lang_chg.Size[config.language],
                    size_contract_value: Lang_chg.num045[config.language],
                    size_usdt: Lang_chg.sizeusdt[config.language],
                    price_value: Lang_chg.num92[config.language],
                    ReduceOnly: Lang_chg.ReduceOnly[config.language],
                    ReduceOnly_value: Lang_chg.NO[config.language],
                    order_id: Lang_chg.OrderId[config.language],
                    order_id_value: Lang_chg.num38140121[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: true
                },
                {
                    scriptName: Lang_chg.BTCUSDT[config.language],
                    buy_sell: Lang_chg.BUY[config.language],
                    filled: Lang_chg.Filled011[config.language],
                    datetime: Lang_chg.june6[config.language],
                    ltp: Lang_chg.ltp[config.language],
                    ltp_price: Lang_chg.num_19953[config.language],
                    size_contract: Lang_chg.Size[config.language],
                    size_contract_value: Lang_chg.num045[config.language],
                    size_usdt: Lang_chg.sizeusdt[config.language],
                    price_value: Lang_chg.num92[config.language],
                    ReduceOnly: Lang_chg.ReduceOnly[config.language],
                    ReduceOnly_value: Lang_chg.NO[config.language],
                    order_id: Lang_chg.OrderId[config.language],
                    order_id_value: Lang_chg.num38140121[config.language],
                    currency: Lang_chg.usdt_txt[config.language],
                    status: true
                },
            ],
            trade_history_time: [
                {
                    id: 0,
                    timePeriod: Lang_chg.day1[config.language],
                    active_image: localimag.YellowRadioActice,
                    inactive_image: localimag.Radioinactice,
                    status: true
                },
                {
                    id: 1,
                    timePeriod: Lang_chg.week1[config.language],
                    active_image: localimag.YellowRadioActice,
                    inactive_image: localimag.Radioinactice,
                    status: false
                },
                {
                    id: 2,
                    timePeriod: Lang_chg.month1[config.language],
                    active_image: localimag.YellowRadioActice,
                    inactive_image: localimag.Radioinactice,
                    status: false
                },
                {
                    id: 3,
                    timePeriod: Lang_chg.months3[config.language],
                    active_image: localimag.YellowRadioActice,
                    inactive_image: localimag.Radioinactice,
                    status: false
                },
                {
                    id: 4,
                    timePeriod: Lang_chg.custom[config.language],
                    active_image: localimag.YellowRadioActice,
                    inactive_image: localimag.Radioinactice,
                    status: false
                },
            ],
            CancelOrderModel: false,
            btnStatus: 0,
            selectedTimePeriod: 3,
        }
    }

    getview = (item, index) => {
        var categeory_arr = this.state.heading_arr
        for (var i = 0; i < categeory_arr.length; i++) {
            categeory_arr[i].status = false
        }
        categeory_arr[index].status = !categeory_arr[index].status;
        this.setState({
            heading_arr: categeory_arr,
            btnStatus: item.id
        })
        consolepro.consolelog('heading_arr', this.state.heading_arr)
    }

    getviewtradehistory = (item, index) => {
        var categeory_arr1 = this.state.trade_history_time
        for (var i = 0; i < categeory_arr1.length; i++) {
            categeory_arr1[i].status = false
        }
        categeory_arr1[index].status = !categeory_arr1[index].status;
        this.setState({
            trade_history_time: categeory_arr1,
            selectedTimePeriod: item.id
        })
        consolepro.consolelog('heading_arr', this.state.trade_history_time)

        if (item.id == 4) {
            this.props.navigation.navigate('SelectDateRange')
        }
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: Colors.themeblack_color }} >
                <SafeAreaView style={styles.container}>
                    <StatusBar
                        hidden={false}
                        translucent={false}
                        barStyle="light-content"
                        backgroundColor={Colors.statusbarcolor}
                        networkActivityIndicatorVisible={true}
                    />

                    {/* orders Text */}

                    <View style={{
                        marginTop: mobileH * 3 / 100,
                        marginBottom: mobileH * 1 / 100,
                        width: mobileW * 90 / 100,
                        alignSelf: 'center'
                    }} >
                        <View
                            style={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: mobileW * 90 / 100
                            }}>
                            <Text style={{
                                color: Colors.whiteColor,
                                fontFamily: Font.FontSemiBold,
                                fontSize: mobileW * 6.3 / 100,
                                width: mobileW * 83 / 100
                            }}>
                                {Lang_chg.Orders[config.language]}
                            </Text>

                            <Image style={{
                                marginTop: mobileH * 1 / 100,
                                width: mobileW * 7 / 100,
                                height: mobileW * 7 / 100,
                                tintColor: Colors.yellow_color
                            }} resizeMode='contain'
                                source={localimag.searchwhite}>
                            </Image>

                        </View>
                        <View style={{
                            width: mobileW * 16 / 100,
                            backgroundColor: Colors.yellow_color,
                            borderColor: Colors.yellow_color,
                            borderWidth: mobileW * 0.7 / 100
                        }}>
                        </View>
                    </View>

                    {/* lorem ispum heading */}

                    <View style={{ width: mobileW * 90 / 100, alignSelf: 'center', flexDirection: 'row', }}>
                        <View style={{}}>
                            <Text style={{
                                color: Colors.LoremColor, fontSize: mobileW * 3.5 / 100,
                                fontFamily: Font.FontSemiBold
                            }}>
                                {Lang_chg.lorem_ipsum_dolot_txt[config.language]}
                            </Text>
                        </View>
                    </View>

                    {/* ---------Tab view for FlatList horizontal--------- */}

                    <View style={{
                        width: mobileW * 90 / 100, alignSelf: 'center',
                        marginTop: mobileH * 2 / 100
                    }}>
                        {/* FlatList horizontal */}
                        <FlatList
                            showsHorizontalScrollIndicator={false}
                            horizontal={true}
                            data={this.state.heading_arr}
                            contentContainerStyle={{
                            }}
                            renderItem={({ item, index }) =>

                                <View style={{
                                    marginTop: mobileH * 1.5 / 100,
                                }}>
                                    {item.status == true ?

                                        <TouchableOpacity
                                            style={{
                                                borderBottomWidth: mobileW * 0.8 / 100,
                                                borderBottomColor: Colors.ButtonBarColor,
                                                paddingHorizontal: mobileW * 1 / 100,
                                            }}
                                            activeOpacity={0.9}
                                            onPress={() => this.getview(item, index)}
                                        >
                                            <Text style={{
                                                color: Colors.white_color,
                                                fontSize: mobileW * 4 / 100,
                                                paddingVertical: mobileW * 1.5 / 100,
                                                fontFamily: Font.FontMedium
                                            }}>
                                                {item.scriptName}
                                            </Text>

                                        </TouchableOpacity>
                                        :
                                        <TouchableOpacity
                                            style={{ paddingHorizontal: mobileW * 5 / 100 }}
                                            activeOpacity={0.9}
                                            onPress={() => this.getview(item, index)}>
                                            <Text style={{
                                                color: Colors.PnlTextColor,
                                                paddingVertical: mobileW * 1.5 / 100,
                                                fontSize: mobileW * 4 / 100, fontFamily: Font.FontMedium
                                            }}>
                                                {item.scriptName}
                                            </Text>
                                        </TouchableOpacity>
                                    }
                                </View>
                            }></FlatList>
                    </View>

                    {/* border below flatlist */}
                    <View style={{
                        borderBottomWidth: mobileW * 0.25 / 100,
                        borderColor: Colors.greyColor,
                        width: mobileW,
                    }}>
                    </View>

                    {/* -------------------OpenOrder--------------------- */}
                    {this.state.btnStatus == 0 &&
                        <KeyboardAwareScrollView
                            showsVerticalScrollIndicator={false}
                            contentContainerStyle={{ paddingBottom: mobileH * 1 / 100 }}>
                            <View style={{
                                marginTop: mobileW * 6 / 100,
                                width: mobileW * 85 / 100,
                                alignSelf: 'center'
                            }}>
                                < View style={{
                                    alignSelf: 'center',
                                    borderColor: Colors.BorderColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    paddingVertical: mobileH * 1.5 / 100,
                                    backgroundColor: Colors.CartBackColor
                                }}>
                                    <View style={{
                                        borderColor: Colors.faltlistBorderHome,
                                        borderBottomWidth: mobileW * 0.5 / 100,
                                        paddingHorizontal: mobileW * 2 / 100,
                                    }}>

                                        {/*buy text */}
                                        <View style={{
                                            paddingVertical: mobileH * 0.5 / 100,
                                        }}>
                                            <View style={{
                                                width: mobileW * 15 / 100, alignItems: 'center',
                                                backgroundColor: Colors.green_color,
                                            }}>
                                                <Text style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                    {Lang_chg.BUY[config.language]}</Text>
                                            </View>
                                        </View>

                                        {/*currency and filled */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            paddingVertical: mobileH * 0.5 / 100,
                                            flexDirection: 'row'
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.BTCUSDT[config.language]}</Text>

                                            <View style={{
                                                flexDirection: 'row',
                                                alignItems: 'center'
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color, backgroundColor: Colors.usdt_bg,
                                                        fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 1 / 100, borderRadius: mobileW * 0.5 / 100
                                                    }}>
                                                    {Lang_chg.Filled011[config.language]}</Text>
                                            </View>
                                        </View>

                                        {/*date ,time and LTP */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            flexDirection: 'row', marginBottom: mobileH * 1 / 100
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.june6[config.language]}</Text>

                                            <View style={{ flexDirection: 'row' }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 1 / 100,
                                                    }}>
                                                    {Lang_chg.ltp[config.language]}
                                                </Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.num_19953[config.language]}</Text>
                                            </View>
                                        </View>
                                    </View>

                                    <View style={{
                                        paddingHorizontal: mobileW * 2 / 100,
                                        marginTop: mobileH * 1 / 100,
                                    }}>
                                        {/*size ,price and reduce only view */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            flexDirection: 'row', marginBottom: mobileH * 2 / 100,
                                        }}>
                                            <View style={{
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.Size[config.language]}</Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.num045[config.language]}</Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        marginTop: mobileH * 2 / 100,
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.sizeusdt[config.language]}</Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.num045[config.language]}</Text>
                                            </View>

                                            <View style={{
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                    }}>
                                                    {Lang_chg.Price[config.language]} </Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                    }}>
                                                    {Lang_chg.num92[config.language]} </Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        marginTop: mobileH * 2 / 100,
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                    }}>
                                                    {Lang_chg.TriggerPrice[config.language]} </Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                    }}>
                                                    {Lang_chg.num045[config.language]} </Text>
                                            </View>

                                            <View style={{
                                                alignItems: 'flex-end'
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 1 / 100,
                                                    }}>
                                                    {Lang_chg.ReduceOnly[config.language]} </Text>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        alignSelf: 'flex-start',
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 1 / 100,
                                                        // right: mobileW * 15.25 / 100
                                                    }}>
                                                    {Lang_chg.NO[config.language]} </Text>

                                                <View style={{
                                                    alignSelf: 'flex-start',
                                                    flexDirection: 'row',
                                                    alignItems: 'center',
                                                    marginTop: mobileH * 2 / 100,
                                                }}>
                                                    <Text
                                                        numberOfLines={1}
                                                        style={{
                                                            color: Colors.PnlTextColor,
                                                            fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                            paddingHorizontal: mobileW * 1 / 100,
                                                        }}>
                                                        {Lang_chg.OrderId[config.language]} </Text>

                                                    <Image style={{
                                                        width: mobileW * 2.5 / 100,
                                                        height: mobileW * 2.5 / 100,
                                                    }} resizeMode='contain' source={localimag.copy}></Image>

                                                </View>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        alignSelf: 'flex-start',
                                                        color: Colors.placeholder_color, paddingHorizontal: mobileW * 1 / 100,
                                                        fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {Lang_chg.num38140121[config.language]} </Text>
                                            </View>
                                        </View>
                                        {/* -------------button--------------- */}
                                        <Appsmallbutton1
                                            handlepress={() => {
                                                this.setState({ CancelOrderModel: true })
                                            }}
                                            title={Lang_chg.CancelOrder[config.language]}
                                        />
                                    </View>
                                </View>
                            </View>

                            {/* -------------------------------------- */}
                            <FlatList
                                data={this.state.order_arr}
                                showsVerticalScrollIndicator={false}
                                contentContainerStyle={{
                                    paddingBottom: mobileH * 12 / 100,
                                    marginTop: mobileW * 3 / 100,
                                }}
                                renderItem={({ item, index }) =>
                                    <View style={{
                                        alignSelf: 'center',
                                        marginTop: mobileW * 3 / 100,
                                        borderColor: Colors.BorderColor,
                                        borderWidth: mobileW * 0.5 / 100,
                                        paddingVertical: mobileH * 1.5 / 100,
                                        paddingHorizontal: mobileW * 2 / 100,
                                        backgroundColor: Colors.CartBackColor
                                    }}>
                                        {/*----------buy text---------- */}
                                        <View style={{
                                            paddingVertical: mobileH * 0.5 / 100,
                                        }}>
                                            <View style={{
                                                width: mobileW * 15 / 100, alignItems: 'center',
                                                backgroundColor: Colors.green_color,
                                            }}>
                                                <Text style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                    {Lang_chg.BUY[config.language]}</Text>
                                            </View>
                                        </View>

                                        {/*----------currency and filled----------- */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            flexDirection: 'row',
                                            paddingVertical: mobileH * 0.5 / 100,
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {item.scriptName}</Text>

                                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        marginRight: mobileW * 2 / 100,
                                                        color: Colors.placeholder_color, backgroundColor: Colors.usdt_bg,
                                                        fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100, borderRadius: mobileW * 0.5 / 100
                                                    }}>
                                                    {item.filled}</Text>

                                                <Image style={{
                                                    top: mobileH * 1 / 100,
                                                    width: mobileW * 5 / 100,
                                                    height: mobileW * 5 / 100,
                                                }} resizeMode='contain' source={localimag.dropdown_bg}></Image>
                                            </View>
                                        </View>

                                        {/*-----------date ,time and LTP----------- */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            flexDirection: 'row',
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {item.datetime}</Text>
                                            <View style={{
                                                flexDirection: 'row',
                                                marginRight: mobileW * 5.75 / 100,
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.PnlTextColor,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                    }}>
                                                    {item.ltp}  <Text
                                                        numberOfLines={1}
                                                        style={{
                                                            color: Colors.placeholder_color,
                                                            fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                            paddingHorizontal: mobileW * 1 / 100,
                                                        }}>
                                                        {item.ltp_price}</Text>
                                                </Text>
                                            </View>
                                        </View>
                                    </View>
                                }></FlatList>
                        </KeyboardAwareScrollView>
                    }

                    {/* -------------------OrderHistory--------------------- */}
                    {this.state.btnStatus == 1 &&
                        <KeyboardAwareScrollView
                            showsVerticalScrollIndicator={false}
                            contentContainerStyle={{
                                paddingBottom: mobileH * 1 / 100,
                                marginTop: mobileW * 4 / 100,
                            }}>

                            <View style={{
                                alignSelf: 'center',
                                marginTop: mobileW * 3 / 100,
                                marginLeft: mobileW * 1 / 100,
                                borderColor: Colors.BorderColor,
                                backgroundColor: Colors.CartBackColor,
                                borderWidth: mobileW * 0.5 / 100,
                                paddingVertical: mobileH * 1.5 / 100,
                                paddingHorizontal: mobileW * 2 / 100,
                            }}>
                                {/*buy text */}

                                <View style={{
                                    paddingVertical: mobileH * 0.5 / 100,
                                    flexDirection: 'row', justifyContent: 'space-between'
                                }}>
                                    <View style={{
                                        width: mobileW * 15 / 100, alignItems: 'center',
                                        backgroundColor: Colors.green_color,
                                    }}>
                                        <Text style={{
                                            color: Colors.placeholder_color,
                                            fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,

                                        }}>
                                            {Lang_chg.BUY[config.language]}</Text>
                                    </View>

                                    <Text
                                        numberOfLines={1}
                                        style={{
                                            color: Colors.placeholder_color, backgroundColor: Colors.usdt_bg,
                                            fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            paddingHorizontal: mobileW * 2 / 100, borderRadius: mobileW * 0.5 / 100
                                        }}>
                                        Filled</Text>
                                </View>

                                {/*currency and filled */}
                                <View style={{
                                    width: mobileW * 85 / 100, justifyContent: 'space-between',
                                    flexDirection: 'row'
                                }}>
                                    <View style={{ flexDirection: 'row' }}>
                                        <Text
                                            numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            {Lang_chg.BTCUSDT[config.language]}</Text>

                                        <View style={{
                                            marginHorizontal: mobileW * 2 / 100,
                                            borderRightWidth: mobileW * 0.35 / 100,
                                            borderColor: Colors.placeholder_color,
                                        }}>
                                        </View>

                                        <Text
                                            numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            {Lang_chg.june6[config.language]}</Text>
                                    </View>

                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>

                                        <Text
                                            numberOfLines={1}
                                            style={{
                                                color: Colors.text_color3,
                                                fontSize: mobileW * 4 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            Market</Text>

                                    </View>

                                </View>
                            </View>

                            <View style={{
                                paddingHorizontal: mobileW * 2 / 100,
                                marginLeft: mobileW * 1 / 100,
                                alignSelf: 'center',
                                backgroundColor: Colors.CartBackColor,
                                borderColor: Colors.BorderColor,
                                borderBottomWidth: mobileW * 0.5 / 100,
                                borderRightWidth: mobileW * 0.5 / 100,
                                borderLeftWidth: mobileW * 0.5 / 100,
                                paddingVertical: mobileH * 1 / 100,
                            }}>

                                {/*-------size ,price and reduce only view-------- */}
                                <View style={{
                                    width: mobileW * 85 / 100, justifyContent: 'space-between',
                                    flexDirection: 'row', marginBottom: mobileH * 2 / 100,
                                }}>

                                    <View style={styles.WidthAlignStyle}>
                                        <Text
                                            //    numberOfLines={1}
                                            style={{
                                                color: Colors.PnlTextColor,
                                                fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            {Lang_chg.average[config.language]}</Text>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            {Lang_chg.num193[config.language]}</Text>
                                    </View>

                                    <View style={styles.WidthAlignStyle}>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.PnlTextColor,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                paddingHorizontal: mobileW * 2 / 100,
                                            }}>
                                            {Lang_chg.Price[config.language]} </Text>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                paddingHorizontal: mobileW * 2 / 100,
                                            }}>
                                            {Lang_chg.num1900[config.language]} </Text>
                                    </View>

                                    <View style={styles.WidthAlignStyle}>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.PnlTextColor,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                paddingHorizontal: mobileW * 2 / 100,
                                            }}>
                                            {Lang_chg.Executed[config.language]} </Text>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                paddingHorizontal: mobileW * 2 / 100,
                                            }}>
                                            {Lang_chg.num045[config.language]} </Text>
                                    </View>

                                    <View style={styles.WidthAlignStyle}>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.PnlTextColor,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            {Lang_chg.Amount[config.language]} </Text>
                                        <Text
                                            //numberOfLines={1}
                                            style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                            38.453</Text>
                                    </View>
                                </View>
                            </View>

                            <FlatList
                                data={this.state.order_arr}
                                showsVerticalScrollIndicator={false}
                                contentContainerStyle={{
                                    paddingBottom: mobileH * 12 / 100,
                                    marginTop: mobileW * 3 / 100,
                                }}
                                renderItem={({ item, index }) =>

                                    <View style={{
                                        alignSelf: 'center',
                                        marginTop: mobileW * 3 / 100, marginLeft: mobileW * 1 / 100,
                                        borderColor: Colors.BorderColor,
                                        backgroundColor: Colors.CartBackColor,
                                        borderWidth: mobileW * 0.5 / 100,
                                        paddingVertical: mobileH * 1.5 / 100,
                                        paddingHorizontal: mobileW * 2 / 100,
                                    }}>
                                        {/*-----------buy text----------- */}

                                        <View style={{
                                            paddingVertical: mobileH * 0.5 / 100,
                                            flexDirection: 'row', justifyContent: 'space-between'
                                        }}>
                                            <View style={{
                                                width: mobileW * 15 / 100, alignItems: 'center',
                                                backgroundColor: Colors.green_color,
                                            }}>
                                                <Text style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                    {Lang_chg.BUY[config.language]}</Text>
                                            </View>

                                            <View style={{
                                                flexDirection: 'row', alignItems: 'center',
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        marginRight: mobileW * 2 / 100,
                                                        color: Colors.placeholder_color, backgroundColor: Colors.usdt_bg,
                                                        fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                        paddingHorizontal: mobileW * 2 / 100, borderRadius: mobileW * 0.5 / 100
                                                    }}>
                                                    Filled</Text>
                                                <Image style={{
                                                    top: mobileH * 1 / 100,
                                                    width: mobileW * 5 / 100,
                                                    height: mobileW * 5 / 100,
                                                }} resizeMode='contain' source={localimag.dropdown_bg}></Image>
                                            </View>
                                        </View>

                                        {/*-----------currency and filled------------ */}
                                        <View style={{
                                            width: mobileW * 85 / 100, justifyContent: 'space-between',
                                            flexDirection: 'row'
                                        }}>
                                            <View style={{ flexDirection: 'row' }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {item.scriptName}</Text>
                                                {/* -------border below flatlist------- */}

                                                <View style={{
                                                    marginHorizontal: mobileW * 2 / 100,
                                                    borderRightWidth: mobileW * 0.35 / 100,
                                                    borderColor: Colors.placeholder_color,
                                                }}>
                                                </View>

                                                <Text
                                                    numberOfLines={1}
                                                    style={{

                                                        color: Colors.placeholder_color,
                                                        fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    {item.datetime}</Text>
                                            </View>

                                            <View style={{
                                                flexDirection: 'row', alignItems: 'center',
                                            }}>
                                                <Text
                                                    numberOfLines={1}
                                                    style={{
                                                        marginRight: mobileW * 7 / 100,
                                                        color: Colors.text_color3,
                                                        fontSize: mobileW * 4 / 100, fontFamily: Font.FontMedium,
                                                    }}>
                                                    Market</Text>
                                            </View>
                                        </View>
                                    </View>
                                }></FlatList>
                        </KeyboardAwareScrollView>
                    }

                    {/* -------------------TradeHistory--------------------- */}
                    {this.state.btnStatus == 2 &&
                        <View>
                            {/*--------- view for FlatList horizontal--------- */}

                            <View style={{
                                width: mobileW * 90 / 100, alignSelf: 'center',
                                marginTop: mobileH * 2 / 100
                            }}>
                                {/* FlatList horizontal */}
                                <FlatList
                                    showsHorizontalScrollIndicator={false}
                                    horizontal={true}
                                    data={this.state.trade_history_time}
                                    contentContainerStyle={{
                                    }}
                                    renderItem={({ item, index }) =>
                                        <View style={{
                                            paddingVertical: mobileH * 1.5 / 100,
                                            borderColor: Colors.BorderColor,
                                            borderBottomWidth: mobileW * 0.5 / 100,
                                            paddingHorizontal: mobileW * 0.5 / 100
                                        }}>
                                            <TouchableOpacity
                                                style={{
                                                    flexDirection: 'row',
                                                    alignItems: 'center',
                                                    paddingHorizontal: mobileW * 1 / 100,

                                                }}
                                                activeOpacity={0.9}
                                                onPress={() => this.getviewtradehistory(item, index)}
                                            >
                                                <Image source={item.status == true ?
                                                    localimag.YellowRadioActice : localimag.RadioInactice}
                                                    resizeMode='contain'
                                                    style={{
                                                        height: mobileW * 4 / 100,
                                                        width: mobileW * 4 / 100
                                                    }}>
                                                </Image>
                                                <Text style={[
                                                    item.status == true ? { color: Colors.white_color }
                                                        :
                                                        { color: Colors.text_color2 },
                                                    {
                                                        fontSize: mobileW * 3 / 100,
                                                        paddingHorizontal: mobileW * 2 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingTop: mobileH * 0.2 / 100
                                                    }]}>
                                                    {item.timePeriod}
                                                </Text>
                                            </TouchableOpacity>
                                        </View>
                                    }></FlatList>
                            </View>

                            <KeyboardAwareScrollView
                                showsVerticalScrollIndicator={false}
                                contentContainerStyle={{
                                    paddingBottom: mobileH * 1 / 100,
                                    marginTop: mobileW * 4 / 100,
                                }}>

                                {/* 1st box  with details*/}
                                <View style={{
                                    alignSelf: 'center',
                                    marginTop: mobileW * 3 / 100,
                                    marginLeft: mobileW * 1 / 100,
                                    borderColor: Colors.BorderColor,
                                    backgroundColor: Colors.CartBackColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    paddingVertical: mobileH * 1.5 / 100,
                                    paddingHorizontal: mobileW * 2 / 100,
                                }}>
                                    {/*buy text */}
                                    <View style={{
                                        paddingVertical: mobileH * 0.5 / 100,
                                        flexDirection: 'row', justifyContent: 'space-between'
                                    }}>
                                        <View style={{
                                            width: mobileW * 15 / 100, alignItems: 'center',
                                            backgroundColor: Colors.green_color,
                                        }}>
                                            <Text style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                                {Lang_chg.BUY[config.language]}</Text>
                                        </View>
                                    </View>

                                    {/*currency and filled */}
                                    <View style={{
                                        width: mobileW * 85 / 100, justifyContent: 'space-between',
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.BTCUSDT[config.language]}</Text>

                                            {/* border below flatlist */}
                                            <View style={{
                                                marginHorizontal: mobileW * 2 / 100,
                                                borderRightWidth: mobileW * 0.35 / 100,
                                                borderColor: Colors.placeholder_color,
                                            }}>
                                            </View>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.june6[config.language]}</Text>
                                        </View>

                                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 4 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>{'1309.84'}</Text>
                                        </View>
                                    </View>
                                </View>

                                <View style={{
                                    paddingHorizontal: mobileW * 2 / 100,
                                    marginLeft: mobileW * 1 / 100,
                                    alignSelf: 'center',
                                    backgroundColor: Colors.CartBackColor,
                                    borderColor: Colors.BorderColor,
                                    borderBottomWidth: mobileW * 0.5 / 100,
                                    borderRightWidth: mobileW * 0.5 / 100,
                                    borderLeftWidth: mobileW * 0.5 / 100,
                                    paddingVertical: mobileH * 1 / 100,
                                }}>

                                    {/*price, quantity, fee and realized profit view */}
                                    <View style={{
                                        width: mobileW * 85 / 100, justifyContent: 'space-between',
                                        flexDirection: 'row',
                                        marginBottom: mobileH * 2 / 100,
                                    }}>

                                        {/*price, and its value view */}
                                        <View style={styles.WidthAlignStyle}>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.Price[config.language]}</Text>
                                            <Text
                                                //    numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.25 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.num1900[config.language]}</Text>
                                        </View>

                                        {/*quantity text, and its value view */}
                                        <View sstyle={styles.WidthAlignStyle}>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                    paddingHorizontal: mobileW * 2 / 100,
                                                }}>
                                                {Lang_chg.quantity_text[config.language]} </Text>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                    paddingHorizontal: mobileW * 2 / 100,
                                                }}>{'1.019'}</Text>
                                        </View>

                                        {/*fee text, and its value view */}
                                        <View style={styles.WidthAlignStyle}>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                    paddingHorizontal: mobileW * 2 / 100,
                                                }}>
                                                {Lang_chg.fee[config.language]} </Text>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                    paddingHorizontal: mobileW * 2 / 100,
                                                }}>{'0.53336907'}</Text>
                                        </View>

                                        {/*realized_profit text, and its value view */}
                                        <View style={styles.WidthAlignStyle}>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.realized_profit[config.language]} </Text>
                                            <Text
                                                //numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                                }}>{'-4.09436654'}</Text>
                                        </View>
                                    </View>
                                </View>

                                {/* 3 rd box  with less details*/}
                                <View style={{
                                    alignSelf: 'center',
                                    marginTop: mobileW * 3 / 100,
                                    marginLeft: mobileW * 1 / 100,
                                    borderColor: Colors.BorderColor,
                                    backgroundColor: Colors.CartBackColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    paddingVertical: mobileH * 1.5 / 100,
                                    paddingHorizontal: mobileW * 2 / 100,
                                }}>
                                    {/*buy text */}
                                    <View style={{
                                        paddingVertical: mobileH * 0.5 / 100,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{
                                            width: mobileW * 15 / 100, alignItems: 'center',
                                            backgroundColor: Colors.green_color,
                                        }}>
                                            <Text style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                                {Lang_chg.BUY[config.language]}</Text>
                                        </View>
                                    </View>

                                    {/*currency  */}
                                    <View style={{
                                        width: mobileW * 85 / 100, justifyContent: 'space-between',
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.BTCUSDT[config.language]}</Text>

                                            {/* border below flatlist */}
                                            <View style={{
                                                marginHorizontal: mobileW * 2 / 100,
                                                borderRightWidth: mobileW * 0.35 / 100,
                                                borderColor: Colors.placeholder_color,
                                            }}>
                                            </View>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.june6[config.language]}</Text>
                                        </View>

                                        <View style={{
                                            flexDirection: 'row', alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    marginRight: mobileW * 2 / 100,
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.75 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>
                                                1309.84</Text>

                                            <Image style={{
                                                top: mobileH * 0.15 / 100,
                                                width: mobileW * 5 / 100,
                                                height: mobileW * 5 / 100,
                                            }} resizeMode='contain'
                                                source={localimag.dropdown_bg}>
                                            </Image>
                                        </View>
                                    </View>
                                </View>

                                {/* 4th box  with less details*/}
                                <View style={{
                                    alignSelf: 'center',
                                    marginTop: mobileW * 3 / 100,
                                    marginLeft: mobileW * 1 / 100,
                                    borderColor: Colors.BorderColor,
                                    backgroundColor: Colors.CartBackColor,
                                    borderWidth: mobileW * 0.5 / 100,
                                    paddingVertical: mobileH * 1.5 / 100,
                                    paddingHorizontal: mobileW * 2 / 100,
                                }}>
                                    {/*buy text */}
                                    <View style={{
                                        paddingVertical: mobileH * 0.5 / 100,
                                        flexDirection: 'row',
                                        justifyContent: 'space-between'
                                    }}>
                                        <View style={{
                                            width: mobileW * 15 / 100, alignItems: 'center',
                                            backgroundColor: Colors.green_color,
                                        }}>
                                            <Text style={{
                                                color: Colors.placeholder_color,
                                                fontSize: mobileW * 3.5 / 100, fontFamily: Font.FontMedium,
                                            }}>
                                                {Lang_chg.BUY[config.language]}</Text>
                                        </View>
                                    </View>

                                    {/*currency  */}
                                    <View style={{
                                        width: mobileW * 85 / 100, justifyContent: 'space-between',
                                        flexDirection: 'row'
                                    }}>
                                        <View style={{ flexDirection: 'row' }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100, fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.BTCUSDT[config.language]}</Text>

                                            {/* border below flatlist */}
                                            <View style={{
                                                marginHorizontal: mobileW * 2 / 100,
                                                borderRightWidth: mobileW * 0.35 / 100,
                                                borderColor: Colors.placeholder_color,
                                            }}>
                                            </View>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    color: Colors.placeholder_color,
                                                    fontSize: mobileW * 3.75 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>
                                                {Lang_chg.june6[config.language]}</Text>
                                        </View>

                                        <View style={{
                                            flexDirection: 'row', alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <Text
                                                numberOfLines={1}
                                                style={{
                                                    marginRight: mobileW * 2 / 100,
                                                    color: Colors.PnlTextColor,
                                                    fontSize: mobileW * 3.75 / 100,
                                                    fontFamily: Font.FontMedium,
                                                }}>{'1309.84'}</Text>
                                            <Image style={{
                                                top: mobileH * 0.15 / 100,
                                                width: mobileW * 5 / 100,
                                                height: mobileW * 5 / 100,
                                            }} resizeMode='contain'
                                                source={localimag.dropdown_bg}>
                                            </Image>
                                        </View>
                                    </View>
                                </View>

                                {/* ---------------Model--------------- */}
                                <Modal
                                    animationType="slide"
                                    transparent
                                    visible={this.state.CancelOrderModel}
                                    onRequestClose={() => {
                                        this.setState({
                                            CancelOrderModel: false
                                        })
                                    }}>

                                    <View
                                        style={{
                                            flex: 1,
                                            backgroundColor: '#00000090',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            // bottom:-mobileH*2/100,
                                            borderRadius: 0,
                                        }}>
                                        <View style={{
                                            backgroundColor: Colors.ModelColor,
                                            width: mobileW * 80 / 100,
                                            paddingVertical: mobileH * 2 / 100
                                        }}>
                                            <View style={{ paddingVertical: mobileH * 2 / 100, alignSelf: 'center' }}>
                                                <View style={{
                                                    width: mobileW * 70 / 100,
                                                    alignSelf: 'center',
                                                    alignItems: 'center'
                                                }}>
                                                    <Image style={{
                                                        height: mobileH * 6 / 100,
                                                        width: mobileW * 12 / 100,
                                                        marginTop: mobileH * 1 / 100
                                                    }}
                                                        source={localimag.ErrorIcon}></Image>
                                                    <Text style={{
                                                        marginLeft: mobileW * 1 / 100,
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        paddingTop: mobileH * 2 / 100,
                                                        color: Colors.whiteColor,
                                                        textAlign: 'center'
                                                    }}>{Lang_chg.Cancel_order_text}
                                                    </Text>
                                                    <View>
                                                        <Text style={{
                                                            marginLeft: mobileW * 1 / 100,
                                                            fontSize: mobileW * 3.5 / 100,
                                                            fontFamily: Font.FontMedium,
                                                            color: Colors.whiteColor,
                                                            textAlign: 'center'
                                                        }}>{Lang_chg.Cancel_order_text2}
                                                        </Text>
                                                    </View>


                                                    <Text style={{
                                                        fontSize: mobileW * 3.5 / 100,
                                                        fontFamily: Font.FontMedium,
                                                        color: Colors.whiteColor,
                                                        textAlign: 'center'
                                                    }}>{Lang_chg.Cancel_order_text3}
                                                    </Text>
                                                </View>

                                                <View style={{
                                                    marginVertical: mobileH * 1 / 100,
                                                    paddingTop: mobileH * 3 / 100,
                                                    flexDirection: 'row',
                                                    justifyContent: 'space-between',
                                                    width: mobileW * 74 / 100,
                                                    alignSelf: 'center',
                                                }}>
                                                    <TouchableOpacity
                                                        onPress={() => this.setState({ CancelOrderModel: false })}
                                                        activeOpacity={0.7} style={{
                                                            backgroundColor: Colors.ModelColor,
                                                            borderWidth: mobileW * 0.5 / 100,
                                                            borderColor: Colors.whiteColor,
                                                            height: mobileH * 5 / 100,
                                                            width: mobileW * 35 / 100,
                                                            justifyContent: 'center',

                                                        }}>
                                                        <Text style={{
                                                            fontSize: mobileW * 4.5 / 100,
                                                            fontFamily: Font.FontSemiBold,
                                                            textAlign: 'center',
                                                            color: Colors.whiteColor
                                                        }}>{Lang_chg.cancel_txt[config.language]}</Text>
                                                    </TouchableOpacity>

                                                    <TouchableOpacity
                                                        activeOpacity={0.7} style={{
                                                            backgroundColor: Colors.whiteColor,
                                                            borderWidth: mobileW * 0.5 / 100,
                                                            borderColor: Colors.whiteColor,
                                                            height: mobileH * 5 / 100,
                                                            width: mobileW * 35 / 100,
                                                            justifyContent: 'center',
                                                        }}>
                                                        <Text style={{
                                                            fontSize: mobileW * 4.5 / 100,
                                                            fontFamily: Font.FontSemiBold,
                                                            textAlign: 'center',
                                                            color: Colors.black_color
                                                        }}>{Lang_chg.Confirm[config.language]}</Text>
                                                    </TouchableOpacity>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </Modal>


                            </KeyboardAwareScrollView>
                        </View>
                    }

                    {/* -------------Footer-------------- */}
                    <Footer
                        activepage='Orders'
                        usertype={1}
                        footerpage={[
                            {
                                name: 'Home',
                                fname: 'Home',
                                image: localimag.home_inactive,
                                activeimage: localimag.home_active,
                            },
                            {
                                name: 'Orders',
                                fname: 'Orders',
                                image: localimag.orders_inactive,
                                activeimage: localimag.orders_active,
                            },
                            {
                                name: 'Trade',
                                fname: 'Trade',
                                image: localimag.trade_inactive,
                                activeimage: localimag.trade_active,
                            },
                            {
                                name: 'Positions',
                                fname: 'Positions',
                                image: localimag.position_inactive,
                                activeimage: localimag.position_active,
                            },
                            {
                                name: 'Wallet',
                                fname: 'Wallet',
                                image: localimag.wallet_inactive,
                                activeimage: localimag.wallet_active,
                            },
                        ]}
                        navigation={this.props.navigation}
                        imagestyle1={{
                            width: mobileW * 6 / 100, height: mobileW * 6 / 100,
                            backgroundColor: Colors.themeblack_color,
                            countcolor: Colors.white_color,
                        }}
                    />
                </SafeAreaView >
            </View >
        )
    }
}


const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        alignItems: 'center',
        // justifyContent: 'center',
        //backgroundColor: Colors.themeblack_color
    },
    WidthAlignStyle: {
        width: mobileW * 20 / 100,
        alignItems: 'center'
    }


})
