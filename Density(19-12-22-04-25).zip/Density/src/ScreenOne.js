import React, { Component } from 'react'
import { Text, SafeAreaView, TouchableOpacity, StatusBar, View, StyleSheet, Image, } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Objectivebtn } from './AllComponents';

export default class ScreenOne extends Component {
  render() {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar
          hidden={false}
          translucent={false}
          barStyle="light-content"
          networkActivityIndicatorVisible={true}
        />

        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>


          {/* //==========Continue Submit =========// */}
          <Objectivebtn
            handlepress={() => {
              this.props.navigation.navigate('ScreenTwo')
            }}
            image={localimag.ObjectiveBottomOneImage}
          />

        </KeyboardAwareScrollView>
      </SafeAreaView>
    )
  }
}
const styles = StyleSheet.create({
  container:
  {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.themeblack_color
  },
})
