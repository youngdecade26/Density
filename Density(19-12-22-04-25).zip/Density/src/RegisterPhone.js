import React, { Component } from 'react'
import { Text, SafeAreaView, TouchableOpacity, TextInput, StatusBar, View, StyleSheet, Image, } from 'react-native'
import { config, Lang_chg, Font, Colors, mobileH, mobileW, localimag, } from './Provider/utilslib/Utils';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Appbutton, TextInputCmp } from './AllComponents';

export default class RegisterPhone extends Component {

    constructor(props) {
        super(props)
        this.state = {
            mobile: '',
        }
    }
    componentDidMount() {

    }

    render() {
        return (
            <SafeAreaView style={styles.container}>
                <StatusBar
                    hidden={false}
                    translucent={false}
                    barStyle="light-content"
                    networkActivityIndicatorVisible={true}
                />

                <KeyboardAwareScrollView showsVerticalScrollIndicator={false}
                    showsHorizontalScrollIndicator={false} contentContainerStyle={{ width: mobileW, }} keyboardShouldPersistTaps='handled'>
                    {/* //==========Image & density Text=========// */}
                    <View style={{ width: mobileW, alignItems: 'center', alignSelf: 'center' }}>
                        <View style={{
                            width: mobileW * 90 / 100,
                            alignSelf: 'center',
                            flexDirection: 'row',
                            marginTop: mobileH * 3 / 100,
                            alignItems: 'center'
                        }}>
                            <Image style={{ width: mobileW * 4.5 / 100, height: mobileW * 4.5 / 100 }} resizeMode='contain' source={localimag.density_256}></Image>
                            <View style={{ paddingHorizontal: mobileW * 1 / 100, }}>
                                <Text style={{
                                    color: Colors.whiteColor,
                                    fontSize: mobileW * 5.5 / 100,
                                    fontFamily: Font.FontSemiBold
                                }}>{Lang_chg.density_txt[config.language]}</Text>
                            </View>
                        </View>
                    </View>
                    {/* =============Enter Phone Number Text =========== */}
                    <View style={{
                        width: mobileW * 90 / 100,
                        alignSelf: 'center',
                        marginTop: mobileH * 6 / 100
                    }}>
                        <Text style={{
                            fontSize: mobileW * 6.3 / 100,
                            fontFamily: Font.FontBold,
                            color: Colors.whiteColor
                        }}>{Lang_chg.enter_your_phone_txt[config.language]}</Text>
                    </View>
                    {/* //==========MobileText=========// */}
                    <View style={{
                        width: mobileW * 90 / 100,
                        alignItems: 'center',
                        alignSelf: 'center',
                        marginTop: mobileH * 3 / 100
                    }}>
                        <TextInputCmp
                            htitle={Lang_chg.mobile_number_txt[config.language]}
                            placeholder={Lang_chg.enter_mobile_number_txt[config.language]}
                            Keyboard={'numeric'}
                            maxLength={16}
                            onChangeText={(txt) => { this.setState({ email: txt }) }}
                        />
                    </View>

                    {/* //==========Continue Submit =========// */}
                    <View style={{ marginTop: mobileH * 20 / 100 }}>
                        <Appbutton
                            handlepress={() => {
                                this.props.navigation.navigate('OtpVerification')
                            }}
                            title={Lang_chg.SendOTP[config.language]}
                        />
                    </View>


                </KeyboardAwareScrollView>
            </SafeAreaView>
        )
    }
}
const styles = StyleSheet.create({
    container:
    {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.themeblack_color


    },
    view1:
    {
        backgroundColor: Colors.themeblack_color,
        height: mobileH * 8 / 100,

        flexDirection: 'row',
        width: mobileW * 88 / 100,
        alignSelf: 'center',
        alignItems: 'center',

    },

    icon1s: {
        width: mobileW * 5 / 100,
        height: mobileW * 5 / 100,
        resizeMode: 'contain', alignSelf: 'center'
    },

})
